import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.crusher.system',
  appName: 'نظام إدارة مبيعات الكسارات',
  webDir: 'dist'
};

export default config;
