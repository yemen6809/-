import React, { useState, useEffect } from 'react';
import { Order, Supplier, SupplierTransaction, InventoryItem } from '../types';
import { 
  Building2, Landmark, Wallet, ArrowDownLeft, ArrowUpRight, 
  Layers, FileText, CheckCircle2, AlertCircle, Plus, Trash2, 
  Printer, Scale, TrendingUp, Info, PieChart, ShieldCheck, ChevronLeft
} from 'lucide-react';

interface AccountingManagerProps {
  orders: Order[];
  suppliers: Supplier[];
  inventory: InventoryItem[];
  transactions: SupplierTransaction[];
  currentRole: string;
  onAddTransaction?: (txn: SupplierTransaction) => void;
}

// Chart of Accounts Types and Codes
interface Account {
  code: string;
  name: string;
  category: 'Asset' | 'Liability' | 'Equity' | 'Revenue' | 'Expense';
  description: string;
  balanceType: 'Debit' | 'Credit';
}

// Manual Journal Entry Types
interface JournalItem {
  accountCode: string;
  debit: number;
  credit: number;
  note?: string;
}

interface JournalEntry {
  id: string;
  date: string;
  reference: string;
  description: string;
  items: JournalItem[];
  isSystemGenerated: boolean;
  createdBy: string;
}

export default function AccountingManager({ 
  orders, 
  suppliers, 
  inventory, 
  transactions,
  currentRole,
  onAddTransaction
}: AccountingManagerProps) {

  // 1. Chart Of Accounts Definition (COA)
  const chartOfAccounts: Account[] = [
    // Assets (الأصول)
    { code: '10100', name: 'صندوق النقدية العام (الخزينة)', category: 'Asset', balanceType: 'Debit', description: 'الصندوق الرئيسي لجميع المعاملات النقدية السائلة والمقبوضات من العملاء' },
    { code: '10200', name: 'حساب البنك الجاري', category: 'Asset', balanceType: 'Debit', description: 'النقدية المحتفظ بها في الحسابات البنكية والمصرفية والحوالات' },
    { code: '10300', name: 'الذمم المدينة (حسابات العملاء)', category: 'Asset', balanceType: 'Debit', description: 'المطالبات المستحقة على العملاء مقابل مبيعات الكري والتوزيع' },
    { code: '10400', name: 'مخزون الكري والمواد (أصل متداول)', category: 'Asset', balanceType: 'Debit', description: 'القيمة التقديرية للمواد والمنتجات المخزنة بالسيلوهات' },
    
    // Liabilities (الالتزامات)
    { code: '20100', name: 'الذمم الدائنة (حسابات الكسارات الجارية - 5,900 ريال/م³)', category: 'Liability', balanceType: 'Credit', description: 'مستحقات صاحب الكسارة الموردة الفعلية بمعدل 5900 ريال لكل متر مكعب مباع' },
    { code: '20200', name: 'مستحقات الضرائب والرسوم الحكومية العامة والوساطة', category: 'Liability', balanceType: 'Credit', description: 'الرسوم المتراكمة على طلبيات التوريد والوساطة الإضافية' },
    { code: '20300', name: 'مستحقات صندوق الركاز (الزكاة الشرعية - 500 ريال/م³)', category: 'Liability', balanceType: 'Credit', description: 'مستحقات الزكاة المستقطعة آلياً بواقع 500 ريال يمني عن كل متر مباع وتدرج لصندوق الركاز' },
    { code: '20400', name: 'مستحقات الهيئة العامة للكسارات (200 ريال/م³)', category: 'Liability', balanceType: 'Credit', description: 'مستحقات الهيئة العامة المعيارية المنظمة بمعدل 200 ريال لكل متر مباع' },
    { code: '20500', name: 'مستحقات المحور والرقابة (200 ريال/م³)', category: 'Liability', balanceType: 'Credit', description: 'حصة المحور والرقابة التنظيمية بمعدل 200 ريال لكل متر مباع موجه من ساحة الكشف' },
    
    // Equity (حقوق الملكية)
    { code: '30100', name: 'رأس المال المستثمر', category: 'Equity', balanceType: 'Credit', description: 'رأس مال الشركة التأسيسي الموجه للتشغيل' },
    { code: '30200', name: 'الأرباح المحتجزة / المدورة والاحتياطيات', category: 'Equity', balanceType: 'Credit', description: 'صوافي الأرباح التراكمية المستبقاة للأعوام والدورات القادمة' },
    
    // Revenues (الإيرادات)
    { code: '40100', name: 'إيرادات بيع وتوريد الكري الإجمالية', category: 'Revenue', balanceType: 'Credit', description: 'المبيعات الكلية لمنتجات الكسارة' },
    { code: '40200', name: 'إيراد أجور العاملين ونفقات مكتب التوزيع (200 ريال/م³)', category: 'Revenue', balanceType: 'Credit', description: 'الإيراد المفرز تلقائياً لتغطية معاشات الموظفين ومصاريف مكتب التوزيع بمعدل 200 ريال لكل متر' },
    
    // Expenses (المصروفات)
    { code: '50100', name: 'تكلفة مبيعات الكري (المشغلين والكسارات)', category: 'Expense', balanceType: 'Debit', description: 'حصة الكسارة والإنتاج التشغيلي المباشر' },
    { code: '50200', name: 'مصاريف النقل والخدمات اللوجستية والترحيل', category: 'Expense', balanceType: 'Debit', description: 'أجور التوصيل والناقلين والشحنات المفردة' },
    { code: '50300', name: 'مصاريف إدارية وعمومية وصيانة سيلوهات', category: 'Expense', balanceType: 'Debit', description: 'رواتب وإيجارات ومصاريف الصيانة المتكررة للمعدات والمقرات' }
  ];

  // 2. Local Manual Journal Entries State with persistence
  const [manualEntries, setManualEntries] = useState<JournalEntry[]>(() => {
    const saved = localStorage.getItem('quarry_accounting_entries');
    return saved ? JSON.parse(saved) : [];
  });

  // Save manualEntries to LocalStorage
  useEffect(() => {
    localStorage.setItem('quarry_accounting_entries', JSON.stringify(manualEntries));
  }, [manualEntries]);

  // UI Active tabs within Accounting Component
  const [accountingSubTab, setAccountingSubTab] = useState<'overview' | 'ledger' | 'journal' | 'trial_balance' | 'statements'>('overview');
  
  // State for Journal Entry Creation Form
  const [showEntryForm, setShowEntryForm] = useState(false);
  const [formDate, setFormDate] = useState(new Date().toISOString().split('T')[0]);
  const [formReference, setFormReference] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formItems, setFormItems] = useState<JournalItem[]>([
    { accountCode: '10100', debit: 0, credit: 0, note: '' },
    { accountCode: '40200', debit: 0, credit: 0, note: '' }
  ]);
  const [formError, setFormError] = useState<string | null>(null);

  // General Ledger selected account for detailed audit state
  const [selectedLedgerAccountCode, setSelectedLedgerAccountCode] = useState<string>('10100');

  // Print view modes
  const [printDocumentType, setPrintDocumentType] = useState<'journal' | 'trial_balance' | 'income' | 'balance_sheet' | null>(null);

  // Disbursement Voucher Form State
  const [showDisbursementForm, setShowDisbursementForm] = useState(false);
  const [disburseSource, setDisburseSource] = useState<string>('10100'); // Default Treasury (صندوق النقدية العام)
  const [disburseTarget, setDisburseTarget] = useState<string>('20300'); // Default Rikaz
  const [disburseSupplierId, setDisburseSupplierId] = useState<string>(''); // For Crusher
  const [disburseAmount, setDisburseAmount] = useState<number>(0);
  const [disburseReference, setDisburseReference] = useState<string>('');
  const [disburseDesc, setDisburseDesc] = useState<string>('');
  const [disburseDate, setDisburseDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [disburseError, setDisburseError] = useState<string | null>(null);

  // Receipt Voucher Form State
  const [showReceiptForm, setShowReceiptForm] = useState(false);
  const [receiptTarget, setReceiptTarget] = useState<string>('10100'); // Default Treasury (صندوق النقدية العام) to receive funds
  const [receiptSource, setReceiptSource] = useState<string>('10300'); // Default Accounts Receivable (الذمم المدينة)
  const [receiptCustomerName, setReceiptCustomerName] = useState<string>(''); // Customer name
  const [receiptAmount, setReceiptAmount] = useState<number>(0);
  const [receiptReference, setReceiptReference] = useState<string>('');
  const [receiptDesc, setReceiptDesc] = useState<string>('');
  const [receiptDate, setReceiptDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [receiptError, setReceiptError] = useState<string | null>(null);

  // 3. Dynamic Auto-Generated Journal Entries Generator
  // In accounting design, system transactions (Sales, Payments, production) are double-entry mapped
  const generateSystemJournalEntries = (): JournalEntry[] => {
    const systemEntries: JournalEntry[] = [];

    // Order Entries (Sales, commissions, liability increases, receivables)
    orders.forEach((order) => {
      // Create Sale Journal Entry
      // 1. Debit Cash on hand or Accounts Receivable (depending on payment method or if delivered)
      const debitCode = order.paymentMethod === 'Cash' ? '10100' : '10200'; // Cash vs Bank
      
      const qty = order.quantity || 0;
      const rikazShare = qty * 500;
      const haiahShare = qty * 200;
      const mihwarShare = qty * 200;
      const staffOfficeShare = qty * 200;
      const crusherShare = order.supplierAmount; // 5900 per cubic meter directly matched

      const entryItems: JournalItem[] = [
        // Debit: total price collected from customer (7,000 RY per meter)
        { 
          accountCode: debitCode, 
          debit: order.totalPrice, 
          credit: 0, 
          note: `تحصيل القيمة الكلية للفاتورة رقم ${order.id} من العميل` 
        },
        // Credit 1: Crusher Owner (5,900 RY per meter)
        { 
          accountCode: '20100', // accounts payable - suppliers
          debit: 0, 
          credit: crusherShare, 
          note: `استحقاق المورد صاحب الكسارة (${order.supplierName}) بمعدل 5900 ريال/م³` 
        },
        // Credit 2: Rikaz / Zakat (500 RY per meter)
        { 
          accountCode: '20300', 
          debit: 0, 
          credit: rikazShare, 
          note: `مستحقات زكاة الركاز الشرعية بمعدل 500 ريال/م³` 
        },
        // Credit 3: Authority / Al-Hai'ah (200 RY per meter)
        { 
          accountCode: '20400', 
          debit: 0, 
          credit: haiahShare, 
          note: `مستحقات رسوم الهيئة التنظيمية بمعدل 200 ريال/م³` 
        },
        // Credit 4: Axial / Al-Mihwar (200 RY per meter)
        { 
          accountCode: '20500', 
          debit: 0, 
          credit: mihwarShare, 
          note: `رسوم مخصصة للمحور والرقابة بمعدل 200 ريال/م³` 
        },
        // Credit 5: Employees / Office expenses (200 RY per meter)
        { 
          accountCode: '40200', 
          debit: 0, 
          credit: staffOfficeShare, 
          note: `إيراد أجور موظفين ومصاريف مكتب التوزيع بمعدل 200 ريال/م³` 
        }
      ];

      // Insert standard sale description showing exact breakdown of the 1,100 RY distribution
      systemEntries.push({
        id: `SYS-ORD-${order.id}`,
        date: order.date.split('T')[0],
        reference: order.id,
        description: `قيد مالي آلي للفاتورة ${order.id} - العميل: ${order.customerName || 'عام'} - الكسارة: ${order.supplierName} | التفصيل لكل م³: 5900 للكسارة، 500 ركاز، 200 هيئة، 200 محور، 200 نفقات وأجور المكتب.`,
        items: entryItems,
        isSystemGenerated: true,
        createdBy: 'النظام المحاسبي الذكي'
      });
    });

    // Supplier Disbursements/Payments (سندات الصرف والذمم والتسويات للنقدية)
    transactions.forEach((txn) => {
      // We only map payments here since production doesn't direct double-entry cash unless specified.
      // A payment represents actual money outflow to reduce the Liability to Suppliers & reduce cash/bank assets.
      if (txn.type === 'Payment') {
        const creditCode = '10100'; // Disbursed from Cash on Hand
        const amountAbs = Math.abs(txn.amount); // amount in Transactions is negative for payment out

        const entryItems: JournalItem[] = [
          // Debit: accounts payable (reduces liability)
          {
            accountCode: '20100',
            debit: amountAbs,
            credit: 0,
            note: `تخفيض ذمة مورد الكسارة - كود ${txn.supplierId}`
          },
          // Credit: cash asset (reduces general cash)
          {
            accountCode: creditCode,
            debit: 0,
            credit: amountAbs,
            note: `صرف نقدي من الخزينة لحساب المورد بموجب مستند الصرف`
          }
        ];

        systemEntries.push({
          id: `SYS-TXN-${txn.id}`,
          date: txn.date.split('T')[0],
          reference: txn.id,
          description: `قيد صرف وتسوية ذمم ثنائية آلي لمورد الكسارة: ${txn.description}`,
          items: entryItems,
          isSystemGenerated: true,
          createdBy: 'نظام التدقيق الرقمي'
        });
      }
    });

    return systemEntries;
  };

  // Combine System Generated and Manual entries
  const allJournals: JournalEntry[] = [
    ...manualEntries,
    ...generateSystemJournalEntries()
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // 4. Trial Balance dynamic recalculation algorithm
  // This reads all debit and credit movements on all accounts
  const calculateAccountBalances = (): Record<string, { debitsSum: number; creditsSum: number; netBalance: number }> => {
    const balances: Record<string, { debitsSum: number; creditsSum: number; netBalance: number }> = {};
    
    // Initialize chart codes
    chartOfAccounts.forEach(acc => {
      balances[acc.code] = { debitsSum: 0, creditsSum: 0, netBalance: 0 };
    });

    // Aggregate movements from all journal items
    allJournals.forEach(entry => {
      entry.items.forEach(item => {
        if (!balances[item.accountCode]) {
          balances[item.accountCode] = { debitsSum: 0, creditsSum: 0, netBalance: 0 };
        }
        balances[item.accountCode].debitsSum += item.debit;
        balances[item.accountCode].creditsSum += item.credit;
      });
    });

    // Compute Net Balance depending on balance normal type (Debit normal accounts vs Credit normal accounts)
    chartOfAccounts.forEach(acc => {
      const b = balances[acc.code];
      if (acc.balanceType === 'Debit') {
        b.netBalance = b.debitsSum - b.creditsSum;
      } else {
        b.netBalance = b.creditsSum - b.debitsSum;
      }
    });

    return balances;
  };

  const accountBalances = calculateAccountBalances();

  // Helper check for mathematical equation: Debits = Credits overall
  const totals = allJournals.reduce((acc, current) => {
    current.items.forEach(item => {
      acc.debit += item.debit;
      acc.credit += item.credit;
    });
    return acc;
  }, { debit: 0, credit: 0 });

  // 5. Income Statement (قائمة الدخل م³) calculations
  const totalRevenues = (accountBalances['40100']?.netBalance || 0) + (accountBalances['40200']?.netBalance || 0);
  const totalExpenses = (accountBalances['50100']?.netBalance || 0) + (accountBalances['50200']?.netBalance || 0) + (accountBalances['50300']?.netBalance || 0);
  const netOperatingIncome = totalRevenues - totalExpenses;

  // 6. Balance Sheet (الميزانية العمومية) calculation
  // Dynamic temporary assignment of netOperatingIncome into retained earnings (30200) for statement matching
  const dynamicRetainedEarnings = (accountBalances['30200']?.netBalance || 0) + netOperatingIncome;
  
  const assetsList = chartOfAccounts.filter(a => a.category === 'Asset');
  const totalAssets = assetsList.reduce((sum, a) => sum + (accountBalances[a.code]?.netBalance || 0), 0);

  const liabilitiesList = chartOfAccounts.filter(a => a.category === 'Liability');
  const totalLiabilities = liabilitiesList.reduce((sum, a) => sum + (accountBalances[a.code]?.netBalance || 0), 0);

  const equityList = chartOfAccounts.filter(a => a.category === 'Equity');
  const totalEquityWithoutIncome = equityList.reduce((sum, a) => {
    if (a.code === '30200') return sum; // exclude raw retained earnings since we add dynamic complete income below
    return sum + (accountBalances[a.code]?.netBalance || 0);
  }, 0);
  const totalEquity = totalEquityWithoutIncome + dynamicRetainedEarnings;

  // Balance Equation status
  const isBalanceSheetBalanced = Math.abs(totalAssets - (totalLiabilities + totalEquity)) < 1;

  // Form Management Handlers
  const handleAddRow = () => {
    setFormItems([...formItems, { accountCode: '10100', debit: 0, credit: 0, note: '' }]);
  };

  const handleRemoveRow = (index: number) => {
    if (formItems.length <= 2) {
      setFormError('الحد الأدنى لقيد اليومية المزدوج هو سطرين محاسبيين على الأقل.');
      return;
    }
    const filtered = formItems.filter((_, idx) => idx !== index);
    setFormItems(filtered);
    setFormError(null);
  };

  const handleItemChange = (index: number, field: keyof JournalItem, value: any) => {
    const updated = [...formItems];
    
    if (field === 'debit') {
      const val = parseFloat(value) || 0;
      updated[index].debit = val;
      if (val > 0) updated[index].credit = 0; // standard safety: clear opposite value
    } else if (field === 'credit') {
      const val = parseFloat(value) || 0;
      updated[index].credit = val;
      if (val > 0) updated[index].debit = 0; // standard safety: clear opposite value
    } else {
      updated[index][field] = value;
    }
    
    setFormItems(updated);
    setFormError(null);
  };

  const submitJournalEntry = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formDescription.trim()) {
      setFormError('الرجاء كتابة وصف تفصيلي يوضح طبيعة المعاملة المالية.');
      return;
    }

    // Mathematical check: Total debits must equal credits
    const totalDebits = formItems.reduce((sum, item) => sum + item.debit, 0);
    const totalCredits = formItems.reduce((sum, item) => sum + item.credit, 0);

    if (totalDebits === 0 || totalCredits === 0) {
      setFormError('لا يمكن تدوين قيم صفرية لكلا الخانتين. يجب تحديد مبالغ مالية حقيقية.');
      return;
    }

    if (Math.abs(totalDebits - totalCredits) > 0.01) {
      setFormError(`القيد غير متوازن مالياً! إجمالي المدين: ${totalDebits.toLocaleString()} ريال، وإجمالي الدائن: ${totalCredits.toLocaleString()} ريال. الفرق يجب أن يساوي صفراً.`);
      return;
    }

    // Formulate new Entry
    const newEntry: JournalEntry = {
      id: `JV-${Math.floor(Math.random() * 90000 + 10000)}`,
      date: formDate,
      reference: formReference || `MEMO-${Math.floor(Math.random() * 10000)}`,
      description: formDescription,
      items: formItems.map(item => ({
        ...item,
        debit: Number(item.debit),
        credit: Number(item.credit)
      })),
      isSystemGenerated: false,
      createdBy: 'أمير مطري (المدير المالي)'
    };

    setManualEntries([newEntry, ...manualEntries]);
    
    // Reset Form
    setShowEntryForm(false);
    setFormDescription('');
    setFormReference('');
    setFormItems([
      { accountCode: '10100', debit: 0, credit: 0, note: '' },
      { accountCode: '40200', debit: 0, credit: 0, note: '' }
    ]);
    setFormError(null);
  };

  const deleteManualEntry = (id: string) => {
    if (window.confirm('🚨 هل أنت متأكد تماماً من حذف وإلغاء هذا القيد الدفتري اليدوي وتصحيح الحركات العكسية؟')) {
      setManualEntries(manualEntries.filter(entry => entry.id !== id));
    }
  };

  const submitDisbursement = (e: React.FormEvent) => {
    e.preventDefault();
    setDisburseError(null);

    const amount = Number(disburseAmount) || 0;
    if (amount <= 0) {
      setDisburseError('الرجاء تحديد مبلغ مالي صحيح أكبر من الصفر.');
      return;
    }

    // Verify Cash on Hand / Bank
    const sourceAccount = chartOfAccounts.find(a => a.code === disburseSource);
    const sourceBalance = accountBalances[disburseSource]?.netBalance || 0;
    const sourceName = sourceAccount ? sourceAccount.name : 'الحساب المالي';

    if (amount > sourceBalance) {
      if (!window.confirm(`⚠️ تحذير: رصيد مصدر الصرف الحالي (${sourceName} = ${sourceBalance.toLocaleString()} ريال) أقل من القيمة المطلوبة للصرف (${amount.toLocaleString()} ريال). هل تريد المتابعة على أية حال وتجاوز الرصيد؟`)) {
        return;
      }
    }

    const dateStr = disburseDate || new Date().toISOString().split('T')[0];
    const refStr = disburseReference || `DSB-${Math.floor(Math.random() * 90000 + 10000)}`;

    if (disburseTarget === 'crusher') {
      // 1. Pay Supplier / Crusher Owner
      if (!disburseSupplierId) {
        setDisburseError('الرجاء اختيار اسم صاحب الكسارة المستفيد.');
        return;
      }
      const matchedSupplier = suppliers.find(s => s.id === disburseSupplierId);
      if (!matchedSupplier) {
        setDisburseError('لم يتم العثور على الكسارة المحددة في النظام.');
        return;
      }

      const description = disburseDesc.trim() || `سند صرف مالي رقم ${refStr} مسدد لحساب صاحب الكسارة: ${matchedSupplier.name}`;

      if (onAddTransaction) {
        // Submit using cross-module coordinator
        const numericIds = transactions.map(t => {
          const match = t.id.match(/\d+/);
          return match ? parseInt(match[0], 10) : 0;
        });
        const maxId = Math.max(0, ...numericIds);
        const nextTxnId = `TXN-${maxId + 1}`;

        const newTxn: SupplierTransaction = {
          id: nextTxnId,
          supplierId: disburseSupplierId,
          type: 'Payment',
          amount: amount,
          date: new Date(dateStr).toISOString(),
          description: description
        };
        onAddTransaction(newTxn);
      } else {
        setDisburseError('خطأ تقني: محرك تسوية الكسارة الخارجي غير متوفر.');
        return;
      }
    } else {
      // 2. Pay Regulatory bodies or office/salaries directly
      const targetAccount = chartOfAccounts.find(a => a.code === disburseTarget);
      if (!targetAccount) {
        setDisburseError('الحساب المستهدف غير موجود أو غير معرف.');
        return;
      }

      const description = disburseDesc.trim() || `صرف مالي وتسوية بموجب سند صرف رقم ${refStr} - للجهة: ${targetAccount.name}`;

      const entryItems: JournalItem[] = [
        // Debit: reduce liability or record expense/salaries (reduces credit pool or increases expense)
        {
          accountCode: disburseTarget,
          debit: amount,
          credit: 0,
          note: `تسجيل صرف مالي لجهة: ${targetAccount.name}`
        },
        // Credit: reduce cash or bank asset
        {
          accountCode: disburseSource,
          debit: 0,
          credit: amount,
          note: `سحب نقدي بموجب سند الصرف رقم ${refStr}`
        }
      ];

      const newEntry: JournalEntry = {
        id: `JV-${Math.floor(Math.random() * 90000 + 10000)}`,
        date: dateStr,
        reference: refStr,
        description: description,
        items: entryItems,
        isSystemGenerated: false,
        createdBy: 'نظام الصرف التلقائي الذكي'
      };

      setManualEntries([newEntry, ...manualEntries]);
    }

    // Success! Reset and close
    setShowDisbursementForm(false);
    setDisburseSource('10100');
    setDisburseTarget('20300');
    setDisburseSupplierId('');
    setDisburseAmount(0);
    setDisburseReference('');
    setDisburseDesc('');
    setDisburseError(null);
    alert('✅ تم إصدار سند الصرف المالي والتسوية بنجاح، وخصمها من رصيد المصدر وترحيلها للحسابات العامة فوراً.');
  };

  const submitReceipt = (e: React.FormEvent) => {
    e.preventDefault();
    setReceiptError(null);

    const amount = Number(receiptAmount) || 0;
    if (amount <= 0) {
      setReceiptError('الرجاء تحديد مبلغ مالي صحيح أكبر من الصفر.');
      return;
    }

    const dateStr = receiptDate || new Date().toISOString().split('T')[0];
    const refStr = receiptReference || `REC-${Math.floor(Math.random() * 90000 + 10000)}`;

    const targetAccount = chartOfAccounts.find(a => a.code === receiptTarget); // Cash/Bank
    const sourceAccount = chartOfAccounts.find(a => a.code === receiptSource); // Customer/Capital/Revenue

    if (!targetAccount || !sourceAccount) {
      setReceiptError('الحساب المحدد غير موجود أو غير معرف في شجرة الحسابات.');
      return;
    }

    // Prepare note/description
    let suffix = '';
    if (receiptSource === '10300' && receiptCustomerName.trim()) {
      suffix = ` - من العميل: ${receiptCustomerName.trim()}`;
    }
    const description = receiptDesc.trim() || `قبض وتوريد مالي بموجب سند قبض رقم ${refStr}${suffix} لصالح حـ/ ${targetAccount.name}`;

    const entryItems: JournalItem[] = [
      // Debit: increase General Cash or Bank asset (targetAccount)
      {
        accountCode: receiptTarget,
        debit: amount,
        credit: 0,
        note: `توريد للمقبوضات لصندوق/بنك بموجب سند القبض رقم ${refStr}`
      },
      // Credit: sourceAccount (reducing Receivables or adding to Capital/Revenues)
      {
        accountCode: receiptSource,
        debit: 0,
        credit: amount,
        note: `تسوية وإثبات دفعة المقبوضات حـ/ ${sourceAccount.name}${suffix}`
      }
    ];

    const newEntry: JournalEntry = {
      id: `JV-${Math.floor(Math.random() * 90000 + 10000)}`,
      date: dateStr,
      reference: refStr,
      description: description,
      items: entryItems,
      isSystemGenerated: false,
      createdBy: 'نظام القبض والتوريد التلقائي'
    };

    setManualEntries([newEntry, ...manualEntries]);

    // Success! Reset and close
    setShowReceiptForm(false);
    setReceiptTarget('10100');
    setReceiptSource('10300');
    setReceiptCustomerName('');
    setReceiptAmount(0);
    setReceiptReference('');
    setReceiptDesc('');
    setReceiptError(null);
    alert('✅ تم إصدار سند القبض والتوريد المالي بنجاح، وتغذية رصيد الحساب المستلم وترحيله فوراً.');
  };

  // Trigger Print Command
  const handlePrint = (type: 'journal' | 'trial_balance' | 'income' | 'balance_sheet') => {
    setPrintDocumentType(type);
    setTimeout(() => {
      window.print();
    }, 150);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 md:p-6 font-sans text-right" id="accounting-manager-main">
      
      {/* Tab Navigation header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-5 border-b border-slate-200">
        <div>
          <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <Building2 className="w-5 h-5 text-indigo-600 print:hidden" />
            نظام التدقيق والحسابات العامة للمنشأة المعتمد (GAAP / IFRS Arabic Standard)
          </h2>
          <p className="text-slate-500 text-xs mt-1">
            مراقبة الذمم المدينة والدائنة، إيرادات النسب والعمولات، ترحيل قيود اليومية الثنائية، واحتساب المركز المالي والتقارير الختامية الفورية.
          </p>
        </div>

        {/* Action Buttons for Financial Operations */}
        {(currentRole === 'Admin' || currentRole === 'Accounting' || currentRole === 'Cashier') && (
          <div className="flex flex-wrap gap-2 print:hidden" id="financial-action-buttons">
            <button
              type="button"
              onClick={() => {
                setShowReceiptForm(!showReceiptForm);
                if (showDisbursementForm) setShowDisbursementForm(false);
                if (showEntryForm) setShowEntryForm(false);
              }}
              className="bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 transform active:scale-95 transition-all cursor-pointer shadow-sm"
            >
              <ArrowDownLeft className="w-4 h-4" />
              {showReceiptForm ? 'إلغاء القبض' : 'إصدار سند قبض مالي (تحصيل الإيرادات والمقبوضات الفورية)'}
            </button>

            <button
              type="button"
              onClick={() => {
                setShowDisbursementForm(!showDisbursementForm);
                if (showReceiptForm) setShowReceiptForm(false);
                if (showEntryForm) setShowEntryForm(false);
              }}
              className="bg-emerald-600 hover:bg-emerald-750 hover:bg-emerald-700 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 transform active:scale-95 transition-all cursor-pointer shadow-sm"
            >
              <Wallet className="w-4 h-4" />
              {showDisbursementForm ? 'إلغاء الصرف' : 'إصدار سند صرف مالي (صرف مستحقات الجهات والكسارات)'}
            </button>

            {(currentRole === 'Admin' || currentRole === 'Accounting') && (
              <button
                type="button"
                onClick={() => {
                  setShowEntryForm(!showEntryForm);
                  if (showDisbursementForm) setShowDisbursementForm(false);
                  if (showReceiptForm) setShowReceiptForm(false);
                }}
                className="bg-indigo-600 hover:bg-indigo-750 hover:bg-indigo-700 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 transform active:scale-95 transition-all cursor-pointer shadow-sm"
              >
                <Plus className="w-4 h-4" />
                {showEntryForm ? 'إلغاء القيد اليدوي' : 'تسجيل قيد يومية محاسبي يدوي'}
              </button>
            )}
          </div>
        )}
      </div>

      {/* Receipt Voucher Form Box */}
      {showReceiptForm && (
        <form id="receipt-voucher-form" onSubmit={submitReceipt} className="bg-sky-50/50 border border-sky-200 p-5 rounded-2xl mt-5 mb-5 space-y-4 animate-slide-down print:hidden">
          <div className="flex items-center justify-between gap-4 border-b border-sky-100 pb-2">
            <div className="flex items-center gap-2 text-sky-950 font-black text-xs">
              <ArrowDownLeft className="w-4.5 h-4.5 text-sky-600" />
              <span>نافذة إصدار سند قبض مالي وتحصيل الإيرادات والذمم (توريد الحسابات والصناديق فوراً)</span>
            </div>
            
            {/* Top Back/Close Button */}
            <button
              type="button"
              onClick={() => setShowReceiptForm(false)}
              className="text-[10px] bg-white text-sky-900 border border-sky-200 px-3 py-1.5 rounded-xl hover:bg-sky-100/50 font-bold flex items-center gap-1 transition cursor-pointer select-none shrink-0"
            >
              <ChevronLeft className="w-3.5 h-3.5 rotate-180 text-sky-600" />
              <span>رجوع للخلف ×</span>
            </button>
          </div>

          {receiptError && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 text-xs p-3 rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4.5 h-4.5 text-rose-600 shrink-0" />
              <span>{receiptError}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Input 1: Destination Cash/Bank (Debit) */}
            <div>
              <label className="block text-[10px] font-bold text-slate-700 mb-1">الجهة الفنية المستلمة للنقدية (مدين)</label>
              <select
                value={receiptTarget}
                onChange={(e) => setReceiptTarget(e.target.value)}
                className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-sky-500 font-sans"
                required
              >
                <option value="10100">صندوق النقدية العام (الخزينة) - رصيد: { (accountBalances['10100']?.netBalance || 0).toLocaleString() } ريال</option>
                <option value="10200">حساب البنك الجاري (الحوالات) - رصيد: { (accountBalances['10200']?.netBalance || 0).toLocaleString() } ريال</option>
              </select>
            </div>

            {/* Input 2: Source Account (Credit) */}
            <div>
              <label className="block text-[10px] font-bold text-slate-700 mb-1">مصدر الإيراد / الحساب المسدّد (دائن)</label>
              <select
                value={receiptSource}
                onChange={(e) => setReceiptSource(e.target.value)}
                className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-sky-500 font-sans"
                required
              >
                <option value="10300">الذمم المدينة (حسابات العملاء) - كود 10300</option>
                <option value="30100">رأس المال المستثمر (ضخ وتأسيس) - كود 30100</option>
                <option value="40100">إيرادات كليّة لبيع وتوريد الكري - كود 40100</option>
                <option value="40200">إيرادات ونفقات مكتب التوزيع والتشغيل - كود 40200</option>
                <option value="40300">إيرادات عمولات ونسب الكسارات المتنوعة - كود 40300</option>
              </select>
            </div>

            {/* Input 3: Optional Reference field */}
            {receiptSource !== '10300' && (
              <div>
                <label className="block text-[10px] font-bold text-slate-700 mb-1">الرقم المرجعي للسند (اختياري)</label>
                <input
                  type="text"
                  value={receiptReference}
                  onChange={(e) => setReceiptReference(e.target.value)}
                  placeholder="مثال: REC-4911"
                  className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-sky-500 font-sans text-left"
                />
              </div>
            )}

            {/* Input 3 Conditional: Customer Name */}
            {receiptSource === '10300' && (
              <div>
                <label className="block text-[10px] font-bold text-slate-700 mb-1">اسم العميل المسدد (أو اكتب جديداً)</label>
                <input
                  type="text"
                  list="order-customers-list"
                  value={receiptCustomerName}
                  onChange={(e) => setReceiptCustomerName(e.target.value)}
                  placeholder="اكتب اسم العميل أو اختر من القائمة"
                  className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-sky-500 font-sans"
                  required
                />
                <datalist id="order-customers-list">
                  {Array.from(new Set(orders.map(o => o.customerName).filter(Boolean))).map((name) => (
                    <option key={name} value={name} />
                  ))}
                </datalist>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-700 mb-1">المبلغ المراد قبضه وتوريده (ريال يمني)</label>
              <input
                type="number"
                value={receiptAmount || ''}
                onChange={(e) => setReceiptAmount(Math.max(0, parseFloat(e.target.value) || 0))}
                className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-sky-500 font-sans font-bold text-sky-700"
                placeholder="أدخل قيمة المقبوضات بالريال"
                min="1"
                required
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-700 mb-1">تاريخ تحصيل السند</label>
              <input
                type="date"
                value={receiptDate}
                onChange={(e) => setReceiptDate(e.target.value)}
                className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-sky-500 font-sans"
                required
              />
            </div>

            {receiptSource === '10300' && (
              <div>
                <label className="block text-[10px] font-bold text-slate-700 mb-1">الرقم المرجعي للسند (اختياري)</label>
                <input
                  type="text"
                  value={receiptReference}
                  onChange={(e) => setReceiptReference(e.target.value)}
                  placeholder="مثال: REC-4911"
                  className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-sky-500 font-sans text-left"
                />
              </div>
            )}
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-700 mb-1">بيان سند القبض والشرح الاستدلالي (البيان الكلي للقيد)</label>
            <textarea
              value={receiptDesc}
              onChange={(e) => setReceiptDesc(e.target.value)}
              placeholder="مثال: تحصيل وتحصين المبالغ المستحقة من العميل عن قيمة توريد حمولات الكري العالقة وحفظها بالخزينة..."
              rows={2}
              className="w-full text-xs font-medium p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-sky-500"
            />
          </div>

          <div className="flex justify-end gap-2 text-xs font-bold pt-2">
            <button
              type="button"
              onClick={() => setShowReceiptForm(false)}
              className="px-4 py-2 text-slate-700 hover:bg-slate-200 bg-slate-100 rounded-xl font-extrabold flex items-center gap-1.5 transition cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5 rotate-180" />
              <span>تراجع ورجوع للخلف</span>
            </button>
            <button
              type="submit"
              className="bg-sky-600 hover:bg-sky-700 text-white px-5 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md transform active:scale-95 transition-all font-black"
            >
              <CheckCircle2 className="w-4 h-4" />
              تأكيد واعتماد سند قبض وتوريد المبلغ للحساب المستهدف
            </button>
          </div>
        </form>
      )}

      {/* Disbursement Voucher Form Box */}
      {showDisbursementForm && (
        <form id="disbursement-voucher-form" onSubmit={submitDisbursement} className="bg-emerald-50/50 border border-emerald-200 p-5 rounded-2xl mt-5 mb-5 space-y-4 animate-slide-down print:hidden">
          <div className="flex items-center justify-between gap-4 border-b border-emerald-100 pb-2">
            <div className="flex items-center gap-2 text-emerald-950 font-black text-xs">
              <Wallet className="w-4.5 h-4.5 text-emerald-600" />
              <span>نافذة إصدار سند صرف مالي وتسوية مستحقات الجهات (صرف فوري من الخزينة/البنك)</span>
            </div>
            
            {/* Top Back/Close Button */}
            <button
              type="button"
              onClick={() => setShowDisbursementForm(false)}
              className="text-[10px] bg-white text-emerald-955 text-emerald-900 border border-emerald-250 px-3 py-1.5 rounded-xl hover:bg-emerald-100/50 font-bold flex items-center gap-1 transition cursor-pointer select-none shrink-0"
            >
              <ChevronLeft className="w-3.5 h-3.5 rotate-180 text-emerald-600" />
              <span>رجوع للخلف ×</span>
            </button>
          </div>

          {disburseError && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 text-xs p-3 rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4.5 h-4.5 text-rose-600 shrink-0" />
              <span>{disburseError}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Input 1: Source */}
            <div>
              <label className="block text-[10px] font-bold text-slate-700 mb-1">مصدر صرف الأموال (الخزينة/البنك)</label>
              <select
                value={disburseSource}
                onChange={(e) => setDisburseSource(e.target.value)}
                className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-emerald-500 font-sans"
                required
              >
                <option value="10100">صندوق النقدية العام (الخزينة) - رصيد: { (accountBalances['10100']?.netBalance || 0).toLocaleString() } ريال</option>
                <option value="10200">حساب البنك الجاري (الحوالات) - رصيد: { (accountBalances['10200']?.netBalance || 0).toLocaleString() } ريال</option>
              </select>
            </div>

            {/* Input 2: Target Recipient selection */}
            <div>
              <label className="block text-[10px] font-bold text-slate-700 mb-1">الجهة أو الحساب المستلم للمستحقات</label>
              <select
                value={disburseTarget}
                onChange={(e) => {
                  setDisburseTarget(e.target.value);
                  // Default fill supplier id if selected
                  if (e.target.value === 'crusher' && suppliers.length > 0) {
                    setDisburseSupplierId(suppliers[0].id);
                  }
                }}
                className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-emerald-500 font-sans"
                required
              >
                <option value="20300">صندوق الركاز (الزكاة الشرعية) - كود 20300</option>
                <option value="20400">الهيئة العامة للكسارات - كود 20400</option>
                <option value="20500">المحور والرقابة الميدانية - كود 20500</option>
                <option value="40200">أجور مكتب التوزيع والعاملين - كود 40200</option>
                <option value="50300">أجور ومستحقات الموظفين والمصاريف الإدارية والعمومية - كود 50300</option>
                <option value="crusher">أصحاب الكسارات (الموردين الشركاء)</option>
              </select>
            </div>

            {/* Conditional Input 2b: Supplier Select */}
            {disburseTarget === 'crusher' ? (
              <div>
                <label className="block text-[10px] font-bold text-slate-700 mb-1">اختيار المورد المستفيد (صاحب الكسارة)</label>
                <select
                  value={disburseSupplierId}
                  onChange={(e) => setDisburseSupplierId(e.target.value)}
                  className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-emerald-500 font-sans"
                  required
                >
                  <option value="">-- اختر صاحب الكسارة --</option>
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>{s.name} (المستحق المتبقي: {s.balance.toLocaleString()} ريال)</option>
                  ))}
                </select>
              </div>
            ) : (
              <div>
                <label className="block text-[10px] font-bold text-slate-700 mb-1">الرقم المرجعي للسند (اختياري)</label>
                <input
                  type="text"
                  value={disburseReference}
                  onChange={(e) => setDisburseReference(e.target.value)}
                  placeholder="مثال: DSB-9021"
                  className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-emerald-500 font-sans text-left"
                />
              </div>
            )}
          </div>

          {/* Quick Balance Status Ribbon and Autofill Trigger */}
          <div className="bg-emerald-50 border border-emerald-100 p-3.5 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <span className="text-[10px] text-slate-500 block">الحصيلة المستحقة غير المسواة حالياً في النظام للجهة المحددة:</span>
              <span className="text-xs md:text-sm font-black text-emerald-950">
                {disburseTarget === 'crusher' ? (
                  <>
                    {(() => {
                      const matched = suppliers.find(s => s.id === disburseSupplierId);
                      return matched ? `${matched.name}: ${matched.balance.toLocaleString()} ريال` : 'الرجاء اختيار مورد';
                    })()}
                  </>
                ) : (
                  <>
                    {(() => {
                      const name = chartOfAccounts.find(a => a.code === disburseTarget)?.name || 'الحساب';
                      const bal = accountBalances[disburseTarget]?.netBalance || 0;
                      return `${name}: ${bal.toLocaleString()} ريال يمني دائن`;
                    })()}
                  </>
                )}
              </span>
            </div>
            
            <button
              type="button"
              onClick={() => {
                let targetBalance = 0;
                if (disburseTarget === 'crusher') {
                  const matched = suppliers.find(s => s.id === disburseSupplierId);
                  targetBalance = matched ? matched.balance : 0;
                } else {
                  targetBalance = accountBalances[disburseTarget]?.netBalance || 0;
                }
                setDisburseAmount(targetBalance > 0 ? targetBalance : 0);
              }}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] px-3 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              تعبئة كامل المبلغ المستحق للصرف تلقائياً
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-700 mb-1">المبلغ المراد صرفه (ريال)</label>
              <input
                type="number"
                value={disburseAmount || ''}
                onChange={(e) => setDisburseAmount(Math.max(0, parseFloat(e.target.value) || 0))}
                className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-emerald-500 font-sans font-bold text-emerald-700"
                placeholder="أدخل قيمة الصرف بالريال"
                min="1"
                required
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-700 mb-1">تاريخ العملية</label>
              <input
                type="date"
                value={disburseDate}
                onChange={(e) => setDisburseDate(e.target.value)}
                className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-emerald-500 font-sans"
                required
              />
            </div>

            {disburseTarget === 'crusher' && (
              <div>
                <label className="block text-[10px] font-bold text-slate-700 mb-1">الرقم المرجعي للسند (اختياري)</label>
                <input
                  type="text"
                  value={disburseReference}
                  onChange={(e) => setDisburseReference(e.target.value)}
                  placeholder="مثال: DSB-9021"
                  className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-emerald-500 font-sans text-left"
                />
              </div>
            )}
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-700 mb-1">بيان سند الصرف والشرح التفصيلي للقد</label>
            <textarea
              value={disburseDesc}
              onChange={(e) => setDisburseDesc(e.target.value)}
              placeholder="مثال: صرف كامل مستحقات صندوق الركاز عن زكاة الكري حتى تاريخ اليوم بموجب شيك رقم..."
              rows={2}
              className="w-full text-xs font-medium p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="flex justify-end gap-2 text-xs font-bold pt-2">
            <button
              type="button"
              onClick={() => setShowDisbursementForm(false)}
              className="px-4 py-2 text-slate-700 hover:bg-slate-200 bg-slate-100 rounded-xl font-extrabold flex items-center gap-1.5 transition cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5 rotate-180" />
              <span>تراجع ورجوع للخلف</span>
            </button>
            <button
              type="submit"
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md transform active:scale-95 transition-all"
            >
              <CheckCircle2 className="w-4 h-4" />
              تأكيد واعتماد مستند صرف المبلغ للجهة المستفيدة
            </button>
          </div>
        </form>
      )}

      {/* Manual Entry Form Box */}
      {showEntryForm && (
        <form id="accounting-journal-form" onSubmit={submitJournalEntry} className="bg-indigo-50/50 border border-indigo-200 p-5 rounded-2xl mt-5 mb-5 space-y-4 animate-slide-down print:hidden">
          <div className="flex items-center justify-between gap-4 border-b border-indigo-100 pb-2">
            <div className="flex items-center gap-2 text-indigo-950 font-bold text-xs">
              <Scale className="w-4 h-4 text-indigo-600" />
              <span>تسجيل قيد محاسبي يدوي معتمد (سند تسوية أو ترحيل نقدية / مصاريف)</span>
            </div>
            
            {/* Top Back/Close Button */}
            <button
              type="button"
              onClick={() => setShowEntryForm(false)}
              className="text-[10px] bg-white text-indigo-955 text-indigo-900 border border-indigo-250 px-3 py-1.5 rounded-xl hover:bg-indigo-100/50 font-bold flex items-center gap-1 transition cursor-pointer select-none shrink-0"
            >
              <ChevronLeft className="w-3.5 h-3.5 rotate-180 text-indigo-600" />
              <span>رجوع للخلف ×</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-700 mb-1">تاريخ المعاملة المالية</label>
              <input
                type="date"
                value={formDate}
                onChange={(e) => setFormDate(e.target.value)}
                className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-indigo-505 focus:ring-indigo-500 font-sans"
                required
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-700 mb-1">الرقم المرجعي / رقم السند</label>
              <input
                type="text"
                value={formReference}
                onChange={(e) => setFormReference(e.target.value)}
                placeholder="مثال: Bank-293"
                className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-indigo-505 focus:ring-indigo-500 font-sans text-left"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-700 mb-1">بيان تفصيلي للقيد المحاسبي</label>
              <input
                type="text"
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
                placeholder="توضيح كامل للمصاريف أو زيادة الحصص..."
                className="w-full text-xs font-semibold p-2.5 border rounded-xl bg-white focus:ring-1 focus:ring-indigo-505 focus:ring-indigo-500 font-sans"
                required
              />
            </div>
          </div>

          {/* Lines Table */}
          <div className="overflow-x-auto border border-indigo-100 rounded-xl bg-white p-2">
            <table className="w-full min-w-[640px] text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-700 text-right">
                  <th className="p-2 text-right">الحساب الدفتري المتأثر</th>
                  <th className="p-2 text-left bg-emerald-50 text-emerald-900 w-28">مدين (+) Debit</th>
                  <th className="p-2 text-left bg-amber-50 text-amber-900 w-28">دائن (-) Credit</th>
                  <th className="p-2 text-right">ملاحظة فرعية للسطر</th>
                  <th className="p-2 text-center w-12">خيارات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {formItems.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50">
                    <td className="p-2">
                      <select
                        value={item.accountCode}
                        onChange={(e) => handleItemChange(idx, 'accountCode', e.target.value)}
                        className="w-full p-2 border border-slate-200 rounded-lg text-xs font-semibold"
                      >
                        {chartOfAccounts.map(acc => (
                          <option key={acc.code} value={acc.code}>
                            {acc.code} - {acc.name} ({acc.category === 'Asset' ? 'أصول' : acc.category === 'Liability' ? 'لتزامات' : acc.category === 'Equity' ? 'حقوق ملكية' : acc.category === 'Revenue' ? 'إيرادات' : 'مصاريف'})
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="p-1 bg-emerald-50/20">
                      <input
                        type="number"
                        placeholder="0"
                        value={item.debit || ''}
                        onChange={(e) => handleItemChange(idx, 'debit', e.target.value)}
                        className="w-full p-2 border border-slate-200 rounded-lg text-xs font-mono text-left bg-white text-emerald-700 font-bold"
                        min="0"
                        step="0.01"
                      />
                    </td>
                    <td className="p-1 bg-amber-50/20">
                      <input
                        type="number"
                        placeholder="0"
                        value={item.credit || ''}
                        onChange={(e) => handleItemChange(idx, 'credit', e.target.value)}
                        className="w-full p-2 border border-slate-200 rounded-lg text-xs font-mono text-left bg-white text-amber-700 font-bold"
                        min="0"
                        step="0.01"
                      />
                    </td>
                    <td className="p-1">
                      <input
                        type="text"
                        placeholder="ملاحظات توضيحية..."
                        value={item.note || ''}
                        onChange={(e) => handleItemChange(idx, 'note', e.target.value)}
                        className="w-full p-2 border border-slate-200 rounded-lg text-xs"
                      />
                    </td>
                    <td className="p-1 text-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveRow(idx)}
                        className="text-rose-650 text-rose-500 hover:text-rose-700 p-2"
                        title="حذف هذا السطر"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-between items-center bg-indigo-50 p-2 rounded-xl">
            <button
              type="button"
              onClick={handleAddRow}
              className="text-indigo-700 hover:text-indigo-900 font-bold text-xs flex items-center gap-1 px-3 py-1.5 bg-indigo-100 hover:bg-indigo-200 rounded-lg transition-colors"
            >
              <Plus className="w-4 h-4" />
              إضافة صف إضافي للحسابات الفرعية
            </button>

            {/* Sum Indicator */}
            <div className="flex gap-4 text-xs">
              <div className="bg-emerald-100 p-2 rounded-lg text-emerald-950">
                إجمالي المدين: <span className="font-bold font-mono">{formItems.reduce((s,i)=>s+i.debit, 0).toLocaleString()} ريال</span>
              </div>
              <div className="bg-amber-100 p-2 rounded-lg text-amber-950">
                إجمالي الدائن: <span className="font-bold font-mono">{formItems.reduce((s,i)=>s+i.credit, 0).toLocaleString()} ريال</span>
              </div>
            </div>
          </div>

          {formError && (
            <div className="bg-amber-50 border border-amber-300 text-amber-900 rounded-xl p-3 flex items-start gap-2.5 text-xs animate-pulse">
              <AlertCircle className="w-4 h-4 text-amber-600 mt-0.5" />
              <span>{formError}</span>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => {
                setShowEntryForm(false);
                setFormError(null);
              }}
              className="px-4 py-2 text-slate-700 hover:bg-slate-200 bg-slate-100 rounded-xl font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5 rotate-180" />
              <span>تراجع ورجوع للخلف</span>
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs"
            >
              ترحيل السند وحفظ القيد دفترياً
            </button>
          </div>
        </form>
      )}

      {/* Accounting Subnav Controls */}
      <div className="flex border-b border-indigo-100 mt-4 overflow-x-auto gap-2 py-2 print:hidden" id="accounting-sub-navigation">
        <button
          onClick={() => setAccountingSubTab('overview')}
          className={`flex items-center gap-1.5 px-3 py-2 text-xs font-black rounded-lg transition-all ${
            accountingSubTab === 'overview' ? 'bg-indigo-650 bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          لوحة المؤشرات والتحليل المالي
        </button>

        <button
          onClick={() => setAccountingSubTab('journal')}
          className={`flex items-center gap-1.5 px-3 py-2 text-xs font-black rounded-lg transition-all ${
            accountingSubTab === 'journal' ? 'bg-indigo-650 bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <FileText className="w-4 h-4" />
          اليومية العامة والقيود المترابطة (Journal)
        </button>

        <button
          onClick={() => setAccountingSubTab('ledger')}
          className={`flex items-center gap-1.5 px-3 py-2 text-xs font-black rounded-lg transition-all ${
            accountingSubTab === 'ledger' ? 'bg-indigo-650 bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-4 h-4" />
          دفتر الأستاذ العام للحسابات (GL Ledger)
        </button>

        {currentRole !== 'Cashier' && (
          <>
            <button
              onClick={() => setAccountingSubTab('trial_balance')}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-black rounded-lg transition-all ${
                accountingSubTab === 'trial_balance' ? 'bg-indigo-650 bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Scale className="w-4 h-4" />
              ميزان المراجعة التجريبي للتوازن (Trial Balance)
            </button>

            <button
              onClick={() => setAccountingSubTab('statements')}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-black rounded-lg transition-all ${
                accountingSubTab === 'statements' ? 'bg-indigo-650 bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Landmark className="w-4 h-4" />
              القوائم المالية الختامية (Income / Balance sheet)
            </button>
          </>
        )}
      </div>

      {/* ========================================================= */}
      {/* 1. OVERVIEW SCREEN */}
      {/* ========================================================= */}
      {accountingSubTab === 'overview' && (
        <div className="mt-5 space-y-6">
          {/* Key accounting balances cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Asset 1: Box cash */}
            <div className="bg-slate-50 border p-4 rounded-2xl">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-500 font-bold block">10100 - صندوق الخزينة والمحفظة</span>
                <Wallet className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="text-lg font-black text-slate-900 mt-2 font-mono">
                {(accountBalances['10100']?.netBalance || 0).toLocaleString()} <span className="text-[10px] font-sans font-medium text-slate-500">ريال</span>
              </p>
              <div className="flex gap-2 text-[9px] text-slate-450 text-slate-500 mt-1">
                <span>المدخلات: {accountBalances['10100']?.debitsSum.toLocaleString()}</span>
                <span>•</span>
                <span>الكشوفات: {accountBalances['10100']?.creditsSum.toLocaleString()}</span>
              </div>
            </div>

            {/* Asset 2: Bank cash */}
            <div className="bg-slate-50 border p-4 rounded-2xl">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-500 font-bold block">10200 - النقدية في البنوك</span>
                <Landmark className="w-4 h-4 text-indigo-600" />
              </div>
              <p className="text-lg font-black text-slate-900 mt-2 font-mono">
                {(accountBalances['10200']?.netBalance || 0).toLocaleString()} <span className="text-[10px] font-sans font-medium text-slate-500">ريال</span>
              </p>
              <div className="flex gap-2 text-[9px] text-slate-450 text-slate-500 mt-1">
                <span>المدين: {accountBalances['10200']?.debitsSum.toLocaleString()}</span>
                <span>•</span>
                <span>الدائن: {accountBalances['10200']?.creditsSum.toLocaleString()}</span>
              </div>
            </div>

            {/* Asset 3: Receivables */}
            <div className="bg-slate-50 border p-4 rounded-2xl">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-500 font-bold block">10300 - إجمالي ذمم العملاء المدينة</span>
                <ArrowDownLeft className="w-4 h-4 text-cyan-600" />
              </div>
              <p className="text-lg font-black text-slate-900 mt-2 font-mono">
                {(accountBalances['10300']?.netBalance || 0).toLocaleString()} <span className="text-[10px] font-sans font-medium text-slate-500">ريال</span>
              </p>
              <p className="text-[9px] text-slate-400 mt-1">مبالغ المبيعات المستلمة والمستحقة دفترياً</p>
            </div>

            {/* Liability 1: Payables (Crushers) */}
            <div className="bg-slate-50 border p-4 rounded-2xl">
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-500 font-bold block">20100 - ذمم الكسارات الدائنة</span>
                <ArrowUpRight className="w-4 h-4 text-rose-600" />
              </div>
              <p className="text-lg font-black text-rose-950 mt-2 font-mono">
                {(accountBalances['20100']?.netBalance || 0).toLocaleString()} <span className="text-[10px] font-sans font-medium text-slate-500">ريال</span>
              </p>
              <p className="text-[9px] text-slate-400 mt-1">المبالغ غير المسواة المتبقية لشركاء الكسارات</p>
            </div>
          </div>

          {/* Automatic Distribution of 1100 RY Section */}
          <div className="bg-slate-900 border border-slate-850 text-white rounded-2xl p-5 shadow-lg">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 border-b border-slate-800 pb-3.5 mb-4">
              <div>
                <h4 className="font-extrabold text-xs md:text-sm flex items-center gap-2 text-slate-100">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  لوحة التوزيع التلقائي لصافي مبيعات الكري والوساطة (1,100 ريال / م³)
                </h4>
                <p className="text-[10px] text-slate-400 mt-1">نظام تكسيم وفرز فوري بعد كل عملية بيع معتمدة على الحسابات الدفترية المخصصة</p>
              </div>
              <div className="bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-xl text-center self-stretch md:self-auto">
                <span className="text-[8px] font-bold text-slate-400 block whitespace-nowrap">إجمالي المقدار الموزع تلقائياً</span>
                <span className="text-xs md:text-sm font-bold text-emerald-400 font-mono">
                  {((accountBalances['20300']?.netBalance || 0) + (accountBalances['20400']?.netBalance || 0) + (accountBalances['20500']?.netBalance || 0) + (accountBalances['40200']?.netBalance || 0)).toLocaleString()} ريال
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              {/* Box 1: Rikaz */}
              <div className="bg-slate-800/60 border border-slate-800 p-3.5 rounded-xl hover:bg-slate-800 transition-all">
                <div className="flex justify-between items-start">
                  <span className="bg-emerald-500/10 text-emerald-400 text-[9px] font-bold px-2 py-0.5 rounded-full">500 ريال / م³</span>
                  <span className="text-[9px] font-mono text-slate-500">20300</span>
                </div>
                <div className="mt-2.5">
                  <span className="text-[10px] font-bold text-slate-400">الركاز (زكاة مبيعات الكري)</span>
                  <p className="text-base font-black text-white mt-1 font-mono">
                    {(accountBalances['20300']?.netBalance || 0).toLocaleString()} <span className="text-[10px] font-sans font-medium text-slate-400">ريال</span>
                  </p>
                </div>
                <div className="w-full bg-slate-750 bg-slate-700 h-1.5 rounded-full mt-3 overflow-hidden">
                  <div className="bg-emerald-500 h-full" style={{ width: '100%' }}></div>
                </div>
              </div>

              {/* Box 2: Al-Hai'ah */}
              <div className="bg-slate-800/60 border border-slate-800 p-3.5 rounded-xl hover:bg-slate-800 transition-all">
                <div className="flex justify-between items-start">
                  <span className="bg-indigo-500/10 text-indigo-400 text-[9px] font-bold px-2 py-0.5 rounded-full">200 ريال / م³</span>
                  <span className="text-[9px] font-mono text-slate-500">20400</span>
                </div>
                <div className="mt-2.5">
                  <span className="text-[10px] font-bold text-slate-400">حصص الهيئة التنظيمية العامة</span>
                  <p className="text-base font-black text-white mt-1 font-mono">
                    {(accountBalances['20400']?.netBalance || 0).toLocaleString()} <span className="text-[10px] font-sans font-medium text-slate-400">ريال</span>
                  </p>
                </div>
                <div className="w-full bg-slate-750 bg-slate-700 h-1.5 rounded-full mt-3 overflow-hidden">
                  <div className="bg-indigo-400 h-full" style={{ width: '100%' }}></div>
                </div>
              </div>

              {/* Box 3: Al-Mihwar */}
              <div className="bg-slate-800/60 border border-slate-800 p-3.5 rounded-xl hover:bg-slate-800 transition-all">
                <div className="flex justify-between items-start">
                  <span className="bg-amber-500/10 text-amber-400 text-[9px] font-bold px-2 py-0.5 rounded-full">200 ريال / م³</span>
                  <span className="text-[9px] font-mono text-slate-500">20500</span>
                </div>
                <div className="mt-2.5">
                  <span className="text-[10px] font-bold text-slate-400">حصص المحور والرقابة الميدانية</span>
                  <p className="text-base font-black text-white mt-1 font-mono">
                    {(accountBalances['20500']?.netBalance || 0).toLocaleString()} <span className="text-[10px] font-sans font-medium text-slate-400">ريال</span>
                  </p>
                </div>
                <div className="w-full bg-slate-750 bg-slate-700 h-1.5 rounded-full mt-3 overflow-hidden">
                  <div className="bg-amber-400 h-full" style={{ width: '100%' }}></div>
                </div>
              </div>

              {/* Box 4: Office work / salaries */}
              <div className="bg-slate-800/60 border border-slate-800 p-3.5 rounded-xl hover:bg-slate-800 transition-all">
                <div className="flex justify-between items-start">
                  <span className="bg-sky-500/10 text-sky-400 text-[9px] font-bold px-2 py-0.5 rounded-full">200 ريال / م³</span>
                  <span className="text-[9px] font-mono text-slate-500">40200</span>
                </div>
                <div className="mt-2.5">
                  <span className="text-[10px] font-bold text-slate-400">أجور مكتب التوزيع والعاملين</span>
                  <p className="text-base font-black text-white mt-1 font-mono">
                    {(accountBalances['40200']?.netBalance || 0).toLocaleString()} <span className="text-[10px] font-sans font-medium text-slate-400">ريال</span>
                  </p>
                </div>
                <div className="w-full bg-slate-750 bg-slate-700 h-1.5 rounded-full mt-3 overflow-hidden">
                  <div className="bg-sky-400 h-full" style={{ width: '100%' }}></div>
                </div>
              </div>
            </div>
            
            <div className="mt-3.5 flex flex-col sm:flex-row items-center justify-between text-[10px] text-slate-400 bg-slate-950 p-2.5 rounded-xl gap-2 font-black leading-relaxed">
              <span>💡 إرشاد الحسابات:</span>
              <span className="text-right">تدرج حصة صاحب الكسارات المحددة تلقائياً بمعدل <strong className="text-emerald-400">5900 ريال / م³</strong> لحساب الكسارات الدائنة بمجرد اعتماد المبيعات.</span>
            </div>
          </div>

          {/* Audit Shield details */}
          <div className="bg-indigo-50 rounded-2xl border border-indigo-100 p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <div className="flex items-center gap-1.5 text-indigo-950 font-sans font-black text-sm">
                <ShieldCheck className="w-5 h-5 text-indigo-700" />
                توازن النظام المحاسبي الكلي بميزان الجرد المستمر
              </div>
              <p className="text-xs text-indigo-900 mt-1.5 leading-relaxed max-w-2xl">
                ميزان الحسابات متوافق بالكامل. تتبنى الحركات المالية والمبيعات المسجلة كشف الحساب التلقائي الثنائي لحصة الكسارة والمقر (الرسوم والعمولات) لتجنب التضارب البشري.
              </p>
            </div>
            <div className="bg-white rounded-xl py-2 px-3.5 border border-indigo-200 flex flex-col items-center">
              <span className="text-[9px] text-slate-500 font-bold font-sans">تراكم المدين والدائن في اليومية</span>
              <span className="text-sm font-black text-indigo-900 font-mono mt-0.5">
                {totals.debit.toLocaleString()} ريال
              </span>
            </div>
          </div>

          {/* Chart of Accounts Interactive Visual Table in overview */}
          <div>
            <h3 className="font-bold text-slate-800 text-sm mb-3">دليل الحسابات الرسمي المعتمد (Chart of Accounts)</h3>
            <div className="overflow-x-auto border border-slate-200 rounded-2xl">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-900 text-white font-black">
                    <th className="p-3">رمز الحساب</th>
                    <th className="p-3">اسم الحساب الدفتري</th>
                    <th className="p-3">التصنيف المالي</th>
                    <th className="p-3">الرصيد الاعتيادي</th>
                    <th className="p-3 text-left">الرصيد الحالي المستحق</th>
                    <th className="p-3">طبيعة المعاملة والمتابعة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {chartOfAccounts.map(acc => {
                    const bal = accountBalances[acc.code]?.netBalance || 0;
                    return (
                      <tr key={acc.code} className="hover:bg-slate-50">
                        <td className="p-3 font-mono font-bold text-indigo-900">{acc.code}</td>
                        <td className="p-3 font-bold text-slate-800">{acc.name}</td>
                        <td className="p-3">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            acc.category === 'Asset' ? 'bg-sky-50 text-sky-800' :
                            acc.category === 'Liability' ? 'bg-rose-50 text-rose-800' :
                            acc.category === 'Equity' ? 'bg-amber-50 text-amber-800' :
                            acc.category === 'Revenue' ? 'bg-emerald-50 text-emerald-800' :
                            'bg-slate-50 text-slate-800'
                          }`}>
                            {acc.category === 'Asset' ? 'أصول متداولة / ثابتة' :
                             acc.category === 'Liability' ? 'التزامات قصيرة الأجل' :
                             acc.category === 'Equity' ? 'حقوق ملكية ورأس مال' :
                             acc.category === 'Revenue' ? 'إيرادات مبيعات وعمولات' :
                             'مصاريف تشغيل وإدارة'}
                          </span>
                        </td>
                        <td className="p-3 text-slate-500">{acc.balanceType === 'Debit' ? 'مدين (+)' : 'دائن (-)'}</td>
                        <td className="p-3 text-left font-mono font-black" style={{ color: bal > 0 ? '#1e293b' : '#64748b' }}>
                          {bal.toLocaleString()} ريال
                        </td>
                        <td className="p-3 text-slate-500 font-sans">{acc.description}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 2. GENERAL JOURNAL (DAILY BOOK) */}
      {/* ========================================================= */}
      {accountingSubTab === 'journal' && (
        <div className="mt-5 space-y-4" id="accounting-journal-records">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-bold text-slate-800 text-sm">كشف اليومية العامة (General Journal Ledger Ledger)</h3>
              <p className="text-[10px] text-slate-400">يسجل هذا الكشف ويوثق تفاصيل الخصوم والعمولات وقيود اليومية التلقائية واليدوية المزدوجة.</p>
            </div>
            <button
              onClick={() => handlePrint('journal')}
              className="bg-slate-100 hover:bg-slate-200 border text-slate-700 font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-colors print:hidden"
            >
              <Printer className="w-4 h-4" />
              طباعة وتصدير اليومية العامة (PDF)
            </button>
          </div>

          <div id="print-area-journal" className="space-y-4">
            {allJournals.length === 0 ? (
              <div className="bg-slate-50 rounded-2xl p-8 text-center text-slate-500 text-xs">
                لا توجد قيود أو معاملات تدوين حالية في دفتر اليومية.
              </div>
            ) : (
              allJournals.map((entry) => (
                <div key={entry.id} className="border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-xs">
                  {/* Journal metadata bar */}
                  <div className="bg-slate-50 p-3 md:px-4 flex justify-between items-center text-xs border-b border-slate-100">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono bg-slate-900 text-white font-bold px-2.5 py-1 rounded-md">{entry.id}</span>
                      <span className="text-slate-500 font-mono font-bold">{entry.date}</span>
                      <span className="text-slate-400">•</span>
                      <span className="text-slate-500 font-bold font-sans">المرجع: {entry.reference}</span>
                      {entry.isSystemGenerated && (
                        <span className="bg-indigo-50 border border-indigo-100 text-indigo-700 text-[9px] px-2 py-0.5 rounded-lg font-black">
                          قيد تلقائي ذكي
                        </span>
                      )}
                    </div>
                    {/* Delete handler for manual edits only */}
                    {!entry.isSystemGenerated && currentRole === 'Admin' && (
                      <button
                        onClick={() => deleteManualEntry(entry.id)}
                        className="text-rose-500 hover:text-rose-700 font-bold text-[10px] flex items-center gap-1 hover:bg-rose-50 px-2 py-1 rounded-lg print:hidden"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        حذف القيد اليدوي
                      </button>
                    )}
                  </div>

                  {/* Description text */}
                  <div className="bg-white p-3 font-semibold text-slate-900 text-xs border-b border-slate-105 border-slate-100 leading-relaxed font-sans">
                    {entry.description}
                  </div>

                  {/* Journal splits (Table layout) */}
                  <table className="w-full text-right text-xs">
                    <thead>
                      <tr className="bg-slate-100/50 text-slate-600 font-bold border-b border-slate-100">
                        <th className="p-2 w-48 font-bold text-right">رقم الحساب واسمه</th>
                        <th className="p-2 w-32 font-mono text-left bg-emerald-50/10">مدين (+) Debit</th>
                        <th className="p-2 w-32 font-mono text-left bg-amber-50/10">دائن (-) Credit</th>
                        <th className="p-2 font-sans">تفاصيل المعاملة السطرية والتحليل</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {entry.items.map((item, idx) => {
                        const accountName = chartOfAccounts.find(c => c.code === item.accountCode)?.name || 'حساب فرعي';
                        return (
                          <tr key={idx} className="hover:bg-slate-50/30">
                            <td className="p-2 pl-4">
                              <span className="font-mono text-indigo-900 font-black tracking-wide ml-2">{item.accountCode}</span>
                              <span className="text-slate-800 font-semibold">{accountName}</span>
                            </td>
                            <td className="p-2 font-mono text-left font-black text-emerald-800 bg-emerald-50/5">
                              {item.debit > 0 ? item.debit.toLocaleString() : '-'}
                            </td>
                            <td className="p-2 font-mono text-left font-black text-amber-800 bg-amber-50/5">
                              {item.credit > 0 ? item.credit.toLocaleString() : '-'}
                            </td>
                            <td className="p-2 text-slate-500 font-sans italic text-[10px]">{item.note || '-'}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 3. GENERAL LEDGER (GL ACCREDITED) */}
      {/* ========================================================= */}
      {accountingSubTab === 'ledger' && (
        <div className="mt-5 space-y-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h3 className="font-bold text-slate-800 text-sm">دفتر الأستاذ العام وتاريخ كشوفات الحسابات</h3>
              <p className="text-[10px] text-slate-400">تتبع تفاصيل حركات Debit و Credit الجارية لكل حساب من الحسابات المدرجة بدليل المنشأة مستقلة.</p>
            </div>
            
            {/* Account Selector filter */}
            <div className="flex items-center gap-2 print:hidden">
              <span className="text-xs font-bold text-slate-700">تصفية الحساب:</span>
              <select
                value={selectedLedgerAccountCode}
                onChange={(e) => setSelectedLedgerAccountCode(e.target.value)}
                className="p-2 border rounded-xl text-xs font-semibold focus:ring-1 focus:ring-indigo-500 bg-white"
              >
                {chartOfAccounts.map(acc => (
                  <option key={acc.code} value={acc.code}>
                    {acc.code} - {acc.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Detailed Account analysis ledger table */}
          {(() => {
            const acc = chartOfAccounts.find(a => a.code === selectedLedgerAccountCode);
            if (!acc) return null;

            // Get all ledger items related to this account
            const ledgerItems: Array<{
              id: string;
              date: string;
              description: string;
              debit: number;
              credit: number;
              remainingBalance: number;
            }> = [];

            // Sort journal entries chronologically to compute running balance correctly
            const chronologicalJournals = [...allJournals].reverse();
            let currentRunningTemp = 0;

            chronologicalJournals.forEach(entry => {
              entry.items.forEach(item => {
                if (item.accountCode === acc.code) {
                  // Running calculation depending on Normal Balance type
                  if (acc.balanceType === 'Debit') {
                    currentRunningTemp += (item.debit - item.credit);
                  } else {
                    currentRunningTemp += (item.credit - item.debit);
                  }

                  ledgerItems.push({
                    id: entry.id,
                    date: entry.date,
                    description: entry.description + (item.note ? ` [${item.note}]` : ''),
                    debit: item.debit,
                    credit: item.credit,
                    remainingBalance: currentRunningTemp
                  });
                }
              });
            });

            // Reverse for top-down display
            ledgerItems.reverse();

            return (
              <div className="space-y-4">
                {/* Visual statistics for specific ledger */}
                <div className="bg-slate-50 border p-4 rounded-xl grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">رصيد الحساب الموحد الحالي</span>
                    <p className="text-base font-black text-slate-900 mt-1 font-mono">
                      {(accountBalances[acc.code]?.netBalance || 0).toLocaleString()} ريال
                    </p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">إجمالي تراكم المدين (+)</span>
                    <p className="text-base font-black text-emerald-800 mt-1 font-mono">
                      {(accountBalances[acc.code]?.debitsSum || 0).toLocaleString()} ريال
                    </p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">إجمالي تراكم الدائن (-)</span>
                    <p className="text-base font-black text-amber-800 mt-1 font-mono">
                      {(accountBalances[acc.code]?.creditsSum || 0).toLocaleString()} ريال
                    </p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">نوع القيد المحاسبي الاعتيادي</span>
                    <p className="text-xs font-black text-indigo-900 mt-2 font-sans">
                      {acc.balanceType === 'Debit' ? 'مدين بطبيعته (أصول ومصروفات)' : 'دائن بطبيعته (التزامات، إيرادات، حقوق)'}
                    </p>
                  </div>
                </div>

                {/* Ledger Table */}
                <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                  <table className="w-full text-right text-xs">
                    <thead>
                      <tr className="bg-slate-900 text-white font-black">
                        <th className="p-3">تاريخ الحركة</th>
                        <th className="p-3">رقم السند المرجعي</th>
                        <th className="p-3">بيان وتفاصيل القيد والترحيل الدفتري</th>
                        <th className="p-3 text-left">المدين (+) Debit</th>
                        <th className="p-3 text-left">الدائن (-) Credit</th>
                        <th className="p-3 text-left">الرصيد الجاري المستحصل</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {ledgerItems.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-slate-500 text-xs">
                            لا توجد حركات تدوين دفتري مرسلة إلى هذا الحساب للمدة المحددة.
                          </td>
                        </tr>
                      ) : (
                        ledgerItems.map((item, index) => (
                          <tr key={index} className="hover:bg-slate-50">
                            <td className="p-3 text-slate-500 font-mono">{item.date}</td>
                            <td className="p-3 font-mono font-bold text-indigo-900">{item.id}</td>
                            <td className="p-3 font-medium text-slate-800 font-sans leading-relaxed">{item.description}</td>
                            <td className="p-3 text-left font-mono font-bold text-emerald-800">
                              {item.debit > 0 ? item.debit.toLocaleString() : '-'}
                            </td>
                            <td className="p-3 text-left font-mono font-bold text-amber-800">
                              {item.credit > 0 ? item.credit.toLocaleString() : '-'}
                            </td>
                            <td className="p-3 text-left font-mono font-black text-slate-900 bg-slate-50/50">
                              {item.remainingBalance.toLocaleString()} ريال
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* ========================================================= */}
      {/* 4. TRIAL BALANCE */}
      {/* ========================================================= */}
      {accountingSubTab === 'trial_balance' && (
        <div className="mt-5 space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-bold text-slate-800 text-sm">ميزان المراجعة التجريبي لتوازن العمليات</h3>
              <p className="text-[10px] text-slate-400">تدقيق إتمام مبدأ القيد المزدوج، حيث يجب أن يتطابق إجمالي الأرصدة المدينة والدائنة بالتمام لضمان عدم وجود خلل برمجي.</p>
            </div>
            <button
              onClick={() => handlePrint('trial_balance')}
              className="bg-slate-100 hover:bg-slate-200 border text-slate-700 font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-colors print:hidden"
            >
              <Printer className="w-4 h-4" />
              طباعة ميزان المراجعة المعتمد
            </button>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-2xl bg-white shadow-xs" id="print-area-trial-balance">
            <table className="w-full text-right text-xs border-collapse">
              <thead>
                <tr className="bg-slate-900 text-white font-black border-b border-slate-700">
                  <th className="p-3 text-right">كود الحساب</th>
                  <th className="p-3 text-right">اسم وتفصيل الحساب المالي</th>
                  <th className="p-3 text-left bg-emerald-950 text-white w-36 font-mono font-bold">مجموع المدين (Debit)</th>
                  <th className="p-3 text-left bg-amber-950 text-white w-36 font-mono font-bold">مجموع الدائن (Credit)</th>
                  <th className="p-3 text-left w-36 font-mono font-bold">مدين (الأرصدة)</th>
                  <th className="p-3 text-left w-36 font-mono font-bold">دائن (الأرصدة)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {chartOfAccounts.map(acc => {
                  const b = accountBalances[acc.code];
                  const hasMovements = b.debitsSum > 0 || b.creditsSum > 0;
                  
                  // Compute balance splits for display column
                  const balDebit = acc.balanceType === 'Debit' ? (b.netBalance > 0 ? b.netBalance : 0) : 0;
                  const balCredit = acc.balanceType === 'Credit' ? (b.netBalance > 0 ? b.netBalance : 0) : 0;

                  return (
                    <tr key={acc.code} className={`hover:bg-slate-50 ${hasMovements ? '' : 'text-slate-400 opacity-60'}`}>
                      <td className="p-3 font-mono font-black text-indigo-900">{acc.code}</td>
                      <td className="p-3 font-bold text-slate-800">{acc.name}</td>
                      <td className="p-3 text-left font-mono font-bold text-emerald-800 bg-emerald-50/20">{b.debitsSum.toLocaleString()}</td>
                      <td className="p-3 text-left font-mono font-bold text-amber-800 bg-amber-50/20">{b.creditsSum.toLocaleString()}</td>
                      <td className="p-3 text-left font-mono font-bold text-slate-900">{balDebit > 0 ? balDebit.toLocaleString() : '-'}</td>
                      <td className="p-3 text-left font-mono font-bold text-slate-900">{balCredit > 0 ? balCredit.toLocaleString() : '-'}</td>
                    </tr>
                  );
                })}
              </tbody>
              
              {/* Totals Summary Row */}
              <tfoot>
                <tr className="bg-slate-900 text-white font-black text-sm">
                  <td colSpan={2} className="p-4 text-right">الإجمالي الكلي الموحد للمطابقة الرياضية</td>
                  <td className="p-4 text-left font-mono">
                    {chartOfAccounts.reduce((sum, acc) => sum + accountBalances[acc.code].debitsSum, 0).toLocaleString()} ريال
                  </td>
                  <td className="p-4 text-left font-mono">
                    {chartOfAccounts.reduce((sum, acc) => sum + accountBalances[acc.code].creditsSum, 0).toLocaleString()} ريال
                  </td>
                  <td className="p-4 text-left font-mono">
                    {chartOfAccounts.reduce((sum, acc) => {
                      const b = accountBalances[acc.code];
                      return sum + (acc.balanceType === 'Debit' ? (b.netBalance > 0 ? b.netBalance : 0) : 0);
                    }, 0).toLocaleString()} ريال
                  </td>
                  <td className="p-4 text-left font-mono">
                    {chartOfAccounts.reduce((sum, acc) => {
                      const b = accountBalances[acc.code];
                      return sum + (acc.balanceType === 'Credit' ? (b.netBalance > 0 ? b.netBalance : 0) : 0);
                    }, 0).toLocaleString()} ريال
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl p-4 text-xs font-sans">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <span className="font-bold">تأكيد التدقيق المالي:</span> ميزان المراجعة متوازن ومكتمل حسابياً بالتمام والكمال بموجب قيود العمولات والتوريدات. كل قيد متوازن دفترياً بنظام القيد المزدوج.
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 5. STATEMENTS (INCOME STATEMENT & BALANCE SHEET) */}
      {/* ========================================================= */}
      {accountingSubTab === 'statements' && (
        <div className="mt-5 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* COLUMN A: Income Statement (قائمة الدخل) */}
            <div className="border border-slate-205 border-slate-200 rounded-2xl p-5 bg-white shadow-xs space-y-4" id="print-area-income-statement">
              <div className="flex justify-between items-center pb-3 border-b">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">قائمة الدخل م³ والأرباح والخسائر المختصرة</h4>
                  <p className="text-[10px] text-slate-400">للفترة المنتهية الجارية (إثبات العائد الصافي)</p>
                </div>
                <button
                  onClick={() => handlePrint('income')}
                  className="p-1 px-2 hover:bg-slate-100 text-slate-700 text-[10px] font-bold border rounded-lg print:hidden"
                >
                  تصدير القائمة
                </button>
              </div>

              <div className="space-y-3 text-xs">
                {/* Revenues */}
                <div className="font-black text-indigo-950 text-xs border-b pb-1">أولاً: الإيرادات التشغيلية المباشرة</div>
                <div className="flex justify-between pl-4 text-slate-700 font-bold">
                  <span>40100 - إيرادات مبيعات وتوريد الكري الإجمالية</span>
                  <span className="font-mono">{(accountBalances['40100']?.netBalance || 0).toLocaleString()} ريال</span>
                </div>
                <div className="flex justify-between pl-4 text-slate-700 font-bold">
                  <span>40200 - إيرادات عمولات التوزيع والوساطة</span>
                  <span className="font-mono">{(accountBalances['40200']?.netBalance || 0).toLocaleString()} ريال</span>
                </div>
                <div className="flex justify-between font-black text-slate-900 bg-slate-50 p-2 rounded-lg">
                  <span>إجمالي الإيرادات التشغيلية المجمعة</span>
                  <span className="font-mono">{totalRevenues.toLocaleString()} ريال</span>
                </div>

                {/* Expenses */}
                <div className="font-black text-rose-950 text-xs border-b pb-1 pt-3">ثانياً: المصاريف والتشغيل والتوريد</div>
                <div className="flex justify-between pl-4 text-slate-700">
                  <span>50100 - تكلفة مبيعات الكري (حصة الكسارة والإنتاج)</span>
                  <span className="font-mono">{(accountBalances['50100']?.netBalance || 0).toLocaleString()} ريال</span>
                </div>
                <div className="flex justify-between pl-4 text-slate-700">
                  <span>50200 - مصاريف نقل ولوجستيات التوريد الفردي</span>
                  <span className="font-mono">{(accountBalances['50200']?.netBalance || 0).toLocaleString()} ريال</span>
                </div>
                <div className="flex justify-between pl-4 text-slate-700">
                  <span>50300 - مصاريف إدارية وصيانة السيلوهات والترتيبات</span>
                  <span className="font-mono">{(accountBalances['50300']?.netBalance || 0).toLocaleString()} ريال</span>
                </div>
                <div className="flex justify-between font-black text-rose-950 bg-rose-50 p-2 rounded-lg">
                  <span>إجمالي المصاريف والتشغيل الكلّي</span>
                  <span className="font-mono">{totalExpenses.toLocaleString()} ريال</span>
                </div>

                {/* Net Income */}
                <div className="border-t-2 border-double border-slate-900 pt-3 flex justify-between font-black text-sm text-slate-950 bg-indigo-50 p-3 rounded-lg mt-4">
                  <span>صافي الأرباح التشغيلية المحققة (Net Income)</span>
                  <span className="font-mono text-indigo-900">{netOperatingIncome.toLocaleString()} ريال</span>
                </div>
              </div>
            </div>

            {/* COLUMN B: Balance Sheet (الميزانية العمومية) */}
            <div className="border border-slate-205 border-slate-200 rounded-2xl p-5 bg-white shadow-xs space-y-4" id="print-area-balance-sheet">
              <div className="flex justify-between items-center pb-3 border-b">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">قائمة المركز المالي والميزانية العمومية المقارنة</h4>
                  <p className="text-[10px] text-slate-400">تقييم توازن الأصول الكلية مقارنة بالالتزامات وحقوق الشركاء</p>
                </div>
                <button
                  onClick={() => handlePrint('balance_sheet')}
                  className="p-1 px-2 hover:bg-slate-100 text-slate-700 text-[10px] font-bold border rounded-lg print:hidden"
                >
                  تصدير القائمة
                </button>
              </div>

              <div className="space-y-4 text-xs font-sans">
                {/* 1. Assets Column */}
                <div>
                  <div className="font-black text-indigo-950 text-xs border-b pb-1 mb-2">أولاً: الأصول الكلية المتاحة (Assets)</div>
                  <div className="space-y-2 pl-2">
                    {assetsList.map(a => (
                      <div key={a.code} className="flex justify-between text-slate-700">
                        <span>{a.code} - {a.name}</span>
                        <span className="font-mono font-bold">{(accountBalances[a.code]?.netBalance || 0).toLocaleString()} ريال</span>
                      </div>
                    ))}
                    <div className="flex justify-between font-black text-sky-950 bg-sky-50 p-2 rounded-lg mt-1">
                      <span>إجمالي الأصول والمركز المالي الإيجابي</span>
                      <span className="font-mono">{totalAssets.toLocaleString()} ريال</span>
                    </div>
                  </div>
                </div>

                {/* 2. Liabilities + Equity Column */}
                <div>
                  <div className="font-black text-indigo-950 text-xs border-b pb-1 mb-2">ثانياً: الخصوم وحقوق الملكية (Liabilities & Equity)</div>
                  <div className="space-y-2 pl-2">
                    {/* Liabilities */}
                    {liabilitiesList.map(a => (
                      <div key={a.code} className="flex justify-between text-slate-750 text-slate-600">
                        <span>{a.code} - {a.name}</span>
                        <span className="font-mono">{(accountBalances[a.code]?.netBalance || 0).toLocaleString()} ريال</span>
                      </div>
                    ))}
                    <div className="font-bold text-[10px] text-slate-500 pt-1.5 pb-0.5">حقوق الملكية وتراكم الأرباح:</div>
                    {/* Capital */}
                    <div className="flex justify-between text-slate-600">
                      <span>30100 - رأس المال المستثمر</span>
                      <span className="font-mono">{(accountBalances['30100']?.netBalance || 0).toLocaleString()} ريال</span>
                    </div>
                    {/* Retained Earnings (including current year income) */}
                    <div className="flex justify-between text-slate-600">
                      <span>30200 - الأرباح المدورة والأرباح الجارية</span>
                      <span className="font-mono">{dynamicRetainedEarnings.toLocaleString()} ريال</span>
                    </div>

                    <div className="flex justify-between font-black text-amber-950 bg-amber-50 p-2 rounded-lg mt-2">
                      <span>إجمالي الالتزامات وحقوق الملكية الشاملة</span>
                      <span className="font-mono">{(totalLiabilities + totalEquity).toLocaleString()} ريال</span>
                    </div>
                  </div>
                </div>

                {/* Equation validation status */}
                <div className={`p-2.5 rounded-lg text-[10px] flex items-center justify-between font-sans ${isBalanceSheetBalanced ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'}`}>
                  <span className="font-bold">المعادلة المحاسبية الموازنة (الأصول = الخصوم + حقوق الملكية):</span>
                  <span className="font-black font-mono">
                    {isBalanceSheetBalanced ? '✓ متزن ومطابق' : `🚨 غير متوافق - الفارق: ${(totalAssets - (totalLiabilities + totalEquity)).toLocaleString()} ريال`}
                  </span>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
