import React, { useState } from 'react';
import { User, Supplier, InventoryItem, PriceItem, Order } from '../types';
import { ShoppingCart, CheckCircle, Smartphone, Landmark, AlertCircle, Copy, Send, HelpCircle, ArrowRight } from 'lucide-react';

interface CustomerOrderPortalProps {
  activeUser: User;
  suppliers: Supplier[];
  inventory: InventoryItem[];
  prices: PriceItem[];
  onAddOrder: (newOrder: Order) => void;
}

export default function CustomerOrderPortal({
  activeUser,
  suppliers,
  inventory,
  prices,
  onAddOrder
}: CustomerOrderPortalProps) {
  const [selectedSupplierId, setSelectedSupplierId] = useState('');
  const [selectedProductId, setSelectedProductId] = useState('');
  const [quantity, setQuantity] = useState<number>(20);
  const [paymentType, setPaymentType] = useState<'Bank' | 'SMS'>('Bank');
  const [transferNumber, setTransferNumber] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [smsSentSimulated, setSmsSentSimulated] = useState(false);

  // Filter prices for the selected crusher
  const selectedSupplier = suppliers.find(s => s.id === selectedSupplierId);
  const crusherPrices = prices.filter(p => p.crusher === selectedSupplier?.name);
  const selectedPriceItem = crusherPrices.find(p => p.productId === selectedProductId);

  // Find available stock in inventory for display
  const getCrusherStock = (crusherName: string, prodId: string) => {
    const item = inventory.find(i => i.crusher === crusherName && i.productId === prodId);
    return item ? item.quantity : 0;
  };

  // Calculate live cost
  const unitPrice = selectedPriceItem ? selectedPriceItem.pricePerUnit : 0;
  const supplierPrice = selectedPriceItem ? selectedPriceItem.supplierPrice : 0;
  const totalPrice = quantity * unitPrice;
  const commission = quantity * (unitPrice - supplierPrice);
  const supplierAmount = quantity * supplierPrice;

  // Build the exact SMS template requested
  const smsMessageBody = `اطلب منكم قطع هذه الكمية لي انا ${activeUser.name} من ${selectedSupplier?.name || '[اسم الكسارة]'} عدد الكمية ${quantity} متر الصنف ${selectedPriceItem?.productType || '[الصنف]'} رقم الحواله ${transferNumber || '637548737'}`;

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSupplierId) {
      alert('الرجاء اختيار الكسارة أولاً.');
      return;
    }
    if (!selectedProductId) {
      alert('الرجاء تحديد الصنف المطلوب.');
      return;
    }
    if (quantity <= 0) {
      alert('الرجاء إدخال كمية صحيحة.');
      return;
    }
    if (paymentType === 'Bank' && !transferNumber) {
      alert('الرجاء إدخال رقم الحوالة البنكية لتأكيد السداد.');
      return;
    }

    // Generate standard order object
    const nextIdStr = `ORD-CUST-${Math.floor(Math.random() * 90000 + 10000)}`;
    const newOrder: Order = {
      id: nextIdStr,
      customerId: activeUser.id,
      customerName: activeUser.name,
      supplierId: selectedSupplierId,
      supplierName: selectedSupplier?.name || '',
      productId: selectedProductId,
      product: selectedPriceItem?.productType || '',
      quantity: quantity,
      unit: 'م³',
      unitPrice: unitPrice,
      totalPrice: totalPrice,
      commission: commission,
      supplierAmount: supplierAmount,
      status: 'Pending',
      paymentMethod: 'Bank Transfer',
      transferNumber: transferNumber || 'SMS-REQ',
      channel: paymentType === 'SMS' ? 'SMS' : 'App',
      date: new Date().toISOString()
    };

    onAddOrder(newOrder);
    setSuccessMsg('✅ تم إرسال طلبك بنجاح إلى إدارة الطلبات! سيتصل بك مندوب المبيعات فوراً لتأكيد الترحيل.');
    
    // Reset fields
    setTransferNumber('');
    setSelectedProductId('');
    setTimeout(() => {
      setSuccessMsg('');
    }, 5000);
  };

  const handleCopySMS = () => {
    navigator.clipboard.writeText(smsMessageBody);
    alert('تم نسخ نص الرسالة القصيرة بنجاح! يمكنك الآن لصقها وإرسالها.');
  };

  return (
    <div className="space-y-6" id="customer-order-portal">
      
      {/* 1. Live Available Quantities Board */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 shadow-xl" id="customer-live-stock">
        <div className="flex flex-col sm:flex-row-reverse justify-between items-start sm:items-center gap-4 mb-5 pb-4 border-b border-white/10">
          <div>
            <h3 className="text-base font-black text-white text-right">📊 لوحة مراقبة كميات الكسارات المتاحة</h3>
            <p className="text-[11px] text-slate-400 mt-1 text-right">مستويات المخزون الحالي المحدثة دورياً من مدير النظام والإنتاج الفعلي للكسارات.</p>
          </div>
          <span className="bg-amber-500/15 border border-amber-500/25 text-amber-300 px-3 py-1.5 rounded-xl text-[10px] font-bold">
            🟢 تحديث المخزون نشط
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {suppliers.map(sup => {
            const thumnQty = getCrusherStock(sup.name, 'thumn');
            const rubQty = getCrusherStock(sup.name, 'rub');
            const nussQty = getCrusherStock(sup.name, 'nuss');
            return (
              <div key={sup.id} className="bg-slate-950/60 rounded-2xl p-4 border border-slate-800/80 space-y-3.5 hover:border-slate-700 transition">
                <div className="flex justify-between items-center flex-row-reverse">
                  <span className="font-extrabold text-sm text-amber-400">{sup.name}</span>
                  <span className="bg-slate-800 text-[9px] text-slate-400 font-mono px-2 py-0.5 rounded">{sup.id}</span>
                </div>

                <div className="space-y-2 text-right">
                  <div className="flex justify-between flex-row-reverse items-center text-xs text-slate-300">
                    <span>ثمن (حصى 1/8):</span>
                    <span className={`font-mono font-black ${thumnQty > 200 ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {thumnQty.toLocaleString()} م³
                    </span>
                  </div>
                  <div className="flex justify-between flex-row-reverse items-center text-xs text-slate-300">
                    <span>ربع (حصى 1/4):</span>
                    <span className={`font-mono font-black ${rubQty > 200 ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {rubQty.toLocaleString()} م³
                    </span>
                  </div>
                  <div className="flex justify-between flex-row-reverse items-center text-xs text-slate-300">
                    <span>نصف (مخلوط 1/2):</span>
                    <span className={`font-mono font-black ${nussQty > 200 ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {nussQty.toLocaleString()} م³
                    </span>
                  </div>
                </div>

                {/* Quick select shortcut */}
                <button
                  onClick={() => {
                    setSelectedSupplierId(sup.id);
                    setSelectedProductId('');
                  }}
                  className="w-full bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-800 text-xs text-amber-300 py-1.5 rounded-xl transition cursor-pointer"
                >
                  تحديد هذه الكسارة للشراء منها
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. Interactive Order Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Dynamic Invoice and Checkout */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-5 text-right">
            <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5 flex-row-reverse border-b border-slate-100 pb-3">
              <ShoppingCart className="w-4 h-4 text-amber-500" />
              <span>معاينة الفاتورة المقدرة للطلب</span>
            </h3>

            {selectedSupplierId && selectedProductId ? (
              <div className="space-y-4 text-slate-600 text-xs">
                <div className="flex justify-between flex-row-reverse border-b border-slate-50 pb-2">
                  <span className="font-bold">الكسارة المحددة:</span>
                  <span className="text-slate-900 font-extrabold">{selectedSupplier?.name}</span>
                </div>
                <div className="flex justify-between flex-row-reverse border-b border-slate-50 pb-2">
                  <span className="font-bold">الصنف المطلوب:</span>
                  <span className="text-slate-900 font-extrabold">{selectedPriceItem?.productType}</span>
                </div>
                <div className="flex justify-between flex-row-reverse border-b border-slate-50 pb-2">
                  <span className="font-bold">سعر المتر:</span>
                  <span className="text-slate-900 font-mono font-bold">{unitPrice.toLocaleString()} ريال</span>
                </div>
                <div className="flex justify-between flex-row-reverse border-b border-slate-50 pb-2">
                  <span className="font-bold">الكمية المطلوبة:</span>
                  <span className="text-slate-900 font-mono font-extrabold">{quantity} م³</span>
                </div>

                <div className="bg-amber-50 rounded-2xl p-4 border border-amber-100 text-right space-y-1">
                  <span className="block text-[10px] text-amber-700 font-bold">المبلغ الإجمالي المطلوب سداده:</span>
                  <span className="text-lg font-black text-slate-950 font-mono">
                    {totalPrice.toLocaleString()} <span className="text-xs">ريال يمني</span>
                  </span>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-slate-400 space-y-2">
                <HelpCircle className="w-10 h-10 mx-auto text-slate-300 animate-bounce" />
                <p className="text-xs">الرجاء اختيار كسارة وصنف لتوليد الفاتورة التقديرية التلقائية.</p>
              </div>
            )}
          </div>

          {/* SMS Simulation Preview Phone Frame */}
          {paymentType === 'SMS' && selectedSupplierId && selectedProductId && (
            <div className="bg-slate-950 rounded-[2.5rem] border-4 border-slate-800 p-3 shadow-2xl relative">
              <div className="w-24 h-4 bg-slate-800 rounded-full mx-auto mb-3"></div>
              
              <div className="bg-slate-900 rounded-2xl p-4 text-right space-y-3 font-sans">
                <div className="flex justify-between items-center text-[10px] text-slate-400 border-b border-slate-800 pb-2">
                  <span>إلى: 776716818</span>
                  <span className="font-mono">تطبيق الرسائل القصيرة</span>
                </div>

                <div className="bg-slate-800 text-white rounded-2xl p-3 text-[11px] leading-relaxed border border-slate-700">
                  {smsMessageBody}
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={handleCopySMS}
                    className="w-1/2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] py-2 rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    <span>نسخ الرسالة</span>
                  </button>
                  <a
                    href={`sms:776716818?body=${encodeURIComponent(smsMessageBody)}`}
                    onClick={() => setSmsSentSimulated(true)}
                    className="w-1/2 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] py-2 rounded-xl flex items-center justify-center gap-1 font-bold cursor-pointer"
                  >
                    <Send className="w-3 h-3" />
                    <span>إرسال SMS حقيقي</span>
                  </a>
                </div>

                {smsSentSimulated && (
                  <div className="bg-emerald-950/40 text-emerald-400 text-[9px] p-2 rounded-lg border border-emerald-800 text-center">
                    تمت محاكاة توجيه الطلب بنجاح عبر بوابة الرسائل القصيرة للجوال!
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right Side: Interactive Purchase Inputs */}
        <div className="lg:col-span-7">
          <form onSubmit={handleSubmitOrder} className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6 text-right">
            <div>
              <h3 className="text-sm font-black text-slate-900">✍️ تعبئة طلب شراء مواد الكري والبطحاء</h3>
              <p className="text-[11px] text-slate-400 mt-1">يرجى تعبئة الحقول لتوليد سند الطلب ونظام الدفع المناسب لك.</p>
            </div>

            {successMsg && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-4 rounded-2xl font-bold animate-pulse text-right flex justify-between items-center gap-2">
                <span>{successMsg}</span>
                <button
                  type="button"
                  onClick={() => setSuccessMsg('')}
                  className="bg-white hover:bg-slate-150 hover:bg-slate-100 text-slate-800 px-3 py-1 rounded-lg text-[10px] font-bold cursor-pointer border shrink-0"
                >
                  إغلاق / رجوع ×
                </button>
              </div>
            )}

            {/* Select Crusher */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">1. حدد الكسارة المطلوبة للطلب:</label>
              <select
                value={selectedSupplierId}
                onChange={(e) => {
                  setSelectedSupplierId(e.target.value);
                  setSelectedProductId('');
                }}
                className="w-full text-right p-3 bg-slate-50 border border-slate-200 focus:border-amber-500 rounded-xl text-xs focus:outline-none transition"
                required
              >
                <option value="">-- اختر الكسارة الموفرة للمادة المطلوبة --</option>
                {suppliers.map(sup => (
                  <option key={sup.id} value={sup.id}>{sup.name}</option>
                ))}
              </select>
            </div>

            {/* Select Product */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">2. حدد صنف ونوع الكري المطلوب:</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {crusherPrices.map(price => {
                  const stock = getCrusherStock(price.crusher, price.productId);
                  return (
                    <button
                      key={price.id}
                      type="button"
                      onClick={() => setSelectedProductId(price.productId)}
                      className={`p-3.5 rounded-xl border text-right transition flex flex-col justify-between cursor-pointer ${
                        selectedProductId === price.productId
                          ? 'border-amber-500 bg-amber-50 text-amber-950 font-bold'
                          : 'border-slate-150 bg-slate-50 hover:bg-slate-100 text-slate-700'
                      }`}
                    >
                      <span className="text-xs">{price.productType}</span>
                      <span className="text-[10px] text-slate-500 mt-1 block font-mono">
                        السعر: {price.pricePerUnit.toLocaleString()} ريال/م³
                      </span>
                      <span className="text-[9px] text-slate-400 mt-0.5 block font-mono">
                        المتوفر: {stock.toLocaleString()} م³
                      </span>
                    </button>
                  );
                })}
                {selectedSupplierId && crusherPrices.length === 0 && (
                  <div className="col-span-3 text-center text-xs text-rose-500 py-3">
                    عذراً، لم يقم مدير النظام بإدراج تسعيرة أو كميات أصناف لهذه الكسارة بعد.
                  </div>
                )}
              </div>
            </div>

            {/* Input Quantity */}
            <div className="space-y-2">
              <div className="flex justify-between items-center flex-row-reverse">
                <label className="block text-xs font-bold text-slate-700">3. حدد الكمية الإجمالية المطلوبة (بالمتر المكعب م³):</label>
                <span className="text-[10px] text-slate-400 font-mono">الافتراضي: 20 م³</span>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setQuantity(prev => Math.max(1, prev - 5))}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs px-3.5 rounded-xl border border-slate-200 font-bold cursor-pointer"
                >
                  - 5 م³
                </button>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseFloat(e.target.value) || 0))}
                  className="flex-1 text-center font-mono font-extrabold p-3 bg-slate-50 border border-slate-200 focus:border-amber-500 rounded-xl text-xs focus:outline-none"
                  min="1"
                  step="0.5"
                  required
                />
                <button
                  type="button"
                  onClick={() => setQuantity(prev => prev + 5)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs px-3.5 rounded-xl border border-slate-200 font-bold cursor-pointer"
                >
                  + 5 م³
                </button>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-3 border-t border-slate-100 pt-5">
              <label className="block text-xs font-bold text-slate-700">4. تحديد طريقة السداد والتحصيل النقدي:</label>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Bank option */}
                <button
                  type="button"
                  onClick={() => setPaymentType('Bank')}
                  className={`p-4 rounded-2xl border text-right transition flex items-start gap-3 flex-row-reverse cursor-pointer ${
                    paymentType === 'Bank'
                      ? 'border-indigo-500 bg-indigo-50/40 text-indigo-950 font-bold'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <div className="p-2 bg-indigo-500/10 text-indigo-600 rounded-lg">
                    <Landmark className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs block">حوالة بنكية معتمدة</span>
                    <span className="text-[10px] text-slate-500 mt-0.5 block font-normal leading-relaxed">
                      إدخال رقم إشعار الحوالة الصادرة من بنك الكريمي أو غيره مباشرة بالنظام.
                    </span>
                  </div>
                </button>

                {/* SMS option */}
                <button
                  type="button"
                  onClick={() => setPaymentType('SMS')}
                  className={`p-4 rounded-2xl border text-right transition flex items-start gap-3 flex-row-reverse cursor-pointer ${
                    paymentType === 'SMS'
                      ? 'border-emerald-500 bg-emerald-50/40 text-emerald-950 font-bold'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <div className="p-2 bg-emerald-500/10 text-emerald-600 rounded-lg">
                    <Smartphone className="w-5 h-5 animate-pulse" />
                  </div>
                  <div>
                    <span className="text-xs block">السداد وتأكيد الطلب عبر رسالة SMS</span>
                    <span className="text-[10px] text-slate-500 mt-0.5 block font-normal leading-relaxed">
                      إرسال إشعار فوري تلقائي بالكمية والمبلغ إلى بوابة الرسائل الطرفية عبر الرقم 776716818.
                    </span>
                  </div>
                </button>
              </div>
            </div>

            {/* Dynamic input for Transfer number */}
            <div className="space-y-2 bg-slate-50/50 p-4 rounded-2xl border border-slate-100">
              <label className="block text-xs font-bold text-slate-700">
                {paymentType === 'Bank' ? 'الرجاء كتابة رقم إشعار الحوالة البنكية:' : 'أدخل رقم الحوالة لإدراجه بالرسالة الموجهة (مثال: 637548737):'}
              </label>
              <input
                type="text"
                value={transferNumber}
                onChange={(e) => setTransferNumber(e.target.value.replace(/\D/g, ''))}
                placeholder="أدخل الرمز الرقمي للحوالة..."
                className="w-full text-right p-3 bg-white border border-slate-200 focus:border-amber-500 rounded-xl text-xs focus:outline-none transition font-mono"
                required
              />
            </div>

            {/* Confirm Submit button */}
            <button
              type="submit"
              className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs py-4 rounded-xl flex items-center justify-center gap-2 shadow-md shadow-amber-500/10 transition cursor-pointer"
            >
              <span>تأكيد إرسال الطلب وحجز الكمية</span>
              <ArrowRight className="w-4 h-4 rotate-180" />
            </button>
          </form>
        </div>

      </div>
    </div>
  );
}
