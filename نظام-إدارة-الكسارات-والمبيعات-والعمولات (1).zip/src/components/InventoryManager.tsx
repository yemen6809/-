import React, { useState } from 'react';
import { InventoryItem, PriceItem } from '../types';
import { Boxes, Key, AlertTriangle, Leaf, Settings, RefreshCw, BarChart2 } from 'lucide-react';

interface InventoryManagerProps {
  inventory: InventoryItem[];
  prices: PriceItem[];
  currentRole: string;
  onUpdateInventoryQty: (itemId: string, newQty: number) => void;
}

export default function InventoryManager({ 
  inventory, 
  prices, 
  currentRole,
  onUpdateInventoryQty 
}: InventoryManagerProps) {
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [editQty, setEditQty] = useState<number>(0);

  // Helper to map inventory product to pricing sheet details
  const getProductPricing = (crusher: string, productId: string) => {
    return prices.find(p => p.crusher === crusher && p.productId === productId);
  };

  const getStatusBadge = (status: 'Low' | 'Normal' | 'High') => {
    switch (status) {
      case 'Low':
        return <span className="bg-rose-100 border border-rose-200 text-rose-800 text-[10px] px-2 py-0.5 rounded font-extrabold flex items-center gap-1 animate-pulse">⚠️ مخزون منخفض خَرِج</span>;
      case 'Normal':
        return <span className="bg-slate-100 text-slate-800 text-[10px] px-2 py-0.5 rounded font-bold">🔘 طبيعي مستقر</span>;
      case 'High':
        return <span className="bg-emerald-100 text-emerald-800 text-[10px] px-2 py-0.5 rounded font-bold">🟢 فائض ممتلئ</span>;
      default:
        return null;
    }
  };

  const handleUpdate = (id: string) => {
    if (editQty < 0) {
      alert('الرجاء كتابة كمية مقبولة');
      return;
    }
    onUpdateInventoryQty(id, editQty);
    setEditingItemId(null);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-6" id="inventory-module">
      <div className="flex justify-between items-start mb-6 border-b border-slate-100 pb-5">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-1.5">
            <Boxes className="text-slate-600 w-5 h-5" />
            المخزون الفعلي بالمتر المكعب وتسعيرة المصانع
          </h3>
          <p className="text-slate-400 text-xs mt-1">تتبع كفاية الكري في السيلوهات ومطابقتها بالتسعيرات وتوزيعات النسب المعتمدة.</p>
        </div>
        <div className="bg-slate-50 border p-2 rounded-xl flex items-center gap-1.5 text-[10px] font-bold text-slate-600">
          <Key className="w-3.5 h-3.5" />
          <span>هامش الأمان للسيلو: 200 م³</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="inventory-grid">
        {inventory.map(item => {
          const pricing = getProductPricing(item.crusher, item.productId);
          const isEditing = editingItemId === item.id;
          
          // Calculate custom stats if pricing sheets matched
          const profitMargin = pricing ? pricing.pricePerUnit - pricing.supplierPrice : 0;
          const profitPercent = pricing && pricing.pricePerUnit > 0 ? (profitMargin / pricing.pricePerUnit) * 100 : 0;

          return (
            <div 
              key={item.id} 
              className={`p-5 rounded-2xl border transition-all ${
                item.status === 'Low' 
                  ? 'border-rose-200 bg-rose-50/20' 
                  : 'border-slate-205 border-slate-200 hover:shadow-md'
              }`}
              id={`inventory-card-${item.id}`}
            >
              {/* Card top */}
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 block">{item.crusher}</span>
                  <span className="text-slate-950 font-extrabold text-sm mt-0.5 block">{item.product}</span>
                </div>
                {getStatusBadge(item.status)}
              </div>

              {/* Quantity Indicators */}
              <div className="my-5 bg-slate-50 border rounded-xl p-4 flex justify-between items-center">
                <div>
                  <span className="text-[10px] text-slate-500 block">الكمية التشغيلية:</span>
                  {isEditing ? (
                    <div className="flex items-center gap-1 mt-1">
                      <input
                        type="number"
                        value={editQty}
                        onChange={(e) => setEditQty(Number(e.target.value))}
                        className="w-20 bg-white border rounded px-1.5 py-1 text-xs font-mono font-bold"
                      />
                      <button 
                        type="button" 
                        onClick={() => handleUpdate(item.id)}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-2.5 py-1 rounded text-[10px] cursor-pointer"
                      >
                        حفظ
                      </button>
                      <button 
                        type="button" 
                        onClick={() => setEditingItemId(null)}
                        className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-2 py-1 rounded text-[10px] cursor-pointer"
                        title="رجوع وإلغاء"
                      >
                        رجوع ×
                      </button>
                    </div>
                  ) : (
                    <span className="font-mono text-xl font-black text-slate-900">
                      {item.quantity.toLocaleString('ar-YE')} <span className="text-xs font-sans text-slate-400">م³</span>
                    </span>
                  )}
                </div>

                {/* Edit volume trigger */}
                {(currentRole === 'Admin' || currentRole === 'Sales Representative') && !isEditing && (
                  <button 
                    onClick={() => {
                      setEditingItemId(item.id);
                      setEditQty(item.quantity);
                    }}
                    className="p-1 px-2 border rounded-lg bg-white hover:bg-slate-100 text-[10px] text-slate-500 flex items-center gap-1 font-semibold"
                  >
                    <RefreshCw className="w-3 h-3" />
                    تعديل كمية السيلو
                  </button>
                )}
              </div>

              {/* Graphical volume progress bar */}
              <div className="mb-4">
                <div className="flex justify-between text-[10px] text-slate-400 font-semibold mb-1">
                  <span>سعة التعبئة</span>
                  <span>{item.quantity >= 6000 ? '100% (فائض)' : `${Math.min(100, Math.round((item.quantity / 5000) * 100))}%`}</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-500 ${
                      item.status === 'Low' ? 'bg-rose-500' : item.status === 'High' ? 'bg-emerald-500' : 'bg-amber-500'
                    }`}
                    style={{ width: `${Math.min(100, (item.quantity / 5000) * 100)}%` }}
                  ></div>
                </div>
              </div>

              {/* Pricing breakdown associated with this aggregate */}
              {pricing && (
                <div className="border-t border-slate-100 pt-3.5 mt-3 grid grid-cols-2 gap-3 text-[10px]">
                  <div>
                    <span className="text-slate-450 text-slate-400 block pb-0.5">سجل التسعير النهائي:</span>
                    <span className="font-mono font-bold text-slate-800">البيع: {pricing.pricePerUnit} ريال / م³</span>
                  </div>
                  <div>
                    <span className="text-slate-450 text-slate-400 block pb-0.5">الرسوم والنسب القانونية:</span>
                    <span className="font-mono font-bold text-emerald-700 flex items-center gap-0.5">
                      الرسوم: +{profitMargin} ريال ({profitPercent.toFixed(1)}%)
                    </span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
