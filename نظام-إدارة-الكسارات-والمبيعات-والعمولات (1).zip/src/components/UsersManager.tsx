import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { Users, UserPlus, Key, ShieldCheck, Mail, Phone, Power, Check, ChevronLeft } from 'lucide-react';

interface UsersManagerProps {
  users: User[];
  currentRole: string;
  onAddUser: (user: User) => void;
  onToggleUserStatus: (userId: string) => void;
  onToggleTerminalAccess: (userId: string) => void;
}

export default function UsersManager({
  users,
  currentRole,
  onAddUser,
  onToggleUserStatus,
  onToggleTerminalAccess
}: UsersManagerProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('Customer');
  const [terminalAccess, setTerminalAccess] = useState(false);

  const handleRegisterUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;

    const newUser: User = {
      id: 'USR-' + Math.floor(Math.random() * 900 + 100),
      name,
      phone: phone || undefined,
      email: email || undefined,
      role,
      status: 'Active',
      terminalAccess
    };

    onAddUser(newUser);

    // Reset
    setShowAddForm(false);
    setName('');
    setPhone('');
    setEmail('');
    setRole('Customer');
    setTerminalAccess(false);
  };

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'Admin':
        return <span className="bg-red-100 border border-red-200 text-red-800 text-[10px] px-2 py-0.5 rounded-full font-bold">👑 مسؤول النظام</span>;
      case 'Sales Representative':
        return <span className="bg-indigo-100 border border-indigo-200 text-indigo-800 text-[10px] px-2 py-0.5 rounded-full font-bold">👔 مندوب بيع</span>;
      case 'Marketing':
        return <span className="bg-amber-100 text-amber-800 text-[10px] px-2 py-0.5 rounded-full font-bold">📢 تسويق</span>;
      case 'Customer':
        return <span className="bg-slate-100 text-slate-700 text-[10px] px-2 py-0.5 rounded-full font-bold">🚛 عميل / سائق</span>;
      case 'Accounting':
        return <span className="bg-blue-100 border border-blue-200 text-blue-800 text-[10px] px-2 py-0.5 rounded-full font-bold">📊 مسؤول حسابات</span>;
      case 'Cashier':
        return <span className="bg-emerald-100 border border-emerald-200 text-emerald-800 text-[10px] px-2 py-0.5 rounded-full font-bold">💵 مسؤول الصندوق</span>;
      case 'Owner':
        return <span className="bg-purple-100 border border-purple-200 text-purple-800 text-[10px] px-2 py-0.5 rounded-full font-bold">🏗️ مالك كسارة</span>;
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-205 border-slate-200 p-6" id="users-module">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6 border-b border-slate-100 pb-5">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-1.5 animate-fade-in">
            <Users className="text-slate-600 w-5 h-5" />
            إدارة الكادر والصلاحيات البرمجية
          </h3>
          <p className="text-slate-450 text-slate-400 text-xs mt-1">
            تسجيل المستخدمين، مراقبة الوصول إلى الوحدات الطرفية والمقالع الفنية والترخيص التشغيلي.
          </p>
        </div>

        {currentRole === 'Admin' && (
          <button
            onClick={() => {
              const goingToOpen = !showAddForm;
              setShowAddForm(goingToOpen);
              if (goingToOpen) {
                // smooth scroll down to user join sheet
                setTimeout(() => {
                  const formEl = document.getElementById('form-register-user');
                  if (formEl) {
                    formEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }
                }, 100);
              }
            }}
            className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2.5 rounded-xl inline-flex items-center gap-2 transform active:scale-95 transition-all self-start"
          >
            <UserPlus className="w-4 h-4" />
            {showAddForm ? 'إلغاء النافذة' : 'التحاق مستخدم جديد'}
          </button>
        )}
      </div>

      {showAddForm && (
        <form id="form-register-user" onSubmit={handleRegisterUser} className="bg-slate-55 bg-slate-50 border p-5 rounded-2xl mb-6 grid grid-cols-1 md:grid-cols-3 gap-4 animate-slide-down">
          
          {/* Top Full-Width Header Row with Back Button */}
          <div className="md:col-span-3 flex justify-between items-center bg-white p-3 rounded-xl border border-slate-200 mb-2">
            <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
              👤 تسجيل والتحاق كوادر مستخدمين جدد وقرارات صلاحية
            </span>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="text-[10px] bg-slate-50 text-slate-700 border border-slate-250 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 font-bold flex items-center gap-1 transition cursor-pointer select-none"
            >
              <ChevronLeft className="w-3.5 h-3.5 rotate-180 text-slate-500" />
              <span>رجوع للخلف ×</span>
            </button>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">الاسم الكامل لملتحق الحساب</label>
            <input
              type="text"
              required
              placeholder="مثال: المهندس أمجد مصلح"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2 text-xs focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">رقم الهاتف النشط (الرئيسي)</label>
            <input
              type="tel"
              placeholder="مثال: 77739281"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2 text-xs font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">البريد الإلكتروني للإشعارات</label>
            <input
              type="email"
              placeholder="name@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2 text-xs font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">الدور البرمجي المنوط</label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2 text-xs focus:outline-none"
            >
              <option value="Customer">Customer (عميل / مالك شاحنة تتبع)</option>
              <option value="Sales Representative">Sales Representative (مندوب مبيعات الشروخ)</option>
              <option value="Marketing">Marketing (محلل ترويج وتسويق الكباري)</option>
              <option value="Admin">Admin (مسؤول مالي وتشغيلي مطلق)</option>
              <option value="Accounting">Accounting (مسؤول حسابات مالي)</option>
              <option value="Cashier">Cashier (مسؤول الصندوق والتحصيل)</option>
              <option value="Owner">Owner (مالك كسارة / مستثمر)</option>
            </select>
          </div>

          <div className="flex items-center gap-2 md:col-span-2 pt-6">
            <input
              type="checkbox"
              id="terminal_access_check"
              checked={terminalAccess}
              onChange={(e) => setTerminalAccess(e.target.checked)}
              className="rounded text-slate-900 border-slate-300 focus:ring-slate-900"
            />
            <label htmlFor="terminal_access_check" className="text-xs font-semibold text-slate-700 cursor-pointer">
              منح بوابات طرفية (Terminal Access) للتشغيل وإتاحة فحص شفرات التوصيل
            </label>
          </div>

          <div className="md:col-span-3 flex justify-end gap-2 border-t pt-4 mt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs px-3.5 py-2 rounded-xl font-extrabold flex items-center gap-1.5 transition cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5 rotate-180 text-slate-500" />
              <span>تراجع ورجوع للخلف</span>
            </button>
            <button
              type="submit"
              className="bg-slate-900 hover:bg-slate-800 text-white text-xs px-4 py-1.5 rounded-lg font-bold"
            >
              تسجيل الحساب وتوليد الرمز
            </button>
          </div>
        </form>
      )}

      {/* Roster list */}
      <div className="overflow-x-auto">
        <table className="w-full text-right border-collapse text-xs">
          <thead>
            <tr className="border-b bg-slate-50 text-slate-500 font-semibold">
              <th className="py-3 px-4">رقم الكادر</th>
              <th className="py-3 px-4">الاسم والمسمى</th>
              <th className="py-3 px-4">الدور الوظيفي</th>
              <th className="py-3 px-4">بيانات الاتصال</th>
              <th className="py-3 px-4 text-center">الوحدة الطرفية (Terminal)</th>
              <th className="py-3 px-4 text-center">حالة الحساب</th>
              {currentRole === 'Admin' && (
                <th className="py-3 px-4 text-center">إدارة القيود</th>
              )}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-150 divide-slate-100 font-medium text-slate-700">
            {users.map(user => (
              <tr key={user.id} className="hover:bg-slate-50" id={`user-row-${user.id}`}>
                <td className="py-3 px-4 font-mono font-bold text-slate-400">{user.id}</td>
                <td className="py-3 px-4">
                  <span className="text-slate-900 font-bold block">{user.name}</span>
                </td>
                <td className="py-3 px-4">{getRoleBadge(user.role)}</td>
                <td className="py-3 px-4">
                  {user.phone && <div className="font-mono text-slate-600 flex items-center gap-1"><Phone className="w-3 h-3 text-slate-400" /> {user.phone}</div>}
                  {user.email && <div className="font-mono text-slate-400 mt-0.5 flex items-center gap-1"><Mail className="w-3 h-3 text-slate-300" /> {user.email}</div>}
                </td>
                <td className="py-3 px-4 text-center">
                  <span className={`inline-block text-[10px] px-2 py-0.5 rounded font-bold ${
                    user.terminalAccess ? 'bg-sky-50 text-sky-800 text-sky-700' : 'bg-slate-100 text-slate-400'
                  }`}>
                    {user.terminalAccess ? 'متاح ومخوّل' : 'غير معطى'}
                  </span>
                </td>
                <td className="py-3 px-4 text-center">
                  <span className={`inline-block text-[10px] px-2 py-0.5 rounded-full font-bold ${
                    user.status === 'Active' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                  }`}>
                    {user.status === 'Active' ? 'نشط مفعل' : 'موقف مؤقتاً'}
                  </span>
                </td>

                {currentRole === 'Admin' && (
                  <td className="py-3 px-4 text-center">
                    <div className="flex justify-center items-center gap-1.5">
                      <button
                        onClick={() => onToggleUserStatus(user.id)}
                        className={`p-1 rounded text-xs ${
                          user.status === 'Active' 
                            ? 'bg-amber-100 text-amber-800 hover:bg-amber-200' 
                            : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                        }`}
                        title={user.status === 'Active' ? 'تعليق الحساب مؤقتاً' : 'إلغاء تعليق الحساب'}
                      >
                        <Power className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => onToggleTerminalAccess(user.id)}
                        className="bg-slate-100 hover:bg-slate-200 text-slate-700 p-1 rounded text-xs"
                        title="تبديل صلاحية البوابة الطرفية"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
