import React, { useState, useMemo } from 'react';
import { Order, Supplier, InventoryItem, PriceItem, User } from '../types';
import { 
  FileText, Plus, Search, Filter, HelpCircle, 
  CheckCircle2, AlertCircle, Trash2, Check, ArrowUpRight, ArrowDownLeft, XCircle, Share2, Truck, ChevronLeft,
  Printer
} from 'lucide-react';

interface OrdersManagerProps {
  orders: Order[];
  suppliers: Supplier[];
  inventory: InventoryItem[];
  prices: PriceItem[];
  users: User[];
  currentRole: string;
  onAddOrder: (order: Order) => void;
  onUpdateOrderStatus: (orderId: string, newStatus: 'Pending' | 'In Transit' | 'Delivered' | 'Cancelled') => void;
}

export default function OrdersManager({
  orders,
  suppliers,
  inventory,
  prices,
  users,
  currentRole,
  onAddOrder,
  onUpdateOrderStatus
}: OrdersManagerProps) {
  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [supplierFilter, setSupplierFilter] = useState<string>('All');
  const [selectedInvoiceOrder, setSelectedInvoiceOrder] = useState<Order | null>(null);
  
  // Create Order Form State
  const [showAddForm, setShowAddForm] = useState(false);
  const [customerId, setCustomerId] = useState('');
  const [customCustomerName, setCustomCustomerName] = useState('');
  const [selectedSupplierId, setSelectedSupplierId] = useState('');
  const [selectedProductId, setSelectedProductId] = useState('thumn');
  const [quantity, setQuantity] = useState<number>(40);
  const [paymentMethod, setPaymentMethod] = useState<'Bank Transfer' | 'Cash'>('Bank Transfer');
  const [transferNumber, setTransferNumber] = useState('');
  const [orderChannel, setOrderChannel] = useState<'App' | 'WhatsApp' | 'SMS'>('App');

  // Customer List
  const customers = useMemo(() => {
    return users.filter(u => u.role === 'Customer' || u.id === 'USR-003' || u.id === 'USR-005');
  }, [users]);

  // Handle automatic calculations based on current pricing sheet
  const calculatedPrices = useMemo(() => {
    if (!selectedSupplierId) return { pricePerUnit: 0, supplierPrice: 0, total: 0, profit: 0, supplierShare: 0, productText: '' };
    
    // Find supplier's name first
    const supplierObj = suppliers.find(s => s.id === selectedSupplierId);
    if (!supplierObj) return { pricePerUnit: 0, supplierPrice: 0, total: 0, profit: 0, supplierShare: 0, productText: '' };

    const matchedPrice = prices.find(
      p => p.crusher === supplierObj.name && p.productId === selectedProductId
    );

    if (!matchedPrice) return { pricePerUnit: 0, supplierPrice: 0, total: 0, profit: 0, supplierShare: 0, productText: '' };

    const total = quantity * matchedPrice.pricePerUnit;
    const profit = (matchedPrice.pricePerUnit - matchedPrice.supplierPrice) * quantity;
    const supplierShare = matchedPrice.supplierPrice * quantity;

    return {
      pricePerUnit: matchedPrice.pricePerUnit,
      supplierPrice: matchedPrice.supplierPrice,
      total,
      profit,
      supplierShare,
      productText: matchedPrice.productType
    };
  }, [selectedSupplierId, selectedProductId, quantity, prices, suppliers]);

  // Filtered orders list
  const filteredOrders = useMemo(() => {
    return orders.filter(o => {
      const matchesSearch = 
        (o.id.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (o.customerName && o.customerName.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (o.supplierName.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (o.product.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (o.transferNumber && o.transferNumber.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesStatus = statusFilter === 'All' ? true : o.status === statusFilter;
      const matchesSupplier = supplierFilter === 'All' ? true : o.supplierId === supplierFilter;

      // Customers can only see their own orders
      const matchesRoleScope = currentRole === 'Customer' 
        ? (o.customerId === 'USR-003' || o.customerId === 'USR-005') 
        : true;

      return matchesSearch && matchesStatus && matchesSupplier && matchesRoleScope;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [orders, searchTerm, statusFilter, supplierFilter, currentRole]);

  // Form submission
  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSupplierId) {
      alert('الرجاء اختيار الكسارة الموردة');
      return;
    }

    const supplierObj = suppliers.find(s => s.id === selectedSupplierId);
    if (!supplierObj) return;

    let finalCustomerId = customerId;
    let finalCustomerName = '';

    if (customerId === 'CUSTOM') {
      finalCustomerId = 'USR-' + Math.floor(Math.random() * 900 + 100);
      finalCustomerName = customCustomerName || 'عميل خارجي';
    } else {
      const registeredUser = users.find(u => u.id === customerId);
      finalCustomerName = registeredUser ? registeredUser.name : 'عميل غير مسجل';
    }

    const numericIds = orders.map(o => {
      const match = o.id.match(/\d+/);
      return match ? parseInt(match[0], 10) : 0;
    });
    const maxId = Math.max(0, ...numericIds);
    const nextIdStr = `ORD-${maxId + 1}`;

    const newOrder: Order = {
      id: nextIdStr,
      customerId: finalCustomerId,
      customerName: finalCustomerName,
      supplierId: selectedSupplierId,
      supplierName: supplierObj.name,
      productId: selectedProductId,
      product: calculatedPrices.productText || 'كري مخلوط مصفى',
      quantity,
      unit: 'م³',
      unitPrice: calculatedPrices.pricePerUnit,
      totalPrice: calculatedPrices.total,
      commission: calculatedPrices.profit,
      supplierAmount: calculatedPrices.supplierShare,
      status: 'Pending',
      paymentMethod,
      transferNumber: paymentMethod === 'Bank Transfer' ? transferNumber : undefined,
      channel: orderChannel,
      date: new Date().toISOString()
    };

    onAddOrder(newOrder);

    // Reset states
    setShowAddForm(false);
    setCustomerId('');
    setCustomCustomerName('');
    setSelectedSupplierId('');
    setTransferNumber('');
    setQuantity(40);
  };

  // Status badges mapping
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Pending':
        return <span className="bg-amber-100 text-amber-800 text-xs px-2.5 py-1 rounded-full font-medium inline-flex items-center gap-1">⏱️ بانتظار المراجعة</span>;
      case 'Delivered':
        return <span className="bg-emerald-100 text-emerald-800 text-xs px-2.5 py-1 rounded-full font-medium inline-flex items-center gap-1">✅ معتمد وموزع</span>;
      case 'Cancelled':
        return <span className="bg-rose-100 text-rose-800 text-xs px-2.5 py-1 rounded-full font-medium inline-flex items-center gap-1">❌ ملغي</span>;
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-205 border-slate-200 shadow-xs p-6" id="orders-module">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6 border-b border-slate-100 pb-5" id="orders-header">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <FileText className="text-slate-600 w-5 h-5" />
            إدارة طلبات وفواتير مبيعات الكري والتوزيعات
          </h2>
          <p className="text-slate-500 text-xs mt-1">
            {currentRole === 'Customer' 
              ? 'مكتب تتبع طلبياتك للكميات والأسعار والتسويات والتوزيعات المعتمدة.' 
              : 'التحكم بالقلب التشغيلي: إصدار فواتير المبيعات واحتساب بنود الرسوم والنسب المحددة قانوناً.'}
          </p>
        </div>

        {/* Create button */}
        {(currentRole === 'Admin' || currentRole === 'Sales Representative' || currentRole === 'Customer') && (
          <button
            onClick={() => {
              const goingToOpen = !showAddForm;
              setShowAddForm(goingToOpen);
              if (goingToOpen) {
                // smooth scroll down to order sheet form
                setTimeout(() => {
                  const formEl = document.getElementById('form-add-order');
                  if (formEl) {
                    formEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }
                }, 100);
              }
              // Prepopulate with a supplier default
              if (suppliers.length > 0) setSelectedSupplierId(suppliers[0].id);
              if (customers.length > 0) setCustomerId(customers[0].id);
            }}
            className="bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs px-4 py-2.5 rounded-xl inline-flex items-center gap-2 transform active:scale-95 transition-all duration-150 self-start"
            id="btn-toggle-add-order"
          >
            <Plus className="w-4 h-4" />
            {showAddForm ? 'إلغاء النافذة' : 'إصدار طلب / شحنة جديدة'}
          </button>
        )}
      </div>

      {/* 1. Add Order Form Drawer/Container */}
      {showAddForm && (
        <form 
          onSubmit={handleSubmitOrder} 
          className="bg-slate-50 p-6 rounded-2xl border border-slate-200 mb-6 transition-all duration-300 animate-slide-down"
          id="form-add-order"
        >
          <div className="flex items-center justify-between gap-4 mb-4 border-b border-slate-200 pb-3">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-slate-900 text-white rounded-lg">
                <Plus className="w-4 h-4" />
              </div>
              <h3 className="font-bold text-sm text-slate-900">إنشاء طلب وفاتورة مبيعات جديدة</h3>
            </div>
            
            {/* Top Back/Close Button */}
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="text-slate-600 hover:text-slate-900 text-xs font-bold flex items-center gap-1 border border-slate-200 rounded-xl px-3 py-1.5 bg-white hover:bg-slate-100 transition cursor-pointer select-none"
            >
              <ChevronLeft className="w-4 h-4 rotate-180" />
              <span>رجوع للخلف ×</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Customer Identification */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">العميل صاحب الطلب</label>
              {currentRole === 'Customer' ? (
                <div className="bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-slate-800 font-semibold">
                  بشير الخولاني (صاحب الشاحنة)
                </div>
              ) : (
                <select
                  required
                  value={customerId}
                  onChange={(e) => setCustomerId(e.target.value)}
                  className="w-full bg-white border border-slate-205 border-slate-200 rounded-xl px-4 py-2.5 text-xs focus:ring-2 focus:ring-slate-900 focus:outline-none"
                >
                  <option value="">-- اختر العميل --</option>
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                  <option value="CUSTOM">أضف عميل خارجي يدويّاً...</option>
                </select>
              )}

              {customerId === 'CUSTOM' && (
                <input
                  type="text"
                  required
                  placeholder="اكتب اسم العميل الثلاثي هنا..."
                  value={customCustomerName}
                  onChange={(e) => setCustomCustomerName(e.target.value)}
                  className="w-full mt-2 bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs focus:ring-2 focus:ring-slate-900 focus:outline-none"
                />
              )}
            </div>

            {/* Supplier / Crusher */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">الكسارة الموردة</label>
              <select
                required
                value={selectedSupplierId}
                onChange={(e) => setSelectedSupplierId(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs focus:ring-2 focus:ring-slate-900 focus:outline-none"
              >
                <option value="">-- تحديد الكسارة المصنّعة --</option>
                {suppliers.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>

            {/* Product Category */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">تصنيف الكري الفعلي</label>
              <select
                required
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs focus:ring-2 focus:ring-slate-900 focus:outline-none"
              >
                <option value="thumn">ثمن (حصى 1/8)</option>
                <option value="rub">ربع (حصى 1/4)</option>
                <option value="nuss">نصف (مخلوط 1/2)</option>
              </select>
            </div>

            {/* Quantity */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">الكمية المطلوبة بالمتر المكعب (م³)</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  required
                  min="5"
                  max="500"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-mono focus:ring-2 focus:ring-slate-900 focus:outline-none"
                />
                <span className="bg-slate-200 text-slate-700 text-xs px-3 py-2 rounded-xl flex items-center font-semibold">م³</span>
              </div>
            </div>

            {/* Payment Method */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">آلية التمويل والتسديد</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as any)}
                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs focus:ring-2 focus:ring-slate-900 focus:outline-none"
              >
                <option value="Bank Transfer">حوالة بنكية كودية</option>
                <option value="Cash">نقدي مباشر</option>
              </select>
            </div>

            {/* Transfer ID (optional) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                رقم الحوالة أو السند الكودي {paymentMethod === 'Bank Transfer' && <span className="text-rose-500">*</span>}
              </label>
              <input
                type="text"
                required={paymentMethod === 'Bank Transfer'}
                placeholder={paymentMethod === 'Bank Transfer' ? "مثال: TRX-1192-S" : "اختياري - في حال الدفع المؤجل"}
                value={transferNumber}
                onChange={(e) => setTransferNumber(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-mono focus:ring-2 focus:ring-slate-900 focus:outline-none"
              />
            </div>

            {/* Communication Channel */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">قناة ورود الطلب</label>
              <div className="flex gap-3 mt-1 text-xs">
                {(['App', 'WhatsApp', 'SMS'] as const).map(channel => (
                  <label key={channel} className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      checked={orderChannel === channel}
                      onChange={() => setOrderChannel(channel)}
                      name="order_channel"
                      className="text-slate-900 focus:ring-slate-900"
                    />
                    <span>{channel === 'WhatsApp' ? 'واتساب' : channel === 'SMS' ? 'طلب رسالة SMS' : 'التطبيق الموحد'}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Real-time Dynamic Calculations / Relational Preview */}
          {selectedSupplierId && (
            <div className="mt-6 space-y-4">
              <div className="bg-slate-900/5 border border-slate-300 p-4 rounded-xl grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="text-center md:text-right">
                  <span className="text-slate-500 text-[10px] block font-bold font-sans">سعر المتر للمستهلك</span>
                  <span className="font-mono text-sm font-bold text-slate-800">{calculatedPrices.pricePerUnit.toLocaleString('ar-YE')} ريال</span>
                </div>
                <div className="text-center md:text-right">
                  <span className="text-slate-500 text-[10px] block font-bold font-sans">التكلفة من المورد</span>
                  <span className="font-mono text-sm font-bold text-slate-600">{calculatedPrices.supplierPrice.toLocaleString('ar-YE')} ريال</span>
                </div>
                <div className="text-center md:text-right p-1.5 bg-emerald-50 rounded-lg">
                  <span className="text-emerald-800 text-[10px] block font-extrabold flex items-center gap-0.5 font-sans">
                    الرسوم والنسب (1100) <ArrowUpRight className="w-3 h-3 text-emerald-600" />
                  </span>
                  <span className="font-mono text-sm font-extrabold text-emerald-700">+{calculatedPrices.profit.toLocaleString('ar-YE')} ريال</span>
                </div>
                <div className="text-center md:text-right">
                  <span className="text-slate-500 text-[10px] block font-bold font-sans">مستحقات الكسارة الفروق</span>
                  <span className="font-mono text-sm font-bold text-indigo-700">{calculatedPrices.supplierShare.toLocaleString('ar-YE')} ريال</span>
                </div>
                <div className="text-center md:text-right col-span-2 md:col-span-1 p-1.5 bg-slate-900 text-white rounded-lg">
                  <span className="text-slate-400 text-[10px] block font-bold font-sans">إجمالي الفاتورة م³</span>
                  <span className="font-mono text-sm font-bold text-amber-400">{calculatedPrices.total.toLocaleString('ar-YE')} ريال</span>
                </div>
              </div>

              {/* Detailed YER ratio distribution breakdown table */}
              <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm">
                <p className="text-xs font-extrabold text-slate-900 mb-2.5 border-b border-slate-100 pb-2 flex items-center gap-1.5 font-sans">
                  <span>📊</span>
                  <span>جدول تفاصيل توزيع التكلفة والنسب للمتر الواحد ولإجمالي الكمية ({quantity} م³):</span>
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 text-right">
                  <div className="bg-slate-50/50 border border-slate-100 p-2.5 rounded-lg">
                    <span className="text-[10px] text-slate-500 block font-sans">نسبة صاحب الكسارة (5,900)</span>
                    <span className="font-mono text-xs font-bold text-slate-800 block mt-1">{(5900 * quantity).toLocaleString('ar-YE')} ريال</span>
                    <span className="text-[9px] text-slate-400 block font-mono mt-0.5">5,900 × {quantity}</span>
                  </div>
                  <div className="bg-slate-50/50 border border-slate-100 p-2.5 rounded-lg">
                    <span className="text-[10px] text-slate-500 block font-sans">المكتب والموظفين (200)</span>
                    <span className="font-mono text-xs font-bold text-slate-700 block mt-1">{(200 * quantity).toLocaleString('ar-YE')} ريال</span>
                    <span className="text-[9px] text-slate-400 block font-mono mt-0.5">200 × {quantity}</span>
                  </div>
                  <div className="bg-slate-50/50 border border-slate-100 p-2.5 rounded-lg">
                    <span className="text-[10px] text-slate-500 block font-sans font-sans">نسبة المحور (200)</span>
                    <span className="font-mono text-xs font-bold text-slate-700 block mt-1">{(200 * quantity).toLocaleString('ar-YE')} ريال</span>
                    <span className="text-[9px] text-slate-400 block font-mono mt-0.5">200 × {quantity}</span>
                  </div>
                  <div className="bg-slate-50/50 border border-slate-100 p-2.5 rounded-lg">
                    <span className="text-[10px] text-slate-500 block font-sans">هيئة الجيولوجيا (200)</span>
                    <span className="font-mono text-xs font-bold text-slate-700 block mt-1">{(200 * quantity).toLocaleString('ar-YE')} ريال</span>
                    <span className="text-[9px] text-slate-400 block font-mono mt-0.5">200 × {quantity}</span>
                  </div>
                  <div className="bg-emerald-50/30 border border-emerald-100 p-2.5 rounded-lg">
                    <span className="text-[10px] text-emerald-800 font-bold block font-sans">نسبة الركاز (500)</span>
                    <span className="font-mono text-xs font-bold text-emerald-700 block mt-1">{(500 * quantity).toLocaleString('ar-YE')} ريال</span>
                    <span className="text-[9px] text-emerald-600/80 block font-mono mt-0.5 font-bold">500 × {quantity}</span>
                  </div>
                </div>
                <div className="mt-3 text-[10px] text-slate-400 text-left border-t border-slate-100 pt-2 font-mono flex justify-between select-none">
                  <span>إجمالي توزيع النسب: {(7000 * quantity).toLocaleString('ar-YE')} ريال يمني</span>
                  <span>المعادلة المفوترة: 5,900 (صاحب الكسارة) + 1,100 (مجموع الرسوم والنسب) = 7,000 ريال / م³</span>
                </div>
              </div>
            </div>
          )}

          {/* Form validations and buttons */}
          <div className="mt-6 flex justify-end gap-3 border-t border-slate-205 pt-4">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 text-slate-700 hover:bg-slate-150 bg-slate-100 hover:bg-slate-200 rounded-xl font-extrabold text-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4 rotate-180" />
              <span>تراجع ورجوع للخلف</span>
            </button>
            <button
              type="submit"
              className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-5 py-2 rounded-lg inline-flex items-center gap-1.5 shadow-sm"
            >
              <Check className="w-4 h-4" />
              تأكيد الفاتورة وقيد وتحصيل الرسوم
            </button>
          </div>
        </form>
      )}

      {/* 2. Filters & Searches */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-4 bg-slate-50 p-4 rounded-xl border border-slate-100" id="filters-panel">
        <div className="relative flex-1">
          <label className="sr-only">البحث في السجلات</label>
          <input
            type="text"
            placeholder="ابحث برقم الفاتورة، اسم العميل، الكسارة..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-slate-200 rounded-xl pr-10 pl-4 py-2 text-xs focus:ring-2 focus:ring-slate-900 focus:outline-none"
            id="orders-search-input"
          />
          <Search className="absolute right-3.5 top-2.5 w-4.5 h-4.5 text-slate-400" />
        </div>

        <div className="flex flex-wrap items-center gap-3">
           {/* Status filter tab */}
          <div className="flex bg-white p-1 rounded-lg border border-slate-200 text-xs">
            {['All', 'Pending', 'Delivered', 'Cancelled'].map(status => {
              let label = 'الكل';
              if (status === 'Pending') label = 'معلق للمراجعة';
              if (status === 'Delivered') label = 'مسلم ومعتمد';
              if (status === 'Cancelled') label = 'ملغي';
              return (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status)}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                    statusFilter === status 
                      ? 'bg-slate-900 text-white' 
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>

          {/* Supplier selector filter */}
          <select
            value={supplierFilter}
            onChange={(e) => setSupplierFilter(e.target.value)}
            className="bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none"
          >
            <option value="All">جميع الكسارات الموردة</option>
            {suppliers.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* 3. Orders list - high fidelity table */}
      <div className="overflow-x-auto" id="orders-table-container">
        {filteredOrders.length === 0 ? (
          <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
            <HelpCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-800 text-sm font-semibold">لم نعثر على أي بوليصة شحن مطابقة للمرشحات</p>
            <p className="text-slate-400 text-xs mt-1">تأكد من كتابة مصطلح بحث صحيح أو تعديل خيارات الفلترة المتاحة.</p>
          </div>
        ) : (
          <table className="w-full text-right border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50 text-slate-500 font-semibold">
                <th className="py-3.5 px-4">رقم الإيصال</th>
                <th className="py-3.5 px-4">تاريخ الطلب</th>
                <th className="py-3.5 px-4">العميل</th>
                <th className="py-3.5 px-4">الكسارة</th>
                <th className="py-3.5 px-4">الصنف والكمية</th>
                <th className="py-3.5 px-4 text-left">مجموع التكلفة والبيع</th>
                <th className="py-3.5 px-4 text-left">الرسوم والتوزيعات (1100 ريال)</th>
                <th className="py-3.5 px-4 text-center">التدقيق والتسديد</th>
                <th className="py-3.5 px-4 text-center">حالة البوليصة</th>
                <th className="py-3.5 px-4 text-center">طباعة الفاتورة</th>
                {(currentRole === 'Admin' || currentRole === 'Sales Representative') && (
                  <th className="py-3.5 px-4 text-center">اعتماد الطلب والمطابقة</th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filteredOrders.map(order => (
                <tr 
                  key={order.id} 
                  className={`hover:bg-slate-50/80 transition-colors ${
                    order.status === 'Cancelled' ? 'bg-slate-100/50 opacity-60' : ''
                  }`}
                  id={`order-row-${order.id}`}
                >
                  {/* Order ID */}
                  <td className="py-3.5 px-4">
                    <span className="font-mono text-slate-900 font-bold bg-slate-100 px-2 py-1 rounded border border-slate-200">
                      {order.id}
                    </span>
                  </td>

                  {/* Date */}
                  <td className="py-3.5 px-4 text-slate-500 font-mono">
                    {new Date(order.date).toLocaleDateString('ar-YE', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </td>

                  {/* Customer */}
                  <td className="py-3.5 px-4">
                    <p className="text-slate-900 font-semibold">{order.customerName}</p>
                    <p className="text-[10px] text-slate-400 font-mono mt-0.5 border-r-2 border-slate-200 pr-1">{order.customerId}</p>
                  </td>

                  {/* Supplier */}
                  <td className="py-3.5 px-4">
                    <span className="text-indigo-950 font-bold">{order.supplierName}</span>
                  </td>

                  {/* Product + Qty */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-1.5">
                      <span className="bg-slate-100 border border-slate-200 text-slate-700 px-1.5 py-0.5 rounded font-bold">
                        {order.product}
                      </span>
                      <span className="bg-slate-900 text-white text-[10px] font-mono px-1.5 py-0.5 rounded-full font-bold">
                        {order.quantity} م³
                      </span>
                    </div>
                  </td>

                  {/* Financials / Net sale */}
                  <td className="py-3.5 px-4 text-left font-mono">
                    <div className="font-bold text-slate-900">{order.totalPrice.toLocaleString('ar-YE')} ريال</div>
                    <div className="text-[10px] text-slate-400">سعر المتر: {order.unitPrice} ريال</div>
                  </td>

                  {/* Administration fees split */}
                  <td className="py-3.5 px-4 text-left font-mono">
                    <span className="text-emerald-700 font-bold flex items-center justify-end gap-1">
                      +{order.commission.toLocaleString('ar-YE')}
                      <ArrowUpRight className="w-3.5 h-3.5 text-emerald-500" />
                    </span>
                    <span className="text-[10px] text-slate-400 font-sans">توزيعات الرسوم</span>
                  </td>

                  {/* Payment Info */}
                  <td className="py-3.5 px-4 text-center">
                    <div>
                      <span className={`inline-block text-[10px] px-2 py-0.5 rounded font-semibold ${
                        order.paymentMethod === 'Bank Transfer' 
                          ? 'bg-blue-50 text-blue-800 border border-blue-105 border-blue-200' 
                          : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      }`}>
                        {order.paymentMethod === 'Bank Transfer' ? 'حوالة بنكية' : 'نقدي'}
                      </span>
                    </div>
                    {order.transferNumber ? (
                      <p className="text-[10px] font-mono text-slate-500 mt-1 font-bold select-all" title="انقر لتنسخ الحوالة">
                        {order.transferNumber}
                      </p>
                    ) : (
                      <p className="text-[10px] text-slate-400 mt-1">-</p>
                    )}
                  </td>

                  {/* Status */}
                  <td className="py-3.5 px-4 text-center">
                    {getStatusBadge(order.status)}
                  </td>

                  {/* Print Invoice */}
                  <td className="py-3.5 px-4 text-center">
                    <button
                      onClick={() => setSelectedInvoiceOrder(order)}
                      className="bg-indigo-50/80 hover:bg-indigo-600 hover:text-white text-indigo-700 font-bold px-2.5 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all mx-auto cursor-pointer border border-indigo-200"
                      title="طباعة وتجهيز فاتورة البيع المعتمدة"
                    >
                      <Printer className="w-3.5 h-3.5 shrink-0" />
                      <span>فاتورة 🖨️</span>
                    </button>
                  </td>

                  {/* Tracking Lifecycle Controls / Actions */}
                  {(currentRole === 'Admin' || currentRole === 'Sales Representative') && (
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        {order.status === 'Pending' && (
                          <>
                            <button
                              onClick={() => onUpdateOrderStatus(order.id, 'Delivered')}
                              className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-2 py-1 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
                              title="تسليم وتأكيد تسوية الكسارة"
                            >
                              <Check className="w-3 h-3" />
                              <span>تأكيد التسليم</span>
                            </button>
                            <button
                              onClick={() => onUpdateOrderStatus(order.id, 'Cancelled')}
                              className="bg-rose-600 hover:bg-rose-700 text-white font-semibold px-2 py-1 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
                              title="إلغاء الطلب والتسوية"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>إلغاء</span>
                            </button>
                          </>
                        )}
                        {order.status === 'Delivered' && (
                          <span className="text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2 py-1 rounded-md text-[10px]">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>موزع ومعتمد</span>
                          </span>
                        )}
                        {order.status === 'Cancelled' && (
                          <span className="text-rose-600 flex items-center gap-1 bg-rose-50 px-2 py-1 rounded-md text-[10px]">
                            <XCircle className="w-3 h-3" />
                            <span>ملغي</span>
                          </span>
                        )}
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Invoice Printing & Preview Modal */}
      {selectedInvoiceOrder && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto print:bg-white print:p-0 print:absolute print:inset-0 animate-fade-in" id="invoice-modal">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-2xl w-full overflow-hidden text-right print:shadow-none print:border-none print:max-w-none print:m-0 print:rounded-none">
            
            {/* Printable Area */}
            <div className="p-8 print:p-4" id="printable-invoice">
              
              {/* Header */}
              <div className="flex justify-between items-start border-b-2 border-slate-900 pb-5 mb-6">
                <div>
                  <h2 className="text-lg font-black text-slate-900">نظام الكسارات الموحد 🏢</h2>
                  <p className="text-[10px] text-slate-500 font-bold mt-1">الجمهورية اليمنية - مبيعات الكري والخرسانة</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">فرع التوزيع الرئيسي الموحد للكسارات</p>
                </div>
                <div className="text-left">
                  <span className="bg-slate-900 text-white text-[10px] px-3 py-1 rounded font-black tracking-widest uppercase">
                    مستند فاتورة مبيعات
                  </span>
                  <div className="text-slate-900 font-mono text-[11px] mt-2 font-bold">
                    <div>رقم الفاتورة: <span className="text-indigo-600 font-black">#{selectedInvoiceOrder.id}</span></div>
                    <div>تاريخ الإصدار: {new Date(selectedInvoiceOrder.date).toLocaleDateString('ar-YE', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
                    <div>توقيت النظام: ٢٠ يونيو ٢٠٢٦ - ١:٤٣ ص</div>
                  </div>
                </div>
              </div>

              {/* Invoice Meta Grid */}
              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100 text-[11px] mb-6">
                <div>
                  <p className="text-slate-400 font-bold">العميل والمستفيد الأول:</p>
                  <p className="text-slate-900 font-extrabold text-xs mt-1">{selectedInvoiceOrder.customerName}</p>
                  <p className="text-slate-500 font-mono mt-0.5">معرّف العميل: {selectedInvoiceOrder.customerId}</p>
                </div>
                <div>
                  <p className="text-slate-400 font-bold">الجهة الموردة (الكسارة):</p>
                  <p className="text-slate-900 font-extrabold text-xs mt-1">{selectedInvoiceOrder.supplierName}</p>
                  <p className="text-slate-500 font-mono mt-0.5">رمز الكسارة المعتمد: {selectedInvoiceOrder.supplierId}</p>
                </div>
                <div>
                  <p className="text-slate-400 font-bold">طريقة تسديد القيمة:</p>
                  <p className="text-slate-900 font-extrabold mt-1">
                    {selectedInvoiceOrder.paymentMethod === 'Bank Transfer' ? 'حوالة مصرفية بنكية' : 'دفع نقدي مباشر'}
                  </p>
                  {selectedInvoiceOrder.transferNumber && (
                    <p className="text-indigo-600 font-mono font-bold mt-0.5">كود الحوالة: {selectedInvoiceOrder.transferNumber}</p>
                  )}
                </div>
                <div>
                  <p className="text-slate-400 font-bold">حالة البوليصة الحالية:</p>
                  <div className="mt-1">
                    {selectedInvoiceOrder.status === 'Delivered' ? (
                      <span className="text-emerald-700 font-extrabold bg-emerald-100/50 px-2.5 py-0.5 rounded-full text-[10px] border border-emerald-200">
                        ✓ معتمدة ومسلمة ومسجلة مالياً
                      </span>
                    ) : selectedInvoiceOrder.status === 'Pending' ? (
                      <span className="text-amber-700 font-extrabold bg-amber-100/50 px-2.5 py-0.5 rounded-full text-[10px] border border-amber-200">
                        ⏳ قيد المعالجة والتدقيق
                      </span>
                    ) : (
                      <span className="text-rose-700 font-extrabold bg-rose-100/50 px-2.5 py-0.5 rounded-full text-[10px] border border-rose-200">
                        ✗ ملغية وغير سارية
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Items Table */}
              <table className="w-full text-right border-collapse text-[11px] mb-8">
                <thead>
                  <tr className="border-b-2 border-slate-900 bg-slate-100 text-slate-800 font-black">
                    <th className="py-2 px-3">صنف الكري المباع</th>
                    <th className="py-2 px-3 text-center">الكمية المطلوبة</th>
                    <th className="py-2 px-3 text-left">سعر المتر</th>
                    <th className="py-2 px-3 text-left">تكلفة المادة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-700 font-semibold">
                  <tr>
                    <td className="py-3 px-3">
                      <span className="text-slate-900 font-bold">{selectedInvoiceOrder.product}</span>
                      <p className="text-[10px] text-slate-400 font-bold mt-0.5">درجة نقاوة كري ممتازة مطابقة لمواصفات الجودة</p>
                    </td>
                    <td className="py-3 px-3 text-center font-mono font-bold text-slate-900">
                      {selectedInvoiceOrder.quantity} م³
                    </td>
                    <td className="py-3 px-3 text-left font-mono text-slate-900">
                      {selectedInvoiceOrder.unitPrice.toLocaleString('ar-YE')} ريال
                    </td>
                    <td className="py-3 px-3 text-left font-mono text-slate-900">
                      {(selectedInvoiceOrder.quantity * selectedInvoiceOrder.unitPrice).toLocaleString('ar-YE')} ريال
                    </td>
                  </tr>
                  
                  {/* Financial calculation rows */}
                  <tr className="bg-slate-50/50 font-bold text-slate-800 border-t border-slate-300">
                    <td colSpan={2} className="py-2 px-3 text-slate-500">إجمالي قيمة الكري بالمتر:</td>
                    <td colSpan={2} className="py-2 px-3 text-left font-mono text-slate-900">
                      {(selectedInvoiceOrder.quantity * selectedInvoiceOrder.unitPrice).toLocaleString('ar-YE')} ريال
                    </td>
                  </tr>
                  <tr className="bg-slate-50/50 font-bold text-slate-800">
                    <td colSpan={2} className="py-2 px-3 text-slate-500">رسوم التوزيع الإدارية المشتركة (1100 ريال):</td>
                    <td colSpan={2} className="py-2 px-3 text-left font-mono text-emerald-700">
                      +{selectedInvoiceOrder.commission.toLocaleString('ar-YE')} ريال
                    </td>
                  </tr>
                  <tr className="bg-slate-900 text-white font-black text-xs">
                    <td colSpan={2} className="py-3 px-3">الإجمالي النهائي المطلوب سداده:</td>
                    <td colSpan={2} className="py-3 px-3 text-left font-mono text-amber-300 text-sm">
                      {selectedInvoiceOrder.totalPrice.toLocaleString('ar-YE')} ريال يمني
                    </td>
                  </tr>
                </tbody>
              </table>

              {/* Declaration terms */}
              <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-4 text-[10px] text-slate-600 leading-relaxed mb-10 text-right font-semibold">
                <span className="font-extrabold text-amber-800 block mb-1">📢 إقرار وتنبيه مالي مهم:</span>
                تعتبر هذه الفاتورة مستند مالي وقانوني معتمد لدى نظام الكسارات الموحد لإثبات مبيعات الكري والتسويات الضريبية وحصص الملاك (مطلق، عبد الخالق، عارف، صالح، مطارد، يونس، وأحمد). يلتزم سائق الناقلة بمطابقة سند التسليم الموزون في البوابة المادية قبل مغادرة نطاق الكسارة.
              </div>

              {/* Signature Blocks */}
              <div className="grid grid-cols-3 gap-4 text-center text-[10px] text-slate-500 pt-6 border-t border-dashed border-slate-300">
                <div>
                  <p className="font-extrabold text-slate-700 mb-10">إعداد / مندوب المبيعات</p>
                  <div className="border-b border-slate-300 mx-auto w-3/4 mb-1"></div>
                  <p className="font-mono text-slate-400">توقيع المندوب المعتمد</p>
                </div>
                <div>
                  <p className="font-extrabold text-slate-700 mb-10">استلام ومطابقة / الصندوق</p>
                  <div className="border-b border-slate-300 mx-auto w-3/4 mb-1"></div>
                  <p className="font-mono text-slate-400">توقيع أمين الصندوق</p>
                </div>
                <div>
                  <p className="font-extrabold text-slate-700 mb-10">الاعتماد النهائي / الإدارة</p>
                  <div className="border-b border-slate-300 mx-auto w-3/4 mb-1"></div>
                  <p className="font-mono text-slate-400">توقيع المدير أمير مطري</p>
                </div>
              </div>

            </div>

            {/* Modal Control Panel */}
            <div className="flex items-center justify-between gap-3 p-4 bg-slate-50 border-t border-slate-100 print:hidden">
              <button
                onClick={() => setSelectedInvoiceOrder(null)}
                className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-extrabold text-xs px-4 py-2.5 rounded-xl transition cursor-pointer active:scale-95"
              >
                إغلاق المعاينة ×
              </button>
              
              <button
                onClick={() => window.print()}
                className="bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs px-5 py-2.5 rounded-xl transition cursor-pointer active:scale-95 flex items-center gap-2 shadow-md shadow-slate-900/10"
              >
                <Printer className="w-4 h-4 text-amber-400" />
                <span>طباعة الفاتورة الفورية (Print Invoice) 🖨️</span>
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
