import React from 'react';
import { Order, Supplier, InventoryItem } from '../types';
import { TrendingUp, Coins, Clock, AlertTriangle, Layers, Wallet } from 'lucide-react';

interface StatsOverviewProps {
  orders: Order[];
  suppliers: Supplier[];
  inventory: InventoryItem[];
}

export default function StatsOverview({ orders, suppliers, inventory }: StatsOverviewProps) {
  // Total sales for Active orders (excluding Cancelled)
  const activeOrders = orders.filter(o => o.status !== 'Cancelled');
  const deliveredOrders = orders.filter(o => o.status === 'Delivered');

  const totalSales = activeOrders.reduce((sum, o) => sum + o.totalPrice, 0);
  const totalCommission = activeOrders.reduce((sum, o) => sum + o.commission, 0);
  
  // Total balance currently owed to suppliers
  const totalOwedToSuppliers = suppliers.reduce((sum, s) => sum + s.balance, 0);
  
  // Pending orders
  const pendingOrdersCount = orders.filter(o => o.status === 'Pending').length;

  // Inventory warnings
  const lowStockItems = inventory.filter(item => item.status === 'Low');

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4" id="stats-grid">
      {/* 1. Total Sales */}
      <div 
        className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between hover:shadow-md transition-all duration-300 relative overflow-hidden" 
        id="stat-card-total-sales"
      >
        <div className="flex justify-between items-start">
          <div>
            <p className="text-slate-500 text-xs font-semibold">إجمالي فواتير المبيعات</p>
            <p className="text-2xl font-bold font-mono text-slate-900 mt-2 tracking-tight">
              {totalSales.toLocaleString('ar-YE')} <span className="text-xs font-sans text-slate-400">ريال</span>
            </p>
          </div>
          <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-500">
          <span className="font-semibold text-emerald-600 font-mono">+{activeOrders.length}</span>
          <span>طلبيات إجمالية نشطة</span>
        </div>
        <div className="absolute bottom-0 right-0 left-0 h-1 bg-emerald-500"></div>
      </div>

      {/* 2. Management Distributed Fees (Calculated inside commission property) */}
      <div 
        className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between hover:shadow-md transition-all duration-300 relative overflow-hidden" 
        id="stat-card-commissions"
      >
        <div className="flex justify-between items-start">
          <div>
            <p className="text-slate-500 text-xs font-semibold">الرسوم والتوزيعات الموزعة</p>
            <p className="text-2xl font-bold font-mono text-emerald-700 mt-2 tracking-tight">
              {totalCommission.toLocaleString('ar-YE')} <span className="text-xs font-sans text-emerald-600">ريال</span>
            </p>
          </div>
          <div className="p-3 bg-amber-50 rounded-xl text-amber-600">
            <Coins className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4 text-xs text-slate-500 flex justify-between items-center">
          <span>متوسط نسبة الرسوم (1,100 ريال):</span>
          <span className="font-mono text-slate-700 font-semibold bg-slate-100 px-1.5 py-0.5 rounded">
            {totalSales > 0 ? ((totalCommission / totalSales) * 100).toFixed(1) : 0}%
          </span>
        </div>
        <div className="absolute bottom-0 right-0 left-0 h-1 bg-amber-500"></div>
      </div>

      {/* 3. Total Supplier Outstanding Indebtedness */}
      <div 
        className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between hover:shadow-md transition-all duration-300 relative overflow-hidden" 
        id="stat-card-suppliers-balance"
      >
        <div className="flex justify-between items-start">
          <div>
            <p className="text-slate-500 text-xs font-semibold">ذمم ومستحقات الكسارات</p>
            <p className="text-2xl font-bold font-mono text-indigo-700 mt-2 tracking-tight">
              {totalOwedToSuppliers.toLocaleString('ar-YE')} <span className="text-xs font-sans text-indigo-500">ريال</span>
            </p>
          </div>
          <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600">
            <Wallet className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-1 text-xs text-indigo-600">
          <span>موزعة على {suppliers.length} كسارات موردة</span>
        </div>
        <div className="absolute bottom-0 right-0 left-0 h-1 bg-indigo-600"></div>
      </div>

      {/* 4. Pending Validation Orders */}
      <div 
        className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between hover:shadow-md transition-all duration-300 relative overflow-hidden" 
        id="stat-card-active-deliveries"
      >
        <div className="flex justify-between items-start">
          <div>
            <p className="text-slate-500 text-xs font-semibold">طلبيات معلقة (للمراجعة)</p>
            <p className="text-2xl font-bold font-mono text-slate-800 mt-2 tracking-tight">
              {pendingOrdersCount} <span className="text-xs font-sans text-slate-400">طلبيات</span>
            </p>
          </div>
          <div className="p-3 bg-sky-50 rounded-xl text-sky-600">
            <Clock className="w-5 h-5" />
          </div>
        </div>
        <div className="mt-4 flex gap-2 items-center text-xs">
          <span className="flex h-2 w-2 rounded-full bg-amber-500 animate-pulse"></span>
          <span className="text-slate-500">بانتظار مطابقة الحوالات والتسليم</span>
        </div>
        <div className="absolute bottom-0 right-0 left-0 h-1 bg-sky-500"></div>
      </div>

      {/* 5. Inventory Items Warning */}
      <div 
        className={`p-5 rounded-2xl border shadow-xs flex flex-col justify-between hover:shadow-md transition-all duration-300 relative overflow-hidden ${
          lowStockItems.length > 0 
            ? 'bg-rose-50/70 border-rose-200' 
            : 'bg-white border-slate-200'
        }`}
        id="stat-card-warnings"
      >
        <div className="flex justify-between items-start">
          <div>
            <p className="text-slate-500 text-xs font-semibold">حالة مخزون الكري</p>
            <p className={`text-2xl font-bold font-mono mt-2 tracking-tight ${
              lowStockItems.length > 0 ? 'text-rose-600' : 'text-slate-900'
            }`}>
              {lowStockItems.length > 0 ? `${lowStockItems.length} أصناف متدنية` : 'مستقر وآمن'}
            </p>
          </div>
          <div className={`p-3 rounded-xl ${
            lowStockItems.length > 0 ? 'bg-rose-100 text-rose-600' : 'bg-slate-50 text-slate-400'
          }`}>
            {lowStockItems.length > 0 ? (
              <AlertTriangle className="w-5 h-5 animate-bounce-slow" />
            ) : (
              <Layers className="w-5 h-5" />
            )}
          </div>
        </div>
        <div className="mt-4 text-xs text-slate-500">
          {lowStockItems.length > 0 ? (
            <span className="text-rose-600 font-semibold">
              يجب زيادة الإنتاج للكسارات المتأثرة
            </span>
          ) : (
            <span>الكميات كافية لتغطية الشحنات الفورية</span>
          )}
        </div>
        <div className={`absolute bottom-0 right-0 left-0 h-1 ${
          lowStockItems.length > 0 ? 'bg-rose-505 bg-rose-600' : 'bg-slate-300'
        }`}></div>
      </div>
    </div>
  );
}
