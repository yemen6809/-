import React, { useState, useMemo } from 'react';
import { Supplier, SupplierTransaction, InventoryItem, PriceItem, User } from '../types';
import { 
  Building2, Receipt, ArrowUpRight, ArrowDownLeft, 
  Plus, Calendar, DollarSign, ListOrdered, CheckCircle2, Eye, ShieldAlert, FileMinus,
  Printer, Search, X, ChevronLeft
} from 'lucide-react';

interface SuppliersManagerProps {
  suppliers: Supplier[];
  transactions: SupplierTransaction[];
  prices: PriceItem[];
  inventory: InventoryItem[];
  currentRole: string;
  onAddTransaction: (txn: SupplierTransaction) => void;
  onRegisterProduction: (supplierId: string, productId: string, qtyToAdd: number) => void;
}

export default function SuppliersManager({
  suppliers,
  transactions,
  prices,
  inventory,
  currentRole,
  onAddTransaction,
  onRegisterProduction
}: SuppliersManagerProps) {
  // Active selected supplier for detailed ledger
  const [selectedSupplierId, setSelectedSupplierId] = useState<string | null>(null);
  
  // Payment Form States
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [paymentSupplierId, setPaymentSupplierId] = useState('');
  const [paymentAmount, setPaymentAmount] = useState<number>(10000);
  const [paymentDesc, setPaymentDesc] = useState('');

  // Production Form States
  const [showProductionForm, setShowProductionForm] = useState(false);
  const [productionSupplierId, setProductionSupplierId] = useState('');
  const [productionProductId, setProductionProductId] = useState('thumn');
  const [productionQty, setProductionQty] = useState<number>(100);

  // Statement Filters & Dialog States
  const [statementSearch, setStatementSearch] = useState('');
  const [statementTypeFilter, setStatementTypeFilter] = useState<'all' | 'Sale' | 'Payment' | 'Production'>('all');
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Active Ledger details
  const activeSupplier = useMemo(() => {
    return suppliers.find(s => s.id === (selectedSupplierId || ''));
  }, [selectedSupplierId, suppliers]);

  // Supplier's transaction history sorted chronologically
  const activeSupplierTransactions = useMemo(() => {
    if (!selectedSupplierId) return [];
    return transactions
      .filter(t => t.supplierId === selectedSupplierId)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [selectedSupplierId, transactions]);

  // Calculate Running Balances for the Ledger
  const statementOfAccount = useMemo(() => {
    let running = 0;
    return activeSupplierTransactions.map(txn => {
      // Sales increaes balance (+), Payments decrease balance (-)
      // Production could increase balance or just inventory. Let's say Sale/Production increases balance.
      const factor = txn.type === 'Payment' ? -1 : 1;
      const change = txn.amount * factor;
      running += change;
      return {
        ...txn,
        change,
        runningBalance: running
      };
    }).reverse(); // display newest first
  }, [activeSupplierTransactions]);

  // Filtered statement of account for search and tab values
  const filteredStatementOfAccount = useMemo(() => {
    return statementOfAccount.filter(txn => {
      // matches type
      if (statementTypeFilter !== 'all' && txn.type !== statementTypeFilter) {
        return false;
      }
      // matches search
      if (statementSearch) {
        const searchLower = statementSearch.toLowerCase();
        const descMatches = txn.description?.toLowerCase().includes(searchLower);
        const idMatches = txn.id.toLowerCase().includes(searchLower);
        const productMatches = txn.product?.toLowerCase().includes(searchLower);
        return descMatches || idMatches || productMatches;
      }
      return true;
    });
  }, [statementOfAccount, statementTypeFilter, statementSearch]);

  // Active supplier financial summaries
  const activeSupplierStats = useMemo(() => {
    let sales = 0;
    let payments = 0;
    let production = 0;
    
    activeSupplierTransactions.forEach(t => {
      if (t.type === 'Sale') sales += t.amount;
      else if (t.type === 'Payment') payments += t.amount;
      else if (t.type === 'Production') production += t.amount;
    });

    return {
      totalSales: sales,
      totalPayments: payments,
      totalProduction: production,
      netBalance: sales - payments
    };
  }, [activeSupplierTransactions]);

  // Handle Payment Submit
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentSupplierId) return;
    if (paymentAmount <= 0) {
      alert('الرجاء كتابة مبلغ سداد صحيح');
      return;
    }

    const matchedSupplier = suppliers.find(s => s.id === paymentSupplierId);
    if (!matchedSupplier) return;

    const numericIds = transactions.map(t => {
      const match = t.id.match(/\d+/);
      return match ? parseInt(match[0], 10) : 0;
    });
    const maxId = Math.max(0, ...numericIds);
    const nextTxnId = `TXN-${maxId + 1}`;

    const newTxn: SupplierTransaction = {
      id: nextTxnId,
      supplierId: paymentSupplierId,
      type: 'Payment',
      amount: paymentAmount, // Store positive value, transaction log reduces balance during ledger calculation
      date: new Date().toISOString(),
      description: paymentDesc || `سند صرف مسدد للكسارة: ${matchedSupplier.name}`
    };

    onAddTransaction(newTxn);
    
    // Reset
    setShowPaymentForm(false);
    setPaymentSupplierId('');
    setPaymentAmount(1000);
    setPaymentDesc('');
  };

  // Handle Production Submit
  const handleProductionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productionSupplierId) return;
    if (productionQty <= 0) {
      alert('الرجاء تحديد كمية إنتاج صالحة');
      return;
    }

    const matchedSupplier = suppliers.find(s => s.id === productionSupplierId);
    if (!matchedSupplier) return;

    // Call state modifier to add stock
    onRegisterProduction(productionSupplierId, productionProductId, productionQty);

    // Register a transaction
    const prodItemsMapping: Record<string, string> = {
      thumn: 'ثمن (حصى 1/8)',
      rub: 'ربع (حصى 1/4)',
      nuss: 'نصف (مخلوط 1/2)'
    };

    const numericIds = transactions.map(t => {
      const match = t.id.match(/\d+/);
      return match ? parseInt(match[0], 10) : 0;
    });
    const maxId = Math.max(0, ...numericIds);
    const nextTxnId = `TXN-${maxId + 1}`;

    const newTxn: SupplierTransaction = {
      id: nextTxnId,
      supplierId: productionSupplierId,
      type: 'Production',
      amount: 0, // Stock-only correction
      quantity: productionQty,
      product: prodItemsMapping[productionProductId] || 'حصى مخلوط',
      date: new Date().toISOString(),
      description: `شحن مخزني يدوي - إنتاج جديد بمقدار ${productionQty} م³ للصنف ${prodItemsMapping[productionProductId]}`
    };

    onAddTransaction(newTxn);

    // Reset
    setShowProductionForm(false);
    setProductionSupplierId('');
    setProductionQty(100);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="suppliers-module">
      
      {/* 1. Suppliers Ledger Roster */}
      <div className="lg:col-span-1 bg-white rounded-2xl border border-slate-205 border-slate-200 p-6 flex flex-col justify-between" id="suppliers-roster">
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
              <Building2 className="text-slate-500 w-5 h-5" />
              الكسارات وشركاء التوريد
            </h3>
            <span className="bg-slate-100 text-slate-700 text-[10px] px-2 py-0.5 rounded-full font-bold">
              {suppliers.length} موردين
            </span>
          </div>
          <p className="text-slate-400 text-xs mb-6">قائمة الكسارات والذمم والمستحقات والاعتمادات والإنتاج الفعلي.</p>

          <div className="space-y-3" id="supplier-cards-list">
            {suppliers.map(s => {
              const worksAsQuarry = s.id === selectedSupplierId;
              return (
                <div 
                  key={s.id} 
                  onClick={() => {
                    setSelectedSupplierId(s.id);
                    // smooth scroll fallback for mobile screens or desktop views
                    setTimeout(() => {
                      const panel = document.getElementById('supplier-statement-panel');
                      if (panel) {
                        panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }
                    }, 100);
                  }}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    worksAsQuarry 
                      ? 'bg-slate-900 border-slate-900 text-white shadow-md' 
                      : 'bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-800'
                  }`}
                  id={`supplier-item-${s.id}`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className={`font-bold text-xs ${worksAsQuarry ? 'text-white' : 'text-slate-900'}`}>{s.name}</p>
                      <p className={`text-[9px] mt-0.5 font-mono ${worksAsQuarry ? 'text-slate-330 text-slate-400' : 'text-slate-400'}`}>{s.id}</p>
                    </div>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-extrabold ${
                      worksAsQuarry ? 'bg-amber-500 text-slate-950' : 'bg-slate-200 text-slate-800'
                    }`}>
                      قيد الفروق
                    </span>
                  </div>

                  <div className="mt-4 flex justify-between items-end border-t pt-3.5 border-dashed border-slate-700/20">
                    <div>
                      <span className={`text-[10px] block ${worksAsQuarry ? 'text-slate-400' : 'text-slate-500'}`}>الرصيد المعلق المستحق:</span>
                      <span className="font-mono font-bold text-sm">
                        {s.balance.toLocaleString('ar-YE')} <span className="text-[10px]">ريال</span>
                      </span>
                    </div>

                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedSupplierId(s.id);
                        setIsPrintModalOpen(true);
                        // smooth scroll fallback for mobile screens
                        setTimeout(() => {
                          const panel = document.getElementById('supplier-statement-panel');
                          if (panel) {
                            panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
                          }
                        }, 100);
                      }}
                      className={`text-[10px] font-semibold flex items-center gap-1 px-2 py-1 rounded-lg ${
                        worksAsQuarry ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-slate-200 hover:bg-slate-300'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      كشف الحساب
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Action triggers */}
        {currentRole === 'Admin' && (
          <div className="mt-8 pt-4 border-t border-slate-100 flex flex-col md:flex-row gap-2">
            <button
              onClick={() => {
                setShowPaymentForm(true);
                setShowProductionForm(false);
                if (suppliers.length > 0) setPaymentSupplierId(suppliers[0].id);
                // smooth scroll down to payment form
                setTimeout(() => {
                  const formEl = document.getElementById('form-supplier-payment');
                  if (formEl) {
                    formEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }
                }, 100);
              }}
              className="flex-1 text-center bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 rounded-xl flex items-center justify-center gap-1 pb-3"
            >
              <Receipt className="w-4 h-4" />
              سند صرف للكسارة (تسوية مالي)
            </button>

            <button
              onClick={() => {
                setShowProductionForm(true);
                setShowPaymentForm(false);
                if (suppliers.length > 0) setProductionSupplierId(suppliers[0].id);
                // smooth scroll down to production form
                setTimeout(() => {
                  const formEl = document.getElementById('form-supplier-production');
                  if (formEl) {
                    formEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }
                }, 100);
              }}
              className="flex-1 text-center bg-slate-905 bg-slate-900 hover:bg-slate-805 hover:bg-slate-800 text-white font-bold text-xs py-2.5 rounded-xl flex items-center justify-center gap-1 pb-3"
            >
              <Plus className="w-4 h-4" />
              تسجيل عملية إنتاج ومخزون
            </button>
          </div>
        )}
      </div>

      {/* 2. Transaction Logs & Ledger Details (Statement of Account) */}
      <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6" id="suppliers-ledger-logs">
        
        {/* State A: Add Outgoing Payment Form */}
        {showPaymentForm && (
          <form id="form-supplier-payment" onSubmit={handlePaymentSubmit} className="bg-emerald-50/75 border border-emerald-200 p-5 rounded-2xl mb-6 animate-slide-down">
            <div className="flex justify-between items-center gap-4 mb-3 pb-2 border-b border-emerald-100">
              <h4 className="font-bold text-emerald-900 text-xs flex items-center gap-1.5">
                <Receipt className="w-4 h-4 text-emerald-600" />
                سند صرف وتسوية نقدية للمورد (صرف مبلغ دفعة الحساب)
              </h4>
              <button 
                type="button" 
                onClick={() => setShowPaymentForm(false)}
                className="text-[10px] bg-white text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-xl hover:bg-emerald-50 font-bold flex items-center gap-1 transition cursor-pointer select-none"
              >
                <ChevronLeft className="w-3.5 h-3.5 rotate-180" />
                <span>رجوع للخلف ×</span>
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-emerald-800 mb-1">الجهة المستلمة (الكسارة)</label>
                <select
                  required
                  value={paymentSupplierId}
                  onChange={(e) => setPaymentSupplierId(e.target.value)}
                  className="w-full bg-white border border-emerald-300 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                >
                  <option value="">-- اختر الكسارة --</option>
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>{s.name} (رصيد: {s.balance.toLocaleString('ar-YE')} ريال)</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-emerald-800 mb-1">المبلغ المدفوع بالريال</label>
                <input
                  type="number"
                  required
                  min="1"
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(Number(e.target.value))}
                  className="w-full bg-white border border-emerald-300 rounded-xl px-3 py-2 text-xs font-mono focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-[10px] font-bold text-emerald-800 mb-1">وصف السند / رقم الحوالة أو الملاحظات</label>
                <input
                  type="text"
                  placeholder="مثال: حوالة كشف حساب النخبة - تسليم أمير مطري نقداً"
                  value={paymentDesc}
                  onChange={(e) => setPaymentDesc(e.target.value)}
                  className="w-full bg-white border border-emerald-300 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>
            </div>

            <div className="mt-4 flex justify-end gap-2 border-t border-emerald-250 border-emerald-200 pt-3">
              <button 
                type="button" 
                onClick={() => setShowPaymentForm(false)} 
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5 rotate-180" />
                <span>تراجع ورجوع للخلف</span>
              </button>
              <button 
                type="submit" 
                className="bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold px-4 py-1.5 rounded-lg"
              >
                تثبيت السند وتصفير الحساب
              </button>
            </div>
          </form>
        )}

        {/* State B: Register Production Form */}
        {showProductionForm && (
          <form id="form-supplier-production" onSubmit={handleProductionSubmit} className="bg-slate-100 border border-slate-200 p-5 rounded-2xl mb-6 animate-slide-down">
            <div className="flex justify-between items-center gap-4 mb-3 pb-2 border-b border-slate-200">
              <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-slate-600" />
                تسجيل وضخ إنتاج إضافي للمستودعات والسيلوهات (متر مكعب م³)
              </h4>
              <button 
                type="button" 
                onClick={() => setShowProductionForm(false)}
                className="text-[10px] bg-white text-slate-700 border border-slate-250 px-3 py-1.5 rounded-xl hover:bg-slate-50 font-bold flex items-center gap-1 transition cursor-pointer select-none"
              >
                <ChevronLeft className="w-3.5 h-3.5 rotate-180" />
                <span>رجوع للخلف ×</span>
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-700 mb-1">الكسارة</label>
                <select
                  required
                  value={productionSupplierId}
                  onChange={(e) => setProductionSupplierId(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none"
                >
                  <option value="">-- اختر الكسارة --</option>
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-700 mb-1">صنف الكري</label>
                <select
                  value={productionProductId}
                  onChange={(e) => setProductionProductId(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none"
                >
                  <option value="thumn">ثمن (حصى 1/8)</option>
                  <option value="rub">ربع (حصى 1/4)</option>
                  <option value="nuss">nuss نصف (مخلوط 1/2)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-700 mb-1">الكمية المصنعة (م³)</label>
                <input
                  type="number"
                  required
                  min="10"
                  value={productionQty}
                  onChange={(e) => setProductionQty(Number(e.target.value))}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono focus:outline-none"
                />
              </div>
            </div>

            <div className="mt-4 flex justify-end gap-2 border-t border-slate-200 pt-3">
              <button 
                type="button" 
                onClick={() => setShowProductionForm(false)} 
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5 rotate-180" />
                <span>تراجع ورجوع للخلف</span>
              </button>
              <button 
                type="submit" 
                className="bg-slate-900 hover:bg-slate-800 text-white text-[10px] font-bold px-4 py-1.5 rounded-lg"
              >
                ضخ المخزون الفعلي
              </button>
            </div>
          </form>
        )}

        {/* State C: Ledger Viewer (Statement of Account) */}
        {activeSupplier ? (
          <div id="supplier-statement-panel" className="transition-all">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-slate-900 text-white p-4 rounded-xl mb-4 gap-4">
              <div>
                <p className="text-[10px] text-slate-400">كشف الحساب المالي التفصيلي لـ</p>
                <h4 className="font-bold text-sm mt-0.5">{activeSupplier.name}</h4>
              </div>
              <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
                <div className="text-right">
                  <p className="text-[10px] text-slate-300">الرصيد المعلق:</p>
                  <p className="font-mono text-sm font-bold text-amber-400">
                    {activeSupplier.balance.toLocaleString('ar-YE')} <span className="text-[10px] font-sans text-slate-300">ريال</span>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsPrintModalOpen(true)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  طباعة الكشف
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedSupplierId(null)}
                  className="bg-slate-700 hover:bg-slate-600 text-white font-bold text-[10px] px-3 py-1.5 rounded-lg flex items-center gap-1 transition-all cursor-pointer shadow-sm"
                  title="رجوع للقائمة"
                >
                  <ChevronLeft className="w-3.5 h-3.5 rotate-180" />
                  <span>رجوع للخلف ×</span>
                </button>
              </div>
            </div>

            {/* Filters Bar */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              {/* Search */}
              <div className="relative font-sans">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="بحث في قيود الكشف (الرقم أو الوصف)..."
                  value={statementSearch}
                  onChange={(e) => setStatementSearch(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg pr-8 pl-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-slate-450 focus:ring-slate-400 font-sans"
                />
                {statementSearch && (
                  <button 
                    onClick={() => setStatementSearch('')}
                    className="absolute left-2.5 top-1.5 text-slate-400 hover:text-slate-600"
                  >
                    ×
                  </button>
                )}
              </div>
              
              {/* Type Category */}
              <div>
                <select
                  value={statementTypeFilter}
                  onChange={(e) => setStatementTypeFilter(e.target.value as any)}
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-xs focus:outline-none"
                >
                  <option value="all">كل المعاملات المالية المعتمدة</option>
                  <option value="Sale">مبيعات وفواتير الكري فقط</option>
                  <option value="Payment">سندات الصرف والتحويلات فقط</option>
                  <option value="Production">ضخ الإنتاج والمخزون فقط</option>
                </select>
              </div>
            </div>

            {/* Account Ledger Lists */}
            <div className="overflow-y-auto max-h-[350px] pr-1 space-y-3 font-sans" id="ledger-entries-container font-sans">
              {filteredStatementOfAccount.length === 0 ? (
                <div className="text-center py-12 text-slate-405 text-slate-400 text-xs border border-dashed border-slate-200 rounded-xl">
                  {statementOfAccount.length === 0 
                    ? "لا توجد أي معاملات مسجلة بعد لهذا المورد."
                    : "لم يتم العثور على أي قيود تطابق محددات البحث."}
                </div>
              ) : (
                filteredStatementOfAccount.map((txn, index) => {
                  const isPaymentOut = txn.type === 'Payment';
                  const isProduction = txn.type === 'Production';
                  
                  return (
                    <div 
                      key={txn.id} 
                      className={`p-3 rounded-xl border text-xs flex justify-between items-center transition-all ${
                        isPaymentOut 
                          ? 'bg-emerald-50/40 border-emerald-100/80 hover:bg-emerald-50' 
                          : isProduction 
                            ? 'bg-sky-50/40 border-sky-100/80 hover:bg-sky-50'
                            : 'bg-slate-50/40 border-slate-100/80 hover:bg-slate-50'
                      }`}
                      id={`ledger-txn-${txn.id}`}
                    >
                      {/* Typology and description */}
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg text-xs ${
                          isPaymentOut 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : isProduction 
                              ? 'bg-sky-100 text-sky-800' 
                              : 'bg-indigo-100 text-indigo-800'
                        }`}>
                          {isPaymentOut ? (
                            <ArrowDownLeft className="w-4 h-4" />
                          ) : isProduction ? (
                            <Building2 className="w-4 h-4" />
                          ) : (
                            <ArrowUpRight className="w-4 h-4" />
                          )}
                        </div>

                        <div>
                          <p className="font-bold text-xs text-slate-900">{txn.description}</p>
                          <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-450 text-slate-500 font-mono">
                            <span className="bg-white border text-slate-600 px-1 rounded">{txn.id}</span>
                            <span className="flex items-center gap-0.5 font-sans"><Calendar className="w-3 h-3" /> {new Date(txn.date).toLocaleDateString('ar-YE')}</span>
                          </div>
                        </div>
                      </div>

                      {/* Amounts */}
                      <div className="text-left font-mono">
                        <p className={`font-bold text-xs ${
                          isPaymentOut 
                            ? 'text-emerald-700' 
                            : isProduction 
                              ? 'text-sky-700' 
                              : 'text-indigo-700'
                        }`}>
                          {isPaymentOut ? '-' : '+'}{txn.amount.toLocaleString('ar-YE')} ريال
                        </p>
                        <p className="text-[9px] text-slate-400 mt-0.5">الرصيد الجاري: {txn.runningBalance.toLocaleString('ar-YE')}</p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        ) : (
          <div className="text-center py-20 text-slate-400 text-xs border border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center">
            <Building2 className="w-12 h-12 text-slate-350 text-slate-300 mb-3" />
            <p className="font-bold text-slate-700 text-sm">كشف الحساب المالي الموحد</p>
            <p className="text-slate-400 mt-1 max-w-xs font-sans">انقر على أي كرت كسارة على الجانب الأيمن أو انقر على زر "كشف الحساب" لاستدعاء القيود والتدقيق المالي الفوري.</p>
          </div>
        )}

      </div>

      {/* Printable official ledger statement of accounts model */}
      {isPrintModalOpen && activeSupplier && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 z-50 overflow-y-auto font-sans" id="statement-print-dialog">
          <div id="statement-print-dialog-card" className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-300 overflow-hidden divide-y divide-slate-100 p-4 md:p-8 space-y-6">
            
            {/* Modal Header & Options */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 print:hidden">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-emerald-600" />
                <h3 className="font-black text-sm text-slate-900 font-sans">معاينة وتصدير كشف الحساب المعتمد للكسارة</h3>
              </div>
              <button 
                onClick={() => setIsPrintModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 p-2 rounded-full transition-all cursor-pointer text-lg leading-none"
                title="إغلاق"
              >
                ×
              </button>
            </div>

            {/* Printable Document Body content */}
            <div className="bg-white p-1 sm:p-2 text-right text-slate-800" id="official-ledger-sheet">
              {/* Official business header logo & grid */}
              <div className="border-b-4 border-double border-slate-900 pb-5 grid grid-cols-1 md:grid-cols-3 items-center gap-4 text-center md:text-right">
                <div>
                  <h2 className="text-sm font-black text-slate-950">الجمهورية اليمنية</h2>
                  <p className="text-xs text-slate-600 mt-0.5">نظام إدارة ومبيعات الكري والكسارات الموحد</p>
                  <p className="text-[10px] text-slate-400 mt-0.5 font-mono">تاريخ الاستخراج: {new Date().toLocaleDateString('ar-YE')} {new Date().toLocaleTimeString('ar-YE')}</p>
                </div>
                
                <div className="flex flex-col items-center justify-center">
                  <div className="w-12 h-12 bg-slate-100 border border-slate-900 rounded-full flex items-center justify-center font-black text-[10px] text-slate-900 mb-1">
                    كسارات الكري
                  </div>
                  <h1 className="text-base font-black text-slate-950 tracking-wide mt-1">كشف حـسـاب تـحـلـيـلي</h1>
                  <span className="text-[10px] border border-slate-800 px-3 py-0.5 rounded-full font-bold mt-1 bg-slate-50 text-slate-800 font-sans">نسخة معتمدة للتدقيق</span>
                </div>

                <div className="text-center md:text-left">
                  <h3 className="text-xs font-bold text-slate-950 font-sans">{activeSupplier.name}</h3>
                  <p className="text-[10px] text-slate-500 font-mono mt-0.5">رمز الحساب: {activeSupplier.id}</p>
                  <p className="text-[10px] text-slate-500 font-sans mt-0.5">طبيعة العقد: توريد وتوزيع الكري لشركاء التوريد</p>
                </div>
              </div>

              {/* Financial aggregates summaries */}
              <div className="my-6 grid grid-cols-1 sm:grid-cols-4 gap-4 font-sans" id="ledger-financial-dashboard">
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-right">
                  <span className="text-[10px] text-slate-500 block">إجمالي مبيعات وتوريد الكري (+):</span>
                  <span className="font-mono text-sm font-black text-indigo-700 block mt-1">
                    {activeSupplierStats.totalSales.toLocaleString('ar-YE')} <span className="text-[10px] font-sans">ريال</span>
                  </span>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-right">
                  <span className="text-[10px] text-slate-500 block">إجمالي الدفعات المسددة (-):</span>
                  <span className="font-mono text-sm font-black text-emerald-700 block mt-1">
                    {activeSupplierStats.totalPayments.toLocaleString('ar-YE')} <span className="text-[10px] font-sans">ريال</span>
                  </span>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-right">
                  <span className="text-[10px] text-slate-500 block">إجمالي سندات وصيانة وتوريد:</span>
                  <span className="font-mono text-sm font-black text-slate-500 block mt-1">
                    {activeSupplierTransactions.length} قيود محاسبية
                  </span>
                </div>

                <div className="bg-amber-500/10 border border-amber-300 text-amber-950 rounded-xl p-3 text-right">
                  <span className="text-[10px] text-amber-800 block font-bold font-sans">الرصيد المعلق الجاري والذمم المتممة:</span>
                  <span className="font-mono text-base font-black text-amber-700 block mt-1">
                    {activeSupplier.balance.toLocaleString('ar-YE')} <span className="text-[10px] font-sans text-amber-900">ريال يمني</span>
                  </span>
                </div>
              </div>

              {/* Mobile Horizontal Scroll Indicator Badge */}
              <div className="flex items-center gap-2 bg-indigo-50 border border-indigo-100 rounded-lg p-2.5 my-3 sm:hidden text-[10px] text-indigo-800 font-sans leading-relaxed print:hidden">
                <span className="animate-bounce">💡</span>
                <span>يمكنك سحب الجدول أفقياً (يمين/يسار) لاستعراض كافة تفاصيل كشف الحساب بالكامل.</span>
              </div>

              {/* Ledger ledger detail formal table */}
              <div className="border border-slate-200 rounded-xl overflow-x-auto mt-4" id="formal-ledger-receipt-table">
                <table className="w-full min-w-[720px] text-right text-[11px] border-collapse font-sans font-medium">
                  <thead>
                    <tr className="bg-slate-900 text-white font-black text-xs leading-normal">
                      <th className="p-3 text-right">الرقم المرجعي</th>
                      <th className="p-3 text-right font-sans">تاريخ القيد</th>
                      <th className="p-3 text-right font-sans">نوع الحركة</th>
                      <th className="p-3 text-right font-sans font-sans">بيـان المعـامـلة بالتفصيل</th>
                      <th className="p-3 text-left font-sans">مبلغ الحركة (ريال)</th>
                      <th className="p-3 text-left font-sans">الرصيد الجاري (ريال)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {activeSupplierTransactions.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="p-8 text-center text-slate-400 font-sans">لا توجد أي معاملات محاسبية صادرة في حساب هذا المورد.</td>
                      </tr>
                    ) : (
                      activeSupplierTransactions.map((txn, idx) => {
                        const isPayment = txn.type === 'Payment';
                        const isProduction = txn.type === 'Production';
                        return (
                          <tr key={txn.id} className="hover:bg-slate-55 hover:bg-slate-50 transition-colors font-mono">
                            <td className="p-3 text-right font-bold text-slate-900">{txn.id}</td>
                            <td className="p-3 text-right text-slate-500 font-sans">{new Date(txn.date).toLocaleDateString('ar-YE')}</td>
                            <td className="p-3 text-right">
                              <span className={`px-2 py-0.5 rounded text-[9px] font-bold font-sans ${
                                isPayment 
                                  ? 'bg-emerald-100 text-emerald-800' 
                                  : isProduction 
                                    ? 'bg-sky-100 text-sky-800'
                                    : 'bg-indigo-100 text-indigo-805 text-indigo-800'
                              }`}>
                                {isPayment ? 'سند صرف' : isProduction ? 'ضخ مخزون' : 'فاتورة مبيعات'}
                              </span>
                            </td>
                            <td className="p-3 text-right font-sans text-slate-800 max-w-xs">{txn.description}</td>
                            <td className={`p-3 text-left font-bold ${isPayment ? 'text-emerald-700' : 'text-slate-900'}`}>
                              {isPayment ? '-' : '+'}{txn.amount.toLocaleString('ar-YE')}
                            </td>
                            <td className="p-3 text-left font-extrabold text-slate-950 bg-slate-50">
                              {(idx === 0) 
                                ? txn.amount.toLocaleString('ar-YE')
                                : (activeSupplierTransactions.slice(0, idx + 1).reduce((acc, current) => {
                                    const sign = current.type === 'Payment' ? -1 : 1;
                                    return acc + (current.amount * sign);
                                  }, 0)).toLocaleString('ar-YE')}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {/* Terms and signatures placeholder */}
              <div className="mt-12 pt-6 border-t border-slate-200 grid grid-cols-2 gap-8 text-xs font-sans text-right leading-relaxed" id="ledger-attestations">
                <div className="space-y-4">
                  <h4 className="font-bold text-slate-950">إقرار الإدارة المالية والتدقيق:</h4>
                  <p className="text-[10px] text-slate-400 font-sans text-right">
                    نقر بصحة وأمانة كافة البيانات المحتسبة أعلاه وأن الدفعات المسددة تمت بموجب حوالات بنكية وسجلات بنكية أو فواتير توريدات الكري المستوية وبموجب سندات الصرف المنتظمة.
                  </p>
                  <div className="pt-8 flex flex-col gap-1.5 font-sans">
                    <span className="font-extrabold text-slate-800">توقيع المحاسب العام / إدارة الحسابات:</span>
                    <span className="text-[10px] text-slate-350">--------------------------------</span>
                  </div>
                </div>

                <div className="space-y-4 text-left">
                  <h4 className="font-bold text-slate-950 text-left">تأكيد واعتماد شريك توريد الكسارة:</h4>
                  <p className="text-[10px] text-slate-400 text-left font-sans">
                    يقر شريك الكسارة بالاعتماد والموافقة على كشف الحساب والذمم الثنائية المبينة أعلاه وقبول مطابقة جميع القيود الدفترية.
                  </p>
                  <div className="pt-8 flex flex-col gap-1.5 text-left items-end font-sans">
                    <span className="font-extrabold text-slate-800">توقيع وموافقة ممثل الكسارة المعتمد:</span>
                    <span className="text-[10px] text-slate-350">--------------------------------</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Print Dialogue Options */}
            <div className="pt-4 flex items-center justify-between gap-3 font-sans print:hidden">
              <button
                type="button"
                onClick={() => setIsPrintModalOpen(false)}
                className="text-slate-605 hover:bg-slate-100 hover:text-slate-705 bg-white border border-slate-200 text-xs font-bold px-4 py-2.5 rounded-xl transition-all cursor-pointer font-sans"
              >
                تراجع وإغلاق البانل
              </button>
              
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    window.print();
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black px-6 py-2.5 rounded-xl inline-flex items-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer font-sans"
                >
                  <Printer className="w-4 h-4" />
                  طباعة الكشف الفوري (أندرويد / PDF)
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
