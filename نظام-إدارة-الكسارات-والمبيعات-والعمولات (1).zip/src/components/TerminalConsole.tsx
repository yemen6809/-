import React, { useState, useEffect, useRef } from 'react';
import { Order, Supplier, InventoryItem, PriceItem, User, SupplierTransaction } from '../types';
import { 
  Terminal, Smartphone, Truck, ShieldCheck, Scale, FileText, AlertCircle, 
  Play, RefreshCw, Send, CheckCircle2, Search, ArrowUpRight, ArrowDownLeft,
  UserCheck, Layers, Clipboard, HelpCircle, HardDrive, Cpu, Wifi
} from 'lucide-react';

interface TerminalConsoleProps {
  orders: Order[];
  suppliers: Supplier[];
  inventory: InventoryItem[];
  prices: PriceItem[];
  users: User[];
  currentRole: string;
  activeUser: User;
  onAddOrder: (order: Order) => void;
  onUpdateOrderStatus: (orderId: string, newStatus: 'Pending' | 'Delivered' | 'Cancelled') => void;
  onAddTransaction: (txn: SupplierTransaction) => void;
  onRegisterProduction: (supplierId: string, productId: string, qtyToAdd: number) => void;
  onUpdateInventoryQty: (itemId: string, newQty: number) => void;
}

export default function TerminalConsole({
  orders,
  suppliers,
  inventory,
  prices,
  users,
  currentRole,
  activeUser,
  onAddOrder,
  onUpdateOrderStatus,
  onAddTransaction,
  onRegisterProduction,
  onUpdateInventoryQty
}: TerminalConsoleProps) {
  // Navigation tabs inside the terminal console
  const [terminalTab, setTerminalTab] = useState<'cli' | 'weighbridge' | 'driver-self' | 'telemetry'>('cli');

  // Interactive CLI commands state
  const [commandInput, setCommandInput] = useState('');
  const [cliHistory, setCliHistory] = useState<{ text: string; type: 'cmd' | 'resp' | 'error' | 'success' }[]>([
    { text: '==================================================', type: 'resp' },
    { text: '   نظام البوابة الطرفية - منفذ ميكرو ميزان القبان وتصاريح المرور v4.6', type: 'success' },
    { text: '   Terminal Gate Node: Active & Syncing on Port 3000', type: 'resp' },
    { text: '==================================================', type: 'resp' },
    { text: 'مرحباً بك مجدداً. اكتب "help" لمشاهدة قائمة الأوامر التفاعلية، أو تفقد الأقسام العلوية.', type: 'success' }
  ]);

  // Ref to automatically scroll CLI terminal scrollbox
  const cliEndRef = useRef<HTMLDivElement>(null);

  // Weighbridge loading scale simulation state
  const [wbTruckPlate, setWbTruckPlate] = useState('');
  const [wbSelectedOrder, setWbSelectedOrder] = useState<string>('');
  const [wbGrossWeight, setWbGrossWeight] = useState<number>(31.5); // Tons
  const [wbTareWeight, setWbTareWeight] = useState<number>(12.2); // Tons
  const [wbMaterialWeight, setWbMaterialWeight] = useState<number>(19.3); // Gross - Tare
  const [wbConversionResult, setWbConversionResult] = useState<number>(12.87); // weight into cubic meters
  const [wbMaterialDensity, setWbMaterialDensity] = useState<number>(1.5); // standard ton/cubic ratio
  const [weighbridgeError, setWeighbridgeError] = useState<string | null>(null);

  // Driver self-service query states
  const [driverSearchQuery, setDriverSearchQuery] = useState('');
  const [driverFoundOrders, setDriverFoundOrders] = useState<Order[]>([]);
  const [isDriverSearched, setIsDriverSearched] = useState(false);

  // Telemetry logs
  const [telemetryLogs, setTelemetryLogs] = useState<{ id: string; timestamp: string; nodeName: string; category: string; message: string }[]>([
    { id: '1', timestamp: '14:20:05', nodeName: 'SCALE-NODE-01', category: 'Scale Calibration', message: 'مستشعر الوزن الميكانيكي تم تصفيره وقراءته: 0.00 طن بنجاح' },
    { id: '2', timestamp: '14:21:44', nodeName: 'SYS-SYNC-DAEMON', category: 'Database Connect', message: 'تم سحب حمولة المخازن ومخطط السعر الآني بنجاح من الخادم الرئيسي' },
    { id: '3', timestamp: '14:22:15', nodeName: 'GATE-IR-CAMERA', category: 'OCR Scanner', message: 'تم رصد شاحنة بلوحة رقم "صنعاء - 94511" مجتازة حساس العارضة' }
  ]);

  // Recalculate material and cubic weight when gross/tare weights change
  useEffect(() => {
    const net = Math.max(0, wbGrossWeight - wbTareWeight);
    setWbMaterialWeight(parseFloat(net.toFixed(2)));
    // Volume m3 = weight in tons / density
    const vol = net / (wbMaterialDensity || 1.5);
    setWbConversionResult(parseFloat(vol.toFixed(2)));
  }, [wbGrossWeight, wbTareWeight, wbMaterialDensity]);

  // Scroll to bottom helper for CLI
  useEffect(() => {
    if (cliEndRef.current) {
      cliEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [cliHistory]);

  // Trigger command processing
  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = commandInput.trim().toLowerCase();
    if (!cmd) return;

    // Append user input
    const historyUpdate = [...cliHistory, { text: `quarry-terminal$ ${commandInput}`, type: 'cmd' as const }];

    let responseText = '';
    let responseType: 'resp' | 'error' | 'success' = 'resp';

    // Parse commands
    if (cmd === 'help' || cmd === '?' || cmd === 'مساعدة') {
      responseText = `الأوامر المتاحة في النظام المحادث الموحد:\n` +
        `  - help / مساعدة : لعرض هذه التعليمات.\n` +
        `  - status / الحالة : لعرض الوضع المالي الإجمالي وصافي التداولات الفورية.\n` +
        `  - inventory / المخزون : قائمة مقاسات الكري المتوفرة في السيلوهات بالمتر المكعب.\n` +
        `  - crushers / الكسارات : قائمة الكسارات المزودة وأرصدتها الحالية المترتبة عليها.\n` +
        `  - orders / الفواتير : ملخص عن آخر 5 شحنات وفواتير تم تقييدها بالنظام.\n` +
        `  - find <keyword> : ابحث برقم فاتورة أو اسم عميل (مثال: find بشير).\n` +
        `  - low-stock / تنبيه : لإثبات ومراقبة السيلوهات التي قاربت على النفاد.\n` +
        `  - system / نظام : معلومات الخادم الحالي والموانئ والمجالات النشطة.\n` +
        `  - clear / تصفير : مسح محتويات الشاشة البرمجية الحالية.`;
    } else if (cmd === 'clear' || cmd === 'تصفير') {
      setCliHistory([
        { text: '==================================================', type: 'resp' },
        { text: 'تمت تصفية شاشة الأوامر بنجاح - Terminal Cleared.', type: 'success' }
      ]);
      setCommandInput('');
      return;
    } else if (cmd === 'status' || cmd === 'الحالة') {
      const pendingCount = orders.filter(o => o.status === 'Pending').length;
      const deliveredCount = orders.filter(o => o.status === 'Delivered').length;
      const totalRevenue = orders.filter(o => o.status === 'Delivered').reduce((sum, o) => sum + o.totalPrice, 0);
      const totalComm = orders.filter(o => o.status === 'Delivered').reduce((sum, o) => sum + o.commission, 0);

      responseText = `--- حالة الأعمال الفورية المتصلة بكامير الميزان ---\n` +
        `  - الفواتير قيد التحميل المعلقة: ${pendingCount} فاتورة.\n` +
        `  - الفواتير المكتملة المنطلقة: ${deliveredCount} شحنة.\n` +
        `  - إجمالي تحصيلات الإيرادات: ${totalRevenue.toLocaleString()} ريال مبيعات.\n` +
        `  - إجمالي مخصص عمولات المكتب والرسوم: ${totalComm.toLocaleString()} ريال يمني.\n` +
        `  - الكسارات المسجلة بالمجموع المالي: ${suppliers.length} مقاطع كسارات نشطة.`;
      responseType = 'success';
    } else if (cmd === 'inventory' || cmd === 'المخزون') {
      responseText = `--- كميات السيلوهات الجارية وتراكم المخزن (م³) ---\n` +
        inventory.map(item => `  • ${item.product} (${item.crusher}): ${item.quantity.toLocaleString()} م³ [حالة: ${item.status === 'Low' ? '🚨 متدني' : '⏳ آمن'}]`).join('\n');
    } else if (cmd === 'crushers' || cmd === 'الكسارات') {
      responseText = `--- أرصدة الموردين وأصحاب الشقوفات المقيدة (ريال) ---\n` +
        suppliers.map(sup => `  • ${sup.name}: رصيد مستحق له: ${sup.balance.toLocaleString()} ريال`).join('\n');
    } else if (cmd === 'orders' || cmd === 'الفواتير') {
      const last5 = orders.slice(0, 5);
      responseText = `--- آخر فواتير الكري والطلبات المدخلة ---\n` +
        last5.map(o => `  • [${o.id}] اسم: ${o.customerName || 'عام'} | كسارة: ${o.supplierName} | حمولة: ${o.quantity} ${o.unit} | الكرت: ${o.status=== 'Delivered' ? '✅ تم النقل' : '⏳ قيد الميزان'}`).join('\n');
    } else if (cmd === 'low-stock' || cmd === 'تنبيه') {
      const low = inventory.filter(i => i.quantity < 350);
      if (low.length === 0) {
        responseText = `جميع كميات السيلوهات آمنة وممتازة! لا عجز في المخازن حالياً.`;
        responseType = 'success';
      } else {
        responseText = `⚠️ تنبيه من نفاذ المقاسات التالية:\n` +
          low.map(i => `  - ${i.product} بكسارة (${i.crusher}) الحالي: ${i.quantity} م³ فقط !`).join('\n');
        responseType = 'error';
      }
    } else if (cmd.startsWith('find ')) {
      const searchWord = cmd.substring(5).trim();
      if (!searchWord) {
        responseText = `الرجاء تحديد كلمة للبحث البوابي. مثال: find بشير`;
        responseType = 'error';
      } else {
        const matches = orders.filter(o => 
          o.id.toLowerCase().includes(searchWord) || 
          (o.customerName && o.customerName.toLowerCase().includes(searchWord)) ||
          o.supplierName.toLowerCase().includes(searchWord) ||
          o.product.toLowerCase().includes(searchWord)
        );

        if (matches.length === 0) {
          responseText = `لم يتم العثور على أي فاتورة بوابية تطابق المظهر: "${searchWord}"`;
          responseType = 'error';
        } else {
          responseText = `🚨 عثر على ${matches.length} فواتير تتبع الكلمة الدلالية:\n` +
            matches.map(m => `  - كود: ${m.id} | عميل: ${m.customerName || 'عام'} | شاحنة حمولة ${m.quantity}م³ من ${m.supplierName} [حالة: ${m.status}]`).join('\n');
          responseType = 'success';
        }
      }
    } else if (cmd === 'system' || cmd === 'نظام') {
      responseText = `--- خصائص البنية والاتصال للطرفية ---\n` +
        `  • Node IP: 127.0.0.1 (Reverse Proxied via Nginx)\n` +
        `  • Access Security Mode: Enabled (Role: ${activeUser.role} / User: ${activeUser.name})\n` +
        `  • Port Socket: 3000 (Internal Ingress Live Router)\n` +
        `  • System Frame Rate: Standard PWA Frame\n` +
        `  • Master DB State: Linked with Quarry main memory engine (Re-active)`;
    } else {
      responseText = `خطأ في إدخال السلسلة البرمجية: أمر غير معروف "${cmd}".\n` +
        `اكتب "help" لمعرفة قائمة التعليمات والأوامر المتاحة في البوابة الطرفية.`;
      responseType = 'error';
    }

    setCliHistory([...historyUpdate, { text: responseText, type: responseType }]);
    setCommandInput('');

    // Prepend a log to terminal telemetry
    const newTelLog = {
      id: Math.random().toString(),
      timestamp: new Date().toLocaleTimeString('ar-SA'),
      nodeName: 'USER-TERM-CONSOLE',
      category: 'CLI Execution',
      message: `المستخدم ${activeUser.name} قام بتنفيذ الأمر البرمجي [${cmd}]`
    };
    setTelemetryLogs(prev => [newTelLog, ...prev]);
  };

  // Process Weighbridge Weight submission (Gatepass dispatching)
  const handleWeighbridgeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setWeighbridgeError(null);

    const plate = wbTruckPlate.trim();
    if (!plate) {
      setWeighbridgeError('الرجاء إدخال رقم الشاحنة أو لوحة الترخيص.');
      return;
    }

    if (!wbSelectedOrder) {
      setWeighbridgeError('الرجاء اختيار الفاتورة / الطلب الذي يتم التوزين له حالياً.');
      return;
    }

    const orderObj = orders.find(o => o.id === wbSelectedOrder);
    if (!orderObj) {
      setWeighbridgeError('الفاتورة غير موجودة أو تم تصفيرها.');
      return;
    }

    if (orderObj.status === 'Delivered') {
      setWeighbridgeError('هذه الفاتورة تم توزينها وتصريح مرورها مسبقاً وتعتبر منطلقة حالياً.');
      return;
    }

    if (wbMaterialWeight <= 2) {
      setWeighbridgeError('وزن المورد المتبقي ضئيل جداً. يرجى مراجعة ميزان القبان القائم والإجمالي.');
      return;
    }

    // Success - update active order state to Delivered
    onUpdateOrderStatus(orderObj.id, 'Delivered');

    // Automatically check and deduct inventory level based on calculated weight/volume
    const inventoryItem = inventory.find(i => i.crusher === orderObj.supplierName && i.productId === orderObj.productId);
    if (inventoryItem) {
      // update inventory in parent state
      const actualDeductedVolume = Math.min(inventoryItem.quantity, wbConversionResult);
      onUpdateInventoryQty(inventoryItem.id, Math.max(0, inventoryItem.quantity - wbConversionResult));
    }

    // Add logging to telemetry
    const successLog = {
      id: Math.random().toString(),
      timestamp: new Date().toLocaleTimeString('ar-SA'),
      nodeName: 'WEIGHBRIDGE-AUTO-CALC',
      category: 'Weighing Out',
      message: `✅ ميزان القبان: تم توزين شاحنة [${plate}] بحمولة ${wbConversionResult}م³ من كري ${orderObj.product} ومطابقتها مع الطلب ${orderObj.id} بنجاح`
    };
    setTelemetryLogs(prev => [successLog, ...prev]);

    // Show prompt to operator
    alert(`✅ ميزان القبان وتصريح البوابة:\n\nتم التحقق من مطابقة الوزن للشاحنة ${plate}.\nتم تحويل حالة الطلب ${orderObj.id} إلى (تم التسليم والانطلاق ✅).\nتم حساب الوزن الصافي وهو: ${wbMaterialWeight} طن، ويساوي بالمكعب: ${wbConversionResult} م³ تم خصمها فوراً من مخزن الكسارة.`);
    
    // Clear state
    setWbTruckPlate('');
    setWbSelectedOrder('');
    setWbGrossWeight(31.5);
    setWbTareWeight(12.2);
  };

  // Simulating scale sensor reading
  const simulateScaleReading = () => {
    // Gross weight between 25 and 45 tons
    const simulatedGross = parseFloat((Math.random() * 20 + 25).toFixed(2));
    // Tare weight between 10 and 15 tons
    const simulatedTare = parseFloat((Math.random() * 5 + 10).toFixed(2));
    
    setWbGrossWeight(simulatedGross);
    setWbTareWeight(simulatedTare);

    const alertLog = {
      id: Math.random().toString(),
      timestamp: new Date().toLocaleTimeString('ar-SA'),
      nodeName: 'SCALE-SENSOR-DAEMON',
      category: 'Scale Realtime Reading',
      message: `تم رصد قراءة ميكانيكية حية من كمرات الميزان: إجمالي: ${simulatedGross} طن، فارغ: ${simulatedTare} طن`
    };
    setTelemetryLogs(prev => [alertLog, ...prev]);
  };

  // Driver search handler
  const handleDriverSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setIsDriverSearched(true);
    const text = driverSearchQuery.trim().toLowerCase();
    
    if (!text) {
      setDriverFoundOrders([]);
      return;
    }

    const matches = orders.filter(o => 
      o.id.toLowerCase().includes(text) || 
      (o.customerName && o.customerName.toLowerCase().includes(text)) ||
      o.product.toLowerCase().includes(text)
    );
    setDriverFoundOrders(matches);

    // adding log
    const searchLog = {
      id: Math.random().toString(),
      timestamp: new Date().toLocaleTimeString('ar-SA'),
      nodeName: 'GATEKEEPER-UI',
      category: 'Driver Self Search',
      message: `بوابة السائقين: تم البحث بالقرينة [${text}] وعثر على ${matches.length} نتائج`
    };
    setTelemetryLogs(prev => [searchLog, ...prev]);
  };

  return (
    <div id="terminal-console-root" className="bg-slate-900 text-slate-100 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden font-sans">
      
      {/* Console Header Bar */}
      <div className="bg-slate-950 px-6 py-4 flex flex-wrap justify-between items-center border-b border-slate-850 gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/15 text-emerald-400 rounded-xl border border-emerald-500/20 active:animate-spin">
            <Terminal className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-extrabold text-sm tracking-tight text-white flex items-center gap-2">
              <span>البوابة الطرفية المتصلة بميزان القبان</span>
              <span className="bg-emerald-500/10 text-emerald-400 text-[9px] px-1.5 py-0.5 rounded-md border border-emerald-500/20 font-mono">GATE-CONSOLE V4.6</span>
            </h2>
            <p className="text-[10px] text-slate-400 font-medium mt-0.5">وحدة الفحص التلقائي، الجسر الأرضي، والتحكم الفوري في شحن وصرف كميات الكري</p>
          </div>
        </div>

        {/* Live Network Sync Status */}
        <div className="flex items-center gap-4 text-xs font-mono text-slate-400">
          <div className="flex items-center gap-1.5 bg-emerald-950/40 text-emerald-400 px-2.5 py-1 rounded-lg border border-emerald-500/15">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-[10px] font-bold">مستقر ومتزامن غيوغرافياً</span>
          </div>
          <div className="flex items-center gap-1">
            <Cpu className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[9px]">Server-Node-Direct</span>
          </div>
        </div>
      </div>

      {/* Internal Navigation Sub-tabs */}
      <div className="bg-slate-950/70 px-4 py-2 border-b border-slate-850 flex flex-wrap gap-1.5">
        <button
          onClick={() => setTerminalTab('cli')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            terminalTab === 'cli'
              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-850'
          }`}
        >
          <CommandLineIcon className="w-3.5 h-3.5" />
          <span>موجه الأوامر البرمجي (Console CLI)</span>
        </button>

        <button
          onClick={() => setTerminalTab('weighbridge')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            terminalTab === 'weighbridge'
              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-850'
          }`}
        >
          <Scale className="w-3.5 h-3.5" />
          <span>ميزان قبان الجسر وقفل البوابة (Scale & Gate)</span>
        </button>

        <button
          onClick={() => setTerminalTab('driver-self')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            terminalTab === 'driver-self'
              ? 'bg-sky-500/10 text-sky-450 text-sky-400 border border-sky-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-850'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>خدمة السائق الذاتية وفحص التذاكر</span>
        </button>

        <button
          onClick={() => setTerminalTab('telemetry')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
            terminalTab === 'telemetry'
              ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-850'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>مراقب الأحداث واللوغارتيمات الآلي ({telemetryLogs.length})</span>
        </button>
      </div>

      {/* Main Terminal Viewbox */}
      <div className="p-6">

        {/* TAB 1: Console CLI Command Prompt */}
        {terminalTab === 'cli' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                <span>موجه الأوامر متصل مباشرة بسعة قاعدة البيانات الجارية.</span>
              </div>
              <button 
                onClick={() => {
                  setCliHistory([
                    { text: '==================================================', type: 'resp' },
                    { text: 'تمت إعادة ضبط موجه الأوامر - Terminal Refreshed', type: 'success' },
                    { text: 'اكتب "help" أو "الحالة" لاستلام كشف التقرير الفوري', type: 'resp' }
                  ]);
                }}
                className="text-[10px] text-slate-500 hover:text-slate-300 flex items-center gap-1 hover:underline cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>إعادة ضبط الموجه</span>
              </button>
            </div>

            {/* Simulated monitor frame */}
            <div className="bg-slate-950 border border-slate-850 p-4 rounded-2xl h-80 overflow-y-auto font-mono text-xs text-emerald-400 space-y-2 select-text shadow-inner">
              {cliHistory.map((item, index) => {
                let colorClass = 'text-slate-300';
                if (item.type === 'cmd') colorClass = 'text-sky-400 font-bold';
                else if (item.type === 'success') colorClass = 'text-emerald-400 font-bold';
                else if (item.type === 'error') colorClass = 'text-rose-400';

                return (
                  <pre key={index} className={`whitespace-pre-wrap ${colorClass}`}>
                    {item.text}
                  </pre>
                );
              })}
              <div ref={cliEndRef} />
            </div>

            {/* Input Bar */}
            <form onSubmit={handleCommandSubmit} className="flex gap-2">
              <div className="relative flex-1">
                <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-sky-400 font-mono font-bold select-none text-xs">
                  quarry-terminal$
                </span>
                <input
                  type="text"
                  value={commandInput}
                  onChange={(e) => setCommandInput(e.target.value)}
                  placeholder="اكتب الأمر هنا (مثال: help, status, inventory, crushers, low-stock) ثم اضغط Enter..."
                  className="w-full bg-slate-950 text-sky-200 font-mono text-xs pr-28 pl-4 py-3 rounded-xl border border-slate-850 focus:border-sky-500 focus:outline-none transition text-right"
                  dir="ltr"
                />
              </div>
              <button
                type="submit"
                className="bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs px-5 rounded-xl flex items-center gap-1.5 transition cursor-pointer select-none"
              >
                <span>إرسال</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>

            <div className="bg-slate-950/40 border border-slate-800 p-3 rounded-xl">
              <span className="text-[10px] text-slate-400 block mb-1 font-semibold">تلميح بوابي سريع:</span>
              <p className="text-[9.5px] text-slate-500 leading-relaxed font-sans">
                يمكنك التفاعل باللغة العربية أو الإنجليزية. جرب كتابة <strong className="text-sky-400 font-mono">الحالة</strong> لمسح شامل على كميات الإيرادات الإجمالية، أو <strong className="text-sky-400 font-mono">المخزون</strong> لمعرفة مستويات مكيال المخازن الحية للكسارات المترابطة.
              </p>
            </div>
          </div>
        )}

        {/* TAB 2: Weighbridge Loading Scale & Gate Control */}
        {terminalTab === 'weighbridge' && (
          <div className="space-y-6">
            <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800 flex flex-wrap justify-between items-center gap-4">
              <div className="space-y-0.5">
                <h3 className="font-extrabold text-xs text-amber-400 flex items-center gap-1.5">
                  <Scale className="w-4 h-4 text-amber-500" />
                  <span>محاكاة موازين القبان وجهاز الاستشعار الإلكتروني</span>
                </h3>
                <p className="text-[10px] text-slate-400">واجهة توزين وتسجيل أوزان النقل الصافية وتحويلها المباشر لأمتار مكعبة م³ مطابقة لمستند التوريد</p>
              </div>
              <button
                type="button"
                onClick={simulateScaleReading}
                className="bg-amber-600 hover:bg-amber-500 text-slate-950 font-black text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all transform active:scale-95 shadow-sm cursor-pointer select-none"
              >
                <RefreshCw className="w-3.5 h-3.5 text-slate-900 animate-spin-slow" />
                <span>أخذ قراءة حية من الميزان الأرضي</span>
              </button>
            </div>

            {weighbridgeError && (
              <div className="bg-rose-950/30 border border-rose-900/50 text-rose-300 text-xs p-3.5 rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4.5 h-4.5 text-rose-500 shrink-0" />
                <span>{weighbridgeError}</span>
              </div>
            )}

            <form onSubmit={handleWeighbridgeSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Scale Weights Display Panel */}
              <div className="md:col-span-1 bg-slate-950 border border-slate-850 p-5 rounded-2xl flex flex-col justify-between space-y-4">
                <div className="border-b border-slate-850 pb-3 text-center">
                  <span className="text-[10px] text-slate-400 font-bold block">مؤشر الوزن الإلكتروني الحـي</span>
                  <p className="text-2xl font-mono font-black text-amber-400 block mt-1 tracking-widest">{wbGrossWeight.toFixed(2)} طن</p>
                </div>

                <div className="grid grid-cols-2 gap-2 text-center text-xs">
                  <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-850">
                    <span className="text-[9px] text-slate-500 block">الوزن القائم (إجمالي)</span>
                    <span className="font-mono text-white font-bold">{wbGrossWeight} طن</span>
                  </div>
                  <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-850">
                    <span className="text-[9px] text-slate-500 block">الفارغ (شاحنة مفرغة)</span>
                    <span className="font-mono text-white font-bold">{wbTareWeight} طن</span>
                  </div>
                </div>

                <div className="bg-amber-500/5 border border-amber-500/20 p-3 rounded-xl text-center">
                  <span className="text-[10px] text-amber-400 block mb-0.5">الوزن الصافي للحمولة (المادة)</span>
                  <p className="text-xl font-mono font-extrabold text-amber-300">{wbMaterialWeight} طن</p>
                  
                  <div className="flex justify-between items-center mt-3 pt-1.5 border-t border-slate-850 text-[10px]">
                    <span className="text-slate-400">معامل الكثافة (طن/م³)</span>
                    <select
                      value={wbMaterialDensity}
                      onChange={(e) => setWbMaterialDensity(parseFloat(e.target.value) || 1.5)}
                      className="bg-slate-900 text-amber-300 border border-slate-800 text-[10px] rounded p-0.5"
                    >
                      <option value="1.5">1.50 (كري متوسط 3/4)</option>
                      <option value="1.6">1.60 (كري حجر جيري ثقيل)</option>
                      <option value="1.4">1.40 (زيرو ناعم ومغسول)</option>
                    </select>
                  </div>

                  <div className="bg-slate-950 mt-3 p-2 rounded-lg text-emerald-400 text-xs font-mono font-extrabold flex justify-between items-center">
                    <span className="text-slate-400 font-sans text-[9px]">الحجم المحسوب بالمكعب:</span>
                    <span>{wbConversionResult} م³</span>
                  </div>
                </div>
              </div>

              {/* Order Matching and Truck details */}
              <div className="md:col-span-2 space-y-4">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">رقم الشاحنة / اللوحة وتفاصيل الناقل</label>
                    <div className="relative">
                      <input
                        type="text"
                        value={wbTruckPlate}
                        onChange={(e) => setWbTruckPlate(e.target.value)}
                        placeholder="مثال: صنعاء - مؤقت 9251"
                        className="w-full bg-slate-950 border border-slate-850 p-2.5 rounded-xl text-xs font-bold text-white focus:border-amber-500 text-right pr-9"
                        required
                      />
                      <Truck className="w-4 h-4 text-slate-500 absolute right-3 top-3.5" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">حمولة الطلب المراد ربطه بالتوزين</label>
                    <select
                      value={wbSelectedOrder}
                      onChange={(e) => setWbSelectedOrder(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 p-2.5 rounded-xl text-xs font-bold text-white focus:border-amber-500"
                      required
                    >
                      <option value="">-- اختر طلب معلق قيد الميزان لتسويته --</option>
                      {orders.filter(o => o.status === 'Pending').map(order => (
                        <option key={order.id} value={order.id}>
                          {order.id} - العميل: {order.customerName || 'عام'} ({order.quantity} م³ من {order.supplierName})
                        </option>
                      ))}
                    </select>
                    <span className="text-[9px] text-slate-500 mt-1 block">تظهر فقط الطلبات المسجلة كـ "معلق شحن"</span>
                  </div>
                </div>

                {wbSelectedOrder && (
                  <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl space-y-3.5 text-xs">
                    <div className="flex items-center gap-1.5 text-slate-300 font-bold border-b border-slate-850 pb-2">
                      <FileText className="w-4 h-4 text-sky-400" />
                      <span>تفاصيل الفاتورة المرتبطة الموزنة:</span>
                    </div>
                    {(() => {
                      const selOrder = orders.find(o => o.id === wbSelectedOrder);
                      if (!selOrder) return null;
                      return (
                        <div className="grid grid-cols-2 gap-y-2 text-slate-400">
                          <div>
                            <span className="text-[10px] text-slate-500 block">العميل الفعلي</span>
                            <span className="font-semibold text-slate-200">{selOrder.customerName || 'نقد عام'}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-slate-500 block">مقاس الكري المطلوب</span>
                            <span className="font-semibold text-slate-200">{selOrder.product}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-slate-500 block">جهة التوريد (الكسارة)</span>
                            <span className="font-semibold text-slate-200">{selOrder.supplierName}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-slate-500 block">الكمية المسدد مسبقاً بقيمة</span>
                            <span className="font-bold text-emerald-400">{selOrder.quantity} م³</span>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                )}

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs py-3.5 rounded-xl transition cursor-pointer select-none flex items-center justify-center gap-2 shadow-lg"
                  >
                    <ShieldCheck className="w-4.5 h-4.5 text-slate-900" />
                    <span>تأكيد تسجيل الميزان الأرضي، خصم المخزن، وطباعة تصريح المرور للشاحنة</span>
                  </button>
                  <p className="text-[9.5px] text-slate-500 mt-2 text-center leading-relaxed">
                    بالنقر هنا سيتم تسجيل خروج وتجاوز الشاحنة، وسيقوم النظام آلياً بخصم الكمية المطروحة من مخزن الكري للكسارة، وترحيل حالة الفاتورة بالجهاز الرئيسي.
                  </p>
                </div>

              </div>

            </form>
          </div>
        )}

        {/* TAB 3: Driver Self Service Ticket Verification */}
        {terminalTab === 'driver-self' && (
          <div className="space-y-6">
            <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800 space-y-1.5 text-center max-w-xl mx-auto">
              <Smartphone className="w-8 h-8 text-sky-400 mx-auto mb-1 animate-bounce" />
              <h3 className="font-extrabold text-xs text-white">منصة وسيلو السائقين والناقلين للتحقق من الكرت والأوزان</h3>
              <p className="text-[10px] text-slate-400 px-4">
                تتيح هذه الشاشة الطرفية المبسطة للسائقين القادمين عند البوابة إدخال رقم الفاتورة أو اسمهم للتحقق الفوري من حالة الشحن وموقع التحميل وتوفير عناء الاتصال بالمكتب المالي.
              </p>
            </div>

            <form onSubmit={handleDriverSearch} className="max-w-xl mx-auto flex gap-2">
              <input
                type="text"
                value={driverSearchQuery}
                onChange={(e) => setDriverSearchQuery(e.target.value)}
                placeholder="أدخل اسم السائق، المشتري، أو رقم الفاتورة (مثال: مقبل ومقاصة)"
                className="flex-1 bg-slate-950 border border-slate-850 p-2.5 rounded-xl text-xs text-white text-right focus:border-sky-500"
              />
              <button
                type="submit"
                className="bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs px-5 rounded-xl transition cursor-pointer flex items-center gap-1 shrink-0"
              >
                <Search className="w-3.5 h-3.5" />
                <span>افحص الآن</span>
              </button>
            </form>

            {isDriverSearched && (
              <div className="max-w-2xl mx-auto space-y-3.5">
                <div className="flex justify-between items-center border-b border-slate-850 pb-2">
                  <span className="text-[10px] font-bold text-slate-400">نتائج كشف البوابة الذاتية:</span>
                  <button
                    type="button"
                    onClick={() => {
                      setIsDriverSearched(false);
                      setDriverSearchQuery('');
                      setDriverFoundOrders([]);
                    }}
                    className="text-[10px] bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-350 px-3 py-1 rounded-lg flex items-center gap-1 transition cursor-pointer"
                  >
                    <span>رجوع للخلف / مسح البحث ↩️</span>
                  </button>
                </div>
                
                {driverFoundOrders.length === 0 ? (
                  <div className="bg-slate-950 p-6 rounded-xl border border-slate-850 text-center text-xs text-slate-500">
                    لم يجد النظام أي طلب معلق أو مكتمل يطابق معايير البحث المدخلة. يرجى مراجعة إدارة الحركة.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-3">
                    {driverFoundOrders.map((ord) => (
                      <div key={ord.id} className="bg-slate-950 border border-slate-850 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="space-y-1 text-right">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="bg-slate-900 border border-slate-800 text-sky-400 font-mono text-[9.5px] px-2 py-0.5 rounded-md font-bold">رقم: {ord.id}</span>
                            <span className="text-[11px] font-extrabold text-white">{ord.customerName || 'مشتري عام'}</span>
                          </div>
                          <div className="text-[10.5px] text-slate-400 font-medium">
                            المطلوب شحنه: {ord.quantity} م³ من مقاس {ord.product} (كسارة {ord.supplierName})
                          </div>
                          <div className="text-[9.5px] text-slate-500">تاريخ الطلب المالي: {new Date(ord.date).toLocaleDateString('ar-YE')}</div>
                        </div>

                        <div className="flex items-center gap-3 shrink-0">
                          {ord.status === 'Delivered' ? (
                            <div className="bg-emerald-950/40 text-emerald-400 border border-emerald-500/15 text-[10px] font-bold px-3 py-1.5 rounded-xl flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              <span>تم التسجيل والتحميل (منطلق)</span>
                            </div>
                          ) : ord.status === 'Pending' ? (
                            <div className="bg-amber-950/40 text-amber-400 border border-amber-500/15 text-[10px] font-bold px-3 py-1.5 rounded-xl flex items-center gap-1 animate-pulse">
                              <Scale className="w-3.5 h-3.5 text-amber-500 animate-bounce" />
                              <span>معلق بانتظار الميزان والتحميل</span>
                            </div>
                          ) : (
                            <span className="bg-slate-900 text-slate-500 text-[10px] px-2 py-1 rounded">تم الإلغاء</span>
                          )}

                          <button
                            type="button"
                            onClick={() => alert(`🖨️ طباعة تذكرة ميزان القبان:\n\nرقم الكود: ${ord.id}\nالعميل: ${ord.customerName || 'عام'}\nالمادة: ${ord.product}\nالكمية: ${ord.quantity} م³\n\nتعتبر هذه الوثيقة ترخيص مرور رسمي لبوابة مصنع الكري.`)}
                            className="bg-slate-900 hover:bg-slate-800 text-slate-350 hover:text-white p-2 rounded-xl border border-slate-800 transition cursor-pointer"
                            title="طباعة التذكرة البوابية"
                          >
                            <FileText className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: Live Telemetry Logs Flow */}
        {terminalTab === 'telemetry' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-xs text-slate-400 font-bold">تسجيل حوادث نظام موازين المنافذ وعارضات البوابات (Realtime Stream)</span>
              <button
                onClick={() => {
                  setTelemetryLogs([
                    { id: Math.random().toString(), timestamp: new Date().toLocaleTimeString('ar-YE'), nodeName: 'LOG-CLEANER', category: 'Clear', message: 'تم تصفير وإخلاء سجل الهرتس للحركة للبوابات الطرفية' }
                  ]);
                }}
                className="text-[10px] text-slate-400 hover:text-rose-400 transition cursor-pointer"
              >
                تصفير السجل
              </button>
            </div>

            <div className="bg-slate-950 rounded-2xl border border-slate-850 overflow-hidden">
              <div className="bg-slate-900 border-b border-slate-850 p-2.5 grid grid-cols-12 text-[10px] font-bold text-slate-400 text-center font-sans">
                <span className="col-span-2">الوقت اللحظي</span>
                <span className="col-span-3">مستشعر المحطة الطرفية</span>
                <span className="col-span-2 text-sky-400">فئة الحدث</span>
                <span className="col-span-5 text-right">مضمون الرسالة والتصريح المقيد</span>
              </div>

              <div className="divide-y divide-slate-900 h-80 overflow-y-auto select-text font-mono text-[10.5px]">
                {telemetryLogs.map((log) => (
                  <div key={log.id} className="p-3 grid grid-cols-12 hover:bg-slate-900/40 transition gap-2 text-center items-center">
                    <span className="col-span-2 text-slate-500 ltr">{log.timestamp}</span>
                    <span className="col-span-3 text-slate-400 font-bold">{log.nodeName}</span>
                    <span className="col-span-2 text-sky-400 font-bold border border-sky-950/40 bg-sky-950/20 px-1 py-0.5 rounded text-[9.5px]">
                      {log.category}
                    </span>
                    <span className="col-span-5 text-right text-slate-300 font-medium font-sans truncate" title={log.message}>
                      {log.message}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-indigo-950/15 border border-indigo-900/30 p-3.5 rounded-xl flex items-start gap-2 text-[10px] text-indigo-300">
              <Cpu className="w-4 h-4 text-indigo-400 mt-0.5 shrink-0" />
              <div>
                <span className="font-extrabold block mb-0.5">شبكة الخوادم والـ Multi-Node:</span>
                <p className="leading-relaxed text-indigo-400/80 font-sans">
                  يتم مزامنة ومقاصة القيود آلياً عند حدوث أي وزن مالي. سيتمكن الكادر المعتمد لاحقاً من تشغيل حكّام كشف الحساب من المنفذ البوّابي للتحكم بآلية المبيعات في الزمن الحقيقي.
                </p>
              </div>
            </div>
          </div>
        )}

      </div>

    </div>
  );
}

// Simple fallback CLI terminal Command Line icon
function CommandLineIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24"
      width="24"
      height="24"
      stroke="currentColor"
      strokeWidth="2"
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={props.className}
      {...props}
    >
      <polyline points="4 17 10 11 4 5" />
      <line x1="12" y1="19" x2="20" y2="19" />
    </svg>
  );
}
