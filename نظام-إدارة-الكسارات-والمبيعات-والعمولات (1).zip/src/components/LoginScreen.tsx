import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { Lock, Eye, EyeOff, LogIn, KeyRound, AlertCircle, RefreshCw, Landmark, ShoppingBag, ShieldAlert } from 'lucide-react';

interface LoginScreenProps {
  users: User[];
  onLogin: (userId: string) => void;
  onUpdatePassword: (userId: string, newPass: string) => void;
}

export default function LoginScreen({ users, onLogin, onUpdatePassword }: LoginScreenProps) {
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isChangingPass, setIsChangingPass] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  // Group users by role for organized presentation
  const groupedUsers: Record<UserRole | 'Others', User[]> = {
    Admin: [],
    'Sales Representative': [],
    Accounting: [],
    Cashier: [],
    Owner: [],
    Customer: [],
    Marketing: [],
    Others: []
  };

  users.forEach(u => {
    if (groupedUsers[u.role]) {
      groupedUsers[u.role].push(u);
    } else {
      groupedUsers.Others.push(u);
    }
  });

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) {
      setError('الرجاء اختيار المستخدم أولاً.');
      return;
    }

    const expectedPass = selectedUser.password || '1234'; // Default to 1234 if not set
    if (password === expectedPass) {
      setError('');
      setSuccessMsg('تم تسجيل الدخول بنجاح! جاري تحويلك...');
      setTimeout(() => {
        onLogin(selectedUser.id);
      }, 800);
    } else {
      setError('كلمة المرور غير صحيحة! كلمة المرور الافتراضية هي 1234');
    }
  };

  const handleChangePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) {
      setError('الرجاء اختيار المستخدم لتغيير كلمة المرور الخاصة به.');
      return;
    }
    if (!newPassword) {
      setError('الرجاء إدخال كلمة المرور الجديدة.');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setError('كلمتا المرور غير متطابقتين.');
      return;
    }

    onUpdatePassword(selectedUser.id, newPassword);
    setSuccessMsg('تم تحديث كلمة المرور وحفظها تلقائياً بنجاح! يمكنك الآن تسجيل الدخول بها.');
    setError('');
    setIsChangingPass(false);
    setPassword('');
    setNewPassword('');
    setConfirmNewPassword('');
    setTimeout(() => {
      setSuccessMsg('');
    }, 4000);
  };

  const getRoleLabel = (role: UserRole) => {
    switch (role) {
      case 'Admin': return 'مدير مطلق النظام';
      case 'Sales Representative': return 'مندوب مبيعات معتمد';
      case 'Accounting': return 'مسؤول الحسابات المالية';
      case 'Cashier': return 'أمين الصندوق (القبض والصرف)';
      case 'Owner': return 'مالك كسارة / مستثمر شريك';
      case 'Customer': return 'زبون / عميل شركة خرسانية';
      case 'Marketing': return 'محلل تسويق وترويج';
      default: return 'مستخدم خارجي';
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden" dir="rtl">
      {/* Decorative Blur Backgrounds */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="bg-slate-900/85 border border-slate-800 backdrop-blur-xl w-full max-w-lg rounded-3xl p-6 sm:p-8 shadow-2xl relative z-10 transition-all">
        
        {/* Header Branding */}
        <div className="text-center space-y-3 mb-8">
          <div className="inline-flex p-3 bg-amber-500/10 text-amber-400 rounded-2xl border border-amber-500/20">
            <Landmark className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-wide">نظام الكسارات الموحد والذكي</h1>
            <p className="text-[11px] text-slate-400 mt-1">بوابة الدخول الموحدة للكوادر والعملاء ومالكي الكسارات v5.5</p>
          </div>
        </div>

        {/* Quick Credentials Info Box */}
        <div className="bg-slate-950/60 rounded-xl p-3.5 border border-slate-800/80 mb-6 text-right">
          <p className="text-[11px] text-amber-300 font-bold flex items-center gap-1.5 flex-row-reverse">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>تنويه وتوجيه للموظفين والملاك:</span>
          </p>
          <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">
            الرمز الافتراضي لجميع الحسابات التجريبية هو <strong className="text-white bg-slate-800 px-1.5 py-0.5 rounded">1234</strong>. يمكنك الضغط على "تغيير كلمة المرور" بالأسفل لتعيين كلمة مرور سرية خاصة بك وحفظها تلقائياً في متصفحك.
          </p>
        </div>

        {/* Error / Success Notifications */}
        {error && (
          <div className="bg-rose-500/15 border border-rose-500/30 text-rose-300 p-3.5 rounded-xl text-xs flex items-start gap-2.5 flex-row-reverse text-right mb-6 animate-shake">
            <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {successMsg && (
          <div className="bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 p-3.5 rounded-xl text-xs text-right mb-6 font-bold animate-pulse">
            {successMsg}
          </div>
        )}

        {/* Selected User Indicator */}
        {selectedUser && (
          <div className="bg-slate-800/50 rounded-xl p-3 border border-slate-700/50 mb-6 flex items-center justify-between flex-row-reverse text-right">
            <div>
              <span className="block text-[10px] text-slate-400 font-bold">المستخدم المحدد حالياً:</span>
              <span className="text-xs font-black text-white">{selectedUser.name}</span>
              <span className="block text-[9px] text-amber-400 font-mono mt-0.5">{getRoleLabel(selectedUser.role)}</span>
            </div>
            <button 
              onClick={() => { setSelectedUser(null); setError(''); }}
              className="text-[10px] text-slate-400 hover:text-slate-200 bg-slate-800 border border-slate-700 px-2.5 py-1 rounded-lg transition"
            >
              تغيير المستخدم
            </button>
          </div>
        )}

        {/* Phase 1: Select User from Predefined Structured Menu */}
        {!selectedUser ? (
          <div className="space-y-4">
            <label className="block text-right text-xs font-extrabold text-slate-300 mb-2">
              اختر اسم المستخدم الخاص بك لتسجيل الدخول:
            </label>
            <div className="max-h-[320px] overflow-y-auto pr-1 space-y-4 border border-slate-800 p-3 rounded-2xl bg-slate-950/40">
              {Object.entries(groupedUsers).map(([role, list]) => {
                if (list.length === 0) return null;
                return (
                  <div key={role} className="space-y-1.5 text-right">
                    <span className="text-[10px] font-bold text-amber-400 px-1 bg-amber-500/10 rounded border border-amber-500/15">
                      {getRoleLabel(role as UserRole)}
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 mt-1">
                      {list.map(u => (
                        <button
                          key={u.id}
                          onClick={() => setSelectedUser(u)}
                          type="button"
                          className="text-right p-2.5 bg-slate-900 border border-slate-800/80 hover:border-slate-700 hover:bg-slate-800/70 rounded-xl transition text-[11px] font-semibold text-slate-200 flex items-center justify-between"
                        >
                          <span className="truncate">{u.name}</span>
                          {u.role === 'Owner' && <span className="text-[9px] text-purple-400 shrink-0 font-mono">({u.ownedCrusher})</span>}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* Phase 2: Enter password OR Change password */
          !isChangingPass ? (
            <form onSubmit={handleLoginSubmit} className="space-y-5">
              <div className="space-y-2">
                <div className="flex justify-between items-center flex-row-reverse">
                  <label className="block text-right text-xs font-bold text-slate-300">
                    كلمة المرور:
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setIsChangingPass(true);
                      setError('');
                    }}
                    className="text-[10px] text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
                  >
                    <KeyRound className="w-3 h-3" />
                    <span>تغيير أو تعيين كلمة مرور جديدة لهذا الحساب</span>
                  </button>
                </div>

                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="أدخل كلمة المرور الخاصة بك..."
                    className="w-full text-right p-3.5 bg-slate-950 border border-slate-800 focus:border-amber-500 text-white rounded-xl text-xs placeholder-slate-600 focus:outline-none transition"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => { setSelectedUser(null); setError(''); }}
                  className="w-1/3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs py-3.5 rounded-xl border border-slate-700 transition cursor-pointer"
                >
                  رجوع للخلف
                </button>
                <button
                  type="submit"
                  className="w-2/3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs py-3.5 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10 transition cursor-pointer"
                >
                  <LogIn className="w-4 h-4" />
                  <span>دخول إلى لوحة النظام</span>
                </button>
              </div>
            </form>
          ) : (
            /* Set/Change Password Mode */
            <form onSubmit={handleChangePasswordSubmit} className="space-y-4">
              <h3 className="text-xs font-bold text-amber-400 text-right mb-1">
                تعديل وتعيين كلمة المرور للمستخدم: {selectedUser.name}
              </h3>
              
              <div className="space-y-1.5 text-right">
                <label className="block text-xs text-slate-300">كلمة المرور الجديدة:</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="أدخل كلمة المرور الجديدة..."
                  className="w-full text-right p-3 bg-slate-950 border border-slate-800 focus:border-amber-500 text-white rounded-xl text-xs focus:outline-none transition"
                  required
                />
              </div>

              <div className="space-y-1.5 text-right">
                <label className="block text-xs text-slate-300">تأكيد كلمة المرور الجديدة:</label>
                <input
                  type="password"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  placeholder="أعد إدخال كلمة المرور لتأكيدها..."
                  className="w-full text-right p-3 bg-slate-950 border border-slate-800 focus:border-amber-500 text-white rounded-xl text-xs focus:outline-none transition"
                  required
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsChangingPass(false);
                    setError('');
                  }}
                  className="w-1/2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs py-2.5 rounded-xl transition cursor-pointer"
                >
                  إلغاء وتراجع
                </button>
                <button
                  type="submit"
                  className="w-1/2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>حفظ وتعيين الآن</span>
                </button>
              </div>
            </form>
          )
        )}

      </div>
    </div>
  );
}
