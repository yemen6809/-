import React from 'react';
import { User, Supplier, Order, InventoryItem } from '../types';
import { Landmark, TrendingUp, Boxes, ListOrdered, Calendar, UserCheck, ShieldAlert } from 'lucide-react';

interface OwnerDashboardProps {
  activeUser: User;
  suppliers: Supplier[];
  orders: Order[];
  inventory: InventoryItem[];
}

export default function OwnerDashboard({
  activeUser,
  suppliers,
  orders,
  inventory
}: OwnerDashboardProps) {
  // Find the crusher owned by this user
  const ownedCrusherName = activeUser.ownedCrusher || '';
  
  // Find the supplier object representing this crusher
  const crusherDetails = suppliers.find(s => s.name === ownedCrusherName);
  
  // Filter inventory items for this crusher
  const crusherInventory = inventory.filter(i => i.crusher === ownedCrusherName);

  // Filter orders (sales) dispatched from this crusher
  const crusherOrders = orders.filter(o => o.supplierName === ownedCrusherName);

  // Calculate sum of quantities sold
  const totalQuantitySold = crusherOrders
    .filter(o => o.status === 'Delivered')
    .reduce((sum, o) => sum + o.quantity, 0);

  // Calculate total earnings generated for the supplier
  const totalRevenue = crusherOrders
    .filter(o => o.status === 'Delivered')
    .reduce((sum, o) => sum + o.supplierAmount, 0);

  return (
    <div className="space-y-6 text-right" dir="rtl" id="owner-dashboard-portal">
      
      {/* Top Welcome Alert Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 border border-slate-800 relative overflow-hidden shadow-xl">
        <div className="absolute top-0 left-0 w-48 h-48 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row-reverse justify-between items-start md:items-center gap-4">
          <div>
            <span className="bg-amber-500/20 text-amber-300 text-[10px] px-3 py-1 rounded-full font-black tracking-wider border border-amber-500/25">
              لوحة المستثمر والشريك المالك الآمنة 🔒
            </span>
            <h2 className="text-xl md:text-2xl font-black mt-3">
              أهلاً بك، المستثمر {activeUser.name}
            </h2>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              تقتصر صلاحياتك على الاطلاع على حسابات وحركة <strong className="text-amber-400 font-extrabold">{ownedCrusherName || 'الكسارة المحددة'}</strong> ومخزونها ومبيعاتها فقط، بما يضمن الخصوصية والأمان المالي التام.
            </p>
          </div>
          
          <div className="flex items-center gap-2 bg-slate-800/80 px-4 py-2.5 rounded-2xl border border-slate-700/50">
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <div className="text-right">
              <span className="block text-[9px] text-slate-400">الكيان المرتبط:</span>
              <span className="text-xs font-bold text-white">{ownedCrusherName}</span>
            </div>
          </div>
        </div>
      </div>

      {!ownedCrusherName ? (
        <div className="bg-rose-500/10 border border-rose-500/20 text-rose-300 p-6 rounded-2xl flex items-center gap-4 flex-row-reverse">
          <ShieldAlert className="w-8 h-8 shrink-0 text-rose-400" />
          <div>
            <h4 className="font-extrabold text-sm">خطأ في تهيئة الحساب</h4>
            <p className="text-xs mt-1">لم يتم ربط حسابك بكسارة محددة بالنظام. يرجى مراجعة أمير مطري (مدير النظام) لإسناد الكسارة المطلوبة.</p>
          </div>
        </div>
      ) : (
        <>
          {/* Key Metrics Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* 1. Crusher Ledger Account Balance */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm relative overflow-hidden flex flex-col justify-between min-h-[140px]">
              <div className="flex justify-between items-start flex-row-reverse">
                <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
                  <Landmark className="w-6 h-6" />
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 font-bold block">رصيد حسابك الجاري (الدائن)</span>
                  <span className="text-2xl font-black text-slate-900 font-mono block mt-1.5">
                    {(crusherDetails?.balance || 0).toLocaleString()} <span className="text-xs font-sans text-slate-500">ريال</span>
                  </span>
                </div>
              </div>
              <div className="text-[10px] text-indigo-600 font-medium bg-indigo-50/50 px-3 py-1.5 rounded-xl mt-3 text-center">
                صافي مستحقاتك المودعة حالياً بالصندوق والجاهزة للصرف
              </div>
            </div>

            {/* 2. Total Delivered Volume */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm relative overflow-hidden flex flex-col justify-between min-h-[140px]">
              <div className="flex justify-between items-start flex-row-reverse">
                <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl">
                  <Boxes className="w-6 h-6" />
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 font-bold block">إجمالي الكميات المباعة والمرحلة</span>
                  <span className="text-2xl font-black text-slate-900 font-mono block mt-1.5">
                    {totalQuantitySold.toLocaleString()} <span className="text-xs font-sans text-slate-500">م³</span>
                  </span>
                </div>
              </div>
              <div className="text-[10px] text-amber-700 font-medium bg-amber-50 px-3 py-1.5 rounded-xl mt-3 text-center">
                إجمالي الأمتار المصروفة والمحملة للعملاء بنجاح
              </div>
            </div>

            {/* 3. Total Generated Revenue */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm relative overflow-hidden flex flex-col justify-between min-h-[140px]">
              <div className="flex justify-between items-start flex-row-reverse">
                <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
                  <TrendingUp className="w-6 h-6" />
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 font-bold block">صافي قيمة مبيعات الكسارة</span>
                  <span className="text-2xl font-black text-slate-900 font-mono block mt-1.5">
                    {totalRevenue.toLocaleString()} <span className="text-xs font-sans text-slate-500">ريال</span>
                  </span>
                </div>
              </div>
              <div className="text-[10px] text-emerald-700 font-medium bg-emerald-50 px-3 py-1.5 rounded-xl mt-3 text-center">
                إجمالي قيمة الكري المقطع باستبعاد عمولة النظام المشغل
              </div>
            </div>

          </div>

          {/* Sub-grid for Silo stocks and Sales ledger */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Silo inventory - exclusive to their crusher */}
            <div className="lg:col-span-4 bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4">
              <div>
                <h3 className="text-xs font-black text-slate-900">🪘 رصيد سيلوهات المخزون بالكسارة</h3>
                <p className="text-[10px] text-slate-400 mt-1">الكميات الحالية المتبقية بمستودعات الكسارة.</p>
              </div>

              <div className="space-y-3 pt-2">
                {crusherInventory.map(item => (
                  <div key={item.id} className="bg-slate-50 rounded-xl p-3.5 border border-slate-150 space-y-1.5">
                    <div className="flex justify-between items-center flex-row-reverse text-xs">
                      <span className="font-bold text-slate-900">{item.product}</span>
                      <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                        item.status === 'High' ? 'bg-emerald-50 text-emerald-700' :
                        item.status === 'Low' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-700'
                      }`}>
                        {item.status === 'High' ? 'مخزون وافر' : item.status === 'Low' ? 'مخزون منخفض' : 'طبيعي'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center flex-row-reverse font-mono text-sm">
                      <span className="text-slate-400 text-xs">الكمية المتوفرة:</span>
                      <span className="font-extrabold text-slate-800">{item.quantity.toLocaleString()} م³</span>
                    </div>
                  </div>
                ))}
                {crusherInventory.length === 0 && (
                  <div className="text-center py-6 text-slate-400 text-xs">
                    لا توجد بيانات مخزون مدخلة لهذه الكسارة.
                  </div>
                )}
              </div>
            </div>

            {/* Sales ledger list - exclusive to their crusher */}
            <div className="lg:col-span-8 bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4">
              <div className="flex justify-between items-center flex-row-reverse pb-2 border-b border-slate-100">
                <div>
                  <h3 className="text-xs font-black text-slate-900">📋 سجل مبيعات الأصناف وحركة الشحن</h3>
                  <p className="text-[10px] text-slate-400 mt-1">قائمة بالأصناف المباعة والكميات المصروفة للعملاء من كسارتك.</p>
                </div>
                <span className="text-[10px] font-mono text-slate-400 font-bold bg-slate-50 border px-2.5 py-1 rounded-lg">
                  عدد العمليات: {crusherOrders.length}
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-right border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-150">
                      <th className="p-3">معرف الفاتورة</th>
                      <th className="p-3">الزبون / الناقل</th>
                      <th className="p-3">الصنف المباع</th>
                      <th className="p-3 text-center">الكمية</th>
                      <th className="p-3 text-left">قيمة الكسارة الصافية</th>
                      <th className="p-3 text-center">الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {crusherOrders.map(order => (
                      <tr key={order.id} className="border-b border-slate-100 hover:bg-slate-50/50 transition">
                        <td className="p-3 font-mono text-slate-400 text-[10px]">{order.id}</td>
                        <td className="p-3 font-bold text-slate-800">{order.customerName || 'زبون عام'}</td>
                        <td className="p-3 text-slate-700">{order.product}</td>
                        <td className="p-3 text-center font-mono font-bold text-slate-900">{order.quantity} م³</td>
                        <td className="p-3 text-left font-mono font-black text-emerald-600">
                          {order.supplierAmount.toLocaleString()} ريال
                        </td>
                        <td className="p-3 text-center">
                          <span className={`inline-block px-2 py-0.5 rounded-full text-[9px] font-bold ${
                            order.status === 'Delivered' ? 'bg-emerald-50 text-emerald-700' :
                            order.status === 'Cancelled' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-700'
                          }`}>
                            {order.status === 'Delivered' ? 'تم الشحن' :
                             order.status === 'Cancelled' ? 'ملغي' : 'انتظار المراجعة'}
                          </span>
                        </td>
                      </tr>
                    ))}
                    {crusherOrders.length === 0 && (
                      <tr>
                        <td colSpan={6} className="text-center py-12 text-slate-400">
                          لم يتم تسجيل أي عمليات بيع أو توريد من هذه الكسارة بعد.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        </>
      )}

    </div>
  );
}
