export type UserRole = 'Admin' | 'Customer' | 'Sales Representative' | 'Marketing' | 'Accounting' | 'Cashier' | 'Owner';

export interface User {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  password?: string;
  ownedCrusher?: string;
  role: UserRole;
  salesRepId?: string;
  status: 'Active' | 'Suspended';
  terminalAccess?: boolean;
}

export interface InventoryItem {
  id: string;
  crusher: string;
  productId: string;
  product: string;
  quantity: number;
  unit: string;
  status: 'Low' | 'Normal' | 'High';
}

export type PaymentMethod = 'Bank Transfer' | 'Cash';

export interface Order {
  id: string;
  customerId: string;
  customerName?: string;
  supplierId: string;
  supplierName: string;
  productId: string;
  product: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  totalPrice: number;
  commission: number;
  supplierAmount: number;
  status: 'Pending' | 'Delivered' | 'Cancelled';
  paymentMethod: PaymentMethod;
  transferNumber?: string;
  channel?: 'WhatsApp' | 'SMS' | 'App';
  date: string;
}

export interface PriceItem {
  id: string;
  crusher: string;
  productType: string;
  productId: string;
  pricePerUnit: number;
  supplierPrice: number;
  unit: string;
}

export interface Supplier {
  id: string;
  name: string;
  balance: number; // Balance owed to crusher (accumulated from completed sales, reduced by payments)
}

export interface SupplierTransaction {
  id: string;
  supplierId: string;
  orderId?: string;
  type: 'Production' | 'Sale' | 'Payment';
  amount: number; // negative for payments out, positive for accumulated sales/production costs
  quantity?: number;
  product?: string;
  date: string;
  description: string;
}
