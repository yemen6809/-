import { User, Supplier, InventoryItem, PriceItem, Order, SupplierTransaction } from './types';

export const INITIAL_USERS: User[] = [
  {
    id: 'USR-001',
    name: 'أمير مطري (مدير النظام)',
    email: 'amir@quarry.com',
    phone: '777123456',
    password: '1234',
    role: 'Admin',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-002',
    name: 'مصطفى (مندوب مبيعات)',
    email: 'mostafa@quarry.com',
    phone: '771222333',
    password: '1234',
    role: 'Sales Representative',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-003',
    name: 'علي (مندوب مبيعات 2)',
    email: 'ali@quarry.com',
    phone: '771444555',
    password: '1234',
    role: 'Sales Representative',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-004',
    name: 'مسؤول حسابات 1',
    email: 'acc1@quarry.com',
    phone: '772111222',
    password: '1234',
    role: 'Accounting',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-005',
    name: 'مسؤول حسابات 2',
    email: 'acc2@quarry.com',
    phone: '772333444',
    password: '1234',
    role: 'Accounting',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-006',
    name: 'مسؤول الصندوق',
    email: 'cashier@quarry.com',
    phone: '773111222',
    password: '1234',
    role: 'Cashier',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-011',
    name: 'مطلق (مالك كسارة كدم)',
    email: 'motlaq@quarry.com',
    phone: '775111001',
    password: '1234',
    role: 'Owner',
    ownedCrusher: 'كسارة كدم',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-012',
    name: 'عبد الخالق (مالك كسارة الامجاد)',
    email: 'abdulkhaliq@quarry.com',
    phone: '775111002',
    password: '1234',
    role: 'Owner',
    ownedCrusher: 'كسارة الامجاد',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-013',
    name: 'عبد الخالق النارة (مالك كسارة الخير)',
    email: 'abdulkhaliq_alnarah@quarry.com',
    phone: '775111003',
    password: '1234',
    role: 'Owner',
    ownedCrusher: 'كسارة الخير',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-014',
    name: 'عارف النجار (مالك كسارة عزان)',
    email: 'arif@quarry.com',
    phone: '775111004',
    password: '1234',
    role: 'Owner',
    ownedCrusher: 'كسارة عزان',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-015',
    name: 'صالح (مالك كسارة النقع)',
    email: 'saleh_owner@quarry.com',
    phone: '775111005',
    password: '1234',
    role: 'Owner',
    ownedCrusher: 'كسارة النقع',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-016',
    name: 'مطارد (مالك كسارة الربيع)',
    email: 'motared@quarry.com',
    phone: '775111006',
    password: '1234',
    role: 'Owner',
    ownedCrusher: 'كسارة الربيع',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-017',
    name: 'يونس (مالك كسارة النهضة)',
    email: 'younis@quarry.com',
    phone: '775111007',
    password: '1234',
    role: 'Owner',
    ownedCrusher: 'كسارة النهضة',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-018',
    name: 'يونس سالم (مالك كسارة العالمية)',
    email: 'younis_salem@quarry.com',
    phone: '775111008',
    password: '1234',
    role: 'Owner',
    ownedCrusher: 'كسارة العالمية',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-019',
    name: 'أحمد (مالك كسارة صعدة)',
    email: 'ahmed_owner@quarry.com',
    phone: '775111009',
    password: '1234',
    role: 'Owner',
    ownedCrusher: 'كسارة صعدة',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-020',
    name: 'عمر (مالك كسارة الامتياز)',
    email: 'omar@quarry.com',
    phone: '775111010',
    password: '1234',
    role: 'Owner',
    ownedCrusher: 'كسارة الامتياز',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-021',
    name: 'علي (مالك كسارة التعاون)',
    email: 'ali_owner@quarry.com',
    phone: '775111011',
    password: '1234',
    role: 'Owner',
    ownedCrusher: 'كسارة التعاون',
    status: 'Active',
    terminalAccess: true
  },
  {
    id: 'USR-008',
    name: 'زبون',
    email: 'customer@quarry.com',
    phone: '733555222',
    password: '1234',
    role: 'Customer',
    status: 'Active',
    terminalAccess: false
  },
  {
    id: 'USR-009',
    name: 'عميل مصنع',
    email: 'factory@quarry.com',
    phone: '772332211',
    password: '1234',
    role: 'Customer',
    status: 'Active',
    terminalAccess: false
  },
  {
    id: 'USR-010',
    name: 'عميل شركة خرسانية',
    email: 'concrete@quarry.com',
    phone: '779999888',
    password: '1234',
    role: 'Customer',
    status: 'Active',
    terminalAccess: false
  }
];

export const INITIAL_SUPPLIERS: Supplier[] = [
  { id: 'SPL-001', name: 'كسارة الخير', balance: 145000 },
  { id: 'SPL-002', name: 'كسارة الربيع', balance: 89000 },
  { id: 'SPL-003', name: 'كسارة الامجاد', balance: 210000 },
  { id: 'SPL-004', name: 'كسارة كدم', balance: 175000 },
  { id: 'SPL-005', name: 'كسارة عزان', balance: 0 },
  { id: 'SPL-006', name: 'كسارة النقع', balance: 120000 },
  { id: 'SPL-007', name: 'كسارة العالمية', balance: 320000 },
  { id: 'SPL-008', name: 'كسارة النهضة', balance: 95000 },
  { id: 'SPL-009', name: 'كسارة الامتياز', balance: 150000 },
  { id: 'SPL-010', name: 'كسارة التعاون', balance: 0 },
  { id: 'SPL-011', name: 'كسارة صعدة', balance: 280000 }
];

export const INITIAL_PRICES: PriceItem[] = [
  // SPL-001 (الخير)
  { id: 'PRC-101', crusher: 'كسارة الخير', productId: 'thumn', productType: 'ثمن (حصى 1/8)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-102', crusher: 'كسارة الخير', productId: 'rub', productType: 'ربع (حصى 1/4)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-103', crusher: 'كسارة الخير', productId: 'nuss', productType: 'نصف (مخلوط 1/2)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },

  // SPL-002 (الربيع)
  { id: 'PRC-201', crusher: 'كسارة الربيع', productId: 'thumn', productType: 'ثمن (حصى 1/8)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-202', crusher: 'كسارة الربيع', productId: 'rub', productType: 'ربع (حصى 1/4)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-203', crusher: 'كسارة الربيع', productId: 'nuss', productType: 'نصف (مخلوط 1/2)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },

  // SPL-003 (الامجاد)
  { id: 'PRC-301', crusher: 'كسارة الامجاد', productId: 'thumn', productType: 'ثمن (حصى 1/8)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-302', crusher: 'كسارة الامجاد', productId: 'rub', productType: 'ربع (حصى 1/4)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-303', crusher: 'كسارة الامجاد', productId: 'nuss', productType: 'نصف (مخلوط 1/2)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },

  // SPL-004 (كدم)
  { id: 'PRC-401', crusher: 'كسارة كدم', productId: 'thumn', productType: 'ثمن (حصى 1/8)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-402', crusher: 'كسارة كدم', productId: 'rub', productType: 'ربع (حصى 1/4)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-403', crusher: 'كسارة كدم', productId: 'nuss', productType: 'نصف (مخلوط 1/2)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },

  // SPL-005 (عزان)
  { id: 'PRC-501', crusher: 'كسارة عزان', productId: 'thumn', productType: 'ثمن (حصى 1/8)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-502', crusher: 'كسارة عزان', productId: 'rub', productType: 'ربع (حصى 1/4)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-503', crusher: 'كسارة عزان', productId: 'nuss', productType: 'نصف (مخلوط 1/2)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },

  // SPL-006 (النقع)
  { id: 'PRC-601', crusher: 'كسارة النقع', productId: 'thumn', productType: 'ثمن (حصى 1/8)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-602', crusher: 'كسارة النقع', productId: 'rub', productType: 'ربع (حصى 1/4)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-603', crusher: 'كسارة النقع', productId: 'nuss', productType: 'نصف (مخلوط 1/2)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },

  // SPL-007 (العالمية)
  { id: 'PRC-701', crusher: 'كسارة العالمية', productId: 'thumn', productType: 'ثمن (حصى 1/8)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-702', crusher: 'كسارة العالمية', productId: 'rub', productType: 'ربع (حصى 1/4)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-703', crusher: 'كسارة العالمية', productId: 'nuss', productType: 'نصف (مخلوط 1/2)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },

  // SPL-008 (النهضة)
  { id: 'PRC-801', crusher: 'كسارة النهضة', productId: 'thumn', productType: 'ثمن (حصى 1/8)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-802', crusher: 'كسارة النهضة', productId: 'rub', productType: 'ربع (حصى 1/4)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-803', crusher: 'كسارة النهضة', productId: 'nuss', productType: 'نصف (مخلوط 1/2)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },

  // SPL-009 (الامتياز)
  { id: 'PRC-901', crusher: 'كسارة الامتياز', productId: 'thumn', productType: 'ثمن (حصى 1/8)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-902', crusher: 'كسارة الامتياز', productId: 'rub', productType: 'ربع (حصى 1/4)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-903', crusher: 'كسارة الامتياز', productId: 'nuss', productType: 'نصف (مخلوط 1/2)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },

  // SPL-010 (التعاون)
  { id: 'PRC-1001', crusher: 'كسارة التعاون', productId: 'thumn', productType: 'ثمن (حصى 1/8)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-1002', crusher: 'كسارة التعاون', productId: 'rub', productType: 'ربع (حصى 1/4)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-1003', crusher: 'كسارة التعاون', productId: 'nuss', productType: 'نصف (مخلوط 1/2)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },

  // SPL-011 (صعدة)
  { id: 'PRC-1101', crusher: 'كسارة صعدة', productId: 'thumn', productType: 'ثمن (حصى 1/8)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-1102', crusher: 'كسارة صعدة', productId: 'rub', productType: 'ربع (حصى 1/4)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' },
  { id: 'PRC-1103', crusher: 'كسارة صعدة', productId: 'nuss', productType: 'نصف (مخلوط 1/2)', pricePerUnit: 7000, supplierPrice: 5900, unit: 'م³' }
];

export const INITIAL_INVENTORY: InventoryItem[] = [
  // SPL-001 (الخير)
  { id: 'INV-101', crusher: 'كسارة الخير', productId: 'thumn', product: 'ثمن (حصى 1/8)', quantity: 2450, unit: 'م³', status: 'Normal' },
  { id: 'INV-102', crusher: 'كسارة الخير', productId: 'rub', product: 'ربع (حصى 1/4)', quantity: 80, unit: 'م³', status: 'Low' },
  { id: 'INV-103', crusher: 'كسارة الخير', productId: 'nuss', product: 'نصف (مخلوط 1/2)', quantity: 4800, unit: 'م³', status: 'High' },

  // SPL-002 (الربيع)
  { id: 'INV-201', crusher: 'كسارة الربيع', productId: 'thumn', product: 'ثمن (حصى 1/8)', quantity: 1800, unit: 'م³', status: 'Normal' },
  { id: 'INV-202', crusher: 'كسارة الربيع', productId: 'rub', product: 'ربع (حصى 1/4)', quantity: 2200, unit: 'م³', status: 'Normal' },
  { id: 'INV-203', crusher: 'كسارة الربيع', productId: 'nuss', product: 'نصف (مخلوط 1/2)', quantity: 120, unit: 'م³', status: 'Low' },

  // SPL-003 (الامجاد)
  { id: 'INV-301', crusher: 'كسارة الامجاد', productId: 'thumn', product: 'ثمن (حصى 1/8)', quantity: 550, unit: 'م³', status: 'Normal' },
  { id: 'INV-302', crusher: 'كسارة الامجاد', productId: 'rub', product: 'ربع (حصى 1/4)', quantity: 380, unit: 'م³', status: 'Normal' },
  { id: 'INV-303', crusher: 'كسارة الامجاد', productId: 'nuss', product: 'نصف (مخلوط 1/2)', quantity: 6000, unit: 'م³', status: 'High' },

  // SPL-004 (كدم)
  { id: 'INV-401', crusher: 'كسارة كدم', productId: 'thumn', product: 'ثمن (حصى 1/8)', quantity: 1200, unit: 'م³', status: 'Normal' },
  { id: 'INV-402', crusher: 'كسارة كدم', productId: 'rub', product: 'ربع (حصى 1/4)', quantity: 850, unit: 'م³', status: 'Normal' },
  { id: 'INV-403', crusher: 'كسارة كدم', productId: 'nuss', product: 'نصف (مخلوط 1/2)', quantity: 3100, unit: 'م³', status: 'High' },

  // SPL-005 (عزان)
  { id: 'INV-501', crusher: 'كسارة عزان', productId: 'thumn', product: 'ثمن (حصى 1/8)', quantity: 450, unit: 'م³', status: 'Normal' },
  { id: 'INV-502', crusher: 'كسارة عزان', productId: 'rub', product: 'ربع (حصى 1/4)', quantity: 230, unit: 'م³', status: 'Normal' },
  { id: 'INV-503', crusher: 'كسارة عزان', productId: 'nuss', product: 'نصف (مخلوط 1/2)', quantity: 90, unit: 'م³', status: 'Low' },

  // SPL-006 (النقع)
  { id: 'INV-601', crusher: 'كسارة النقع', productId: 'thumn', product: 'ثمن (حصى 1/8)', quantity: 1540, unit: 'م³', status: 'Normal' },
  { id: 'INV-602', crusher: 'كسارة النقع', productId: 'rub', product: 'ربع (حصى 1/4)', quantity: 110, unit: 'م³', status: 'Low' },
  { id: 'INV-603', crusher: 'كسارة النقع', productId: 'nuss', product: 'نصف (مخلوط 1/2)', quantity: 2100, unit: 'م³', status: 'Normal' },

  // SPL-007 (العالمية)
  { id: 'INV-701', crusher: 'كسارة العالمية', productId: 'thumn', product: 'ثمن (حصى 1/8)', quantity: 2900, unit: 'م³', status: 'Normal' },
  { id: 'INV-702', crusher: 'كسارة العالمية', productId: 'rub', product: 'ربع (حصى 1/4)', quantity: 4500, unit: 'م³', status: 'High' },
  { id: 'INV-703', crusher: 'كسارة العالمية', productId: 'nuss', product: 'نصف (مخلوط 1/2)', quantity: 1900, unit: 'م³', status: 'Normal' },

  // SPL-008 (النهضة)
  { id: 'INV-801', crusher: 'كسارة النهضة', productId: 'thumn', product: 'ثمن (حصى 1/8)', quantity: 740, unit: 'م³', status: 'Normal' },
  { id: 'INV-802', crusher: 'كسارة النهضة', productId: 'rub', product: 'ربع (حصى 1/4)', quantity: 1500, unit: 'م³', status: 'Normal' },
  { id: 'INV-803', crusher: 'كسارة النهضة', productId: 'nuss', product: 'نصف (مخلوط 1/2)', quantity: 380, unit: 'م³', status: 'Normal' },

  // SPL-009 (الامتياز)
  { id: 'INV-901', crusher: 'كسارة الامتياز', productId: 'thumn', product: 'ثمن (حصى 1/8)', quantity: 1200, unit: 'م³', status: 'Normal' },
  { id: 'INV-902', crusher: 'كسارة الامتياز', productId: 'rub', product: 'ربع (حصى 1/4)', quantity: 1100, unit: 'م³', status: 'Normal' },
  { id: 'INV-903', crusher: 'كسارة الامتياز', productId: 'nuss', product: 'نصف (مخلوط 1/2)', quantity: 1150, unit: 'م³', status: 'Normal' },

  // SPL-010 (التعاون)
  { id: 'INV-1001', crusher: 'كسارة التعاون', productId: 'thumn', product: 'ثمن (حصى 1/8)', quantity: 340, unit: 'م³', status: 'Normal' },
  { id: 'INV-1002', crusher: 'كسارة التعاون', productId: 'rub', product: 'ربع (حصى 1/4)', quantity: 450, unit: 'م³', status: 'Normal' },
  { id: 'INV-1003', crusher: 'كسارة التعاون', productId: 'nuss', product: 'نصف (مخلوط 1/2)', quantity: 720, unit: 'م³', status: 'Normal' },

  // SPL-011 (صعدة)
  { id: 'INV-1101', crusher: 'كسارة صعدة', productId: 'thumn', product: 'ثمن (حصى 1/8)', quantity: 2800, unit: 'م³', status: 'Normal' },
  { id: 'INV-1102', crusher: 'كسارة صعدة', productId: 'rub', product: 'ربع (حصى 1/4)', quantity: 3200, unit: 'م³', status: 'High' },
  { id: 'INV-1103', crusher: 'كسارة صعدة', productId: 'nuss', product: 'نصف (مخلوط 1/2)', quantity: 180, unit: 'م³', status: 'Low' }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ORD-1',
    customerId: 'USR-008',
    customerName: 'زبون',
    supplierId: 'SPL-001',
    supplierName: 'كسارة الخير',
    productId: 'thumn',
    product: 'ثمن (حصى 1/8)',
    quantity: 40,
    unit: 'م³',
    unitPrice: 7000,
    totalPrice: 280000,
    commission: 44000, // (7000 - 5900) * 40
    supplierAmount: 236000, // 5900 * 40
    status: 'Delivered',
    paymentMethod: 'Bank Transfer',
    transferNumber: 'TRX-8839210-Y',
    channel: 'App',
    date: '2026-06-14T10:15:00Z'
  },
  {
    id: 'ORD-2',
    customerId: 'USR-009',
    customerName: 'عميل مصنع',
    supplierId: 'SPL-002',
    supplierName: 'كسارة الربيع',
    productId: 'rub',
    product: 'ربع (حصى 1/4)',
    quantity: 35,
    unit: 'م³',
    unitPrice: 7000,
    totalPrice: 245000,
    commission: 38500, // (7000 - 5900) * 35
    supplierAmount: 206500, // 5900 * 35
    status: 'Pending',
    paymentMethod: 'Cash',
    channel: 'WhatsApp',
    date: '2026-06-15T08:30:00Z'
  },
  {
    id: 'ORD-3',
    customerId: 'USR-008',
    customerName: 'زبون',
    supplierId: 'SPL-003',
    supplierName: 'كسارة الامجاد',
    productId: 'nuss',
    product: 'نصف (مخلوط 1/2)',
    quantity: 50,
    unit: 'م³',
    unitPrice: 7000,
    totalPrice: 350000,
    commission: 55000, // (7000 - 5900) * 50
    supplierAmount: 295000, // 5900 * 50
    status: 'Pending',
    paymentMethod: 'Bank Transfer',
    transferNumber: 'TRX-900215-S',
    channel: 'SMS',
    date: '2026-06-15T12:00:00Z'
  },
  {
    id: 'ORD-4',
    customerId: 'USR-009',
    customerName: 'عميل مصنع',
    supplierId: 'SPL-001',
    supplierName: 'كسارة الخير',
    productId: 'nuss',
    product: 'نصف (مخلوط 1/2)',
    quantity: 60,
    unit: 'م³',
    unitPrice: 7000,
    totalPrice: 420000,
    commission: 66000, // (7000 - 5900) * 60
    supplierAmount: 354000, // 5900 * 60
    status: 'Delivered',
    paymentMethod: 'Cash',
    channel: 'WhatsApp',
    date: '2026-06-12T16:45:00Z'
  }
];

export const INITIAL_SUPPLIER_TRANSACTIONS: SupplierTransaction[] = [
  {
    id: 'TXN-1',
    supplierId: 'SPL-001',
    orderId: 'ORD-1',
    type: 'Sale',
    amount: 236000,
    quantity: 40,
    product: 'ثمن (حصى 1/8)',
    date: '2026-06-14T10:15:00Z',
    description: 'مبيعات الكري - فاتورة شحنة ORD-1 المستلمة من كسارة الخير'
  },
  {
    id: 'TXN-2',
    supplierId: 'SPL-001',
    type: 'Payment',
    amount: -200000,
    date: '2026-06-13T09:00:00Z',
    description: 'سند صرف نقدي مسدد من الإدارة لكسارة الخير - دفعة حساب'
  },
  {
    id: 'TXN-3',
    supplierId: 'SPL-002',
    type: 'Production',
    amount: 885000,
    quantity: 150,
    product: 'ربع (حصى 1/4)',
    date: '2026-06-14T14:00:00Z',
    description: 'سند رصد إنتاج لكسارة الربيع وقيد إضافي للمخاطبة المخزنية'
  },
  {
    id: 'TXN-4',
    supplierId: 'SPL-001',
    orderId: 'ORD-4',
    type: 'Sale',
    amount: 354000,
    quantity: 60,
    product: 'نصف (مخلوط 1/2)',
    date: '2026-06-12T16:45:00Z',
    description: 'مبيعات الكري - فاتورة شحنة ORD-4 المستلمة من كسارة الخير'
  }
];
