import React, { useState, useEffect } from 'react';
import { User, Supplier, InventoryItem, PriceItem, Order, SupplierTransaction } from './types';
import { 
  INITIAL_USERS, 
  INITIAL_SUPPLIERS, 
  INITIAL_INVENTORY, 
  INITIAL_PRICES, 
  INITIAL_ORDERS, 
  INITIAL_SUPPLIER_TRANSACTIONS 
} from './seedData';

import StatsOverview from './components/StatsOverview';
import OrdersManager from './components/OrdersManager';
import SuppliersManager from './components/SuppliersManager';
import InventoryManager from './components/InventoryManager';
import UsersManager from './components/UsersManager';
import AccountingManager from './components/AccountingManager';
import TerminalConsole from './components/TerminalConsole';
import LoginScreen from './components/LoginScreen';
import CustomerOrderPortal from './components/CustomerOrderPortal';
import OwnerDashboard from './components/OwnerDashboard';

import { 
  LayoutDashboard, ShoppingCart, Landmark, Boxes, 
  Users, RefreshCw, UserCheck, Smartphone, CheckSquare, 
  AlertCircle, ShieldAlert, CheckCircle2, ChevronLeft, Award, HelpCircle,
  Scale, Terminal, MoreVertical, Settings, User as UserIcon, Database, Download, Upload, Shield,
  Home, LogOut, Printer, TrendingUp, Coins, Wallet, Clock, ShieldCheck
} from 'lucide-react';

export default function App() {
  // 1. Core States with automated LocalStorage retrieval
  const [users, setUsers] = useState<User[]>(() => {
    const data = localStorage.getItem('quarry_v5_users');
    return data ? JSON.parse(data) : INITIAL_USERS;
  });

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    const data = localStorage.getItem('quarry_v5_suppliers');
    return data ? JSON.parse(data) : INITIAL_SUPPLIERS;
  });

  const [inventory, setInventory] = useState<InventoryItem[]>(() => {
    const data = localStorage.getItem('quarry_v5_inventory');
    return data ? JSON.parse(data) : INITIAL_INVENTORY;
  });

  const [prices] = useState<PriceItem[]>(INITIAL_PRICES); // static pricing configuration base

  const [orders, setOrders] = useState<Order[]>(() => {
    const data = localStorage.getItem('quarry_v5_orders');
    return data ? JSON.parse(data) : INITIAL_ORDERS;
  });

  const [transactions, setTransactions] = useState<SupplierTransaction[]>(() => {
    const data = localStorage.getItem('quarry_v5_transactions');
    return data ? JSON.parse(data) : INITIAL_SUPPLIER_TRANSACTIONS;
  });

  // Current system simulation persona state
  const [selectedUserId, setSelectedUserId] = useState<string>(() => {
    return localStorage.getItem('quarry_v5_selected_user_id') || 'USR-001';
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('quarry_v5_authenticated') === 'true';
  });
  const [activeTab, setActiveTab ] = useState<'home' | 'orders' | 'suppliers' | 'inventory' | 'users' | 'accounts' | 'terminal'>('home');

  // States for resetting data options dialog
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [resetOptions, setResetOptions] = useState({
    resetOrders: false,
    resetTransactions: false,
    resetSuppliers: false,
    resetInventory: false,
    resetUsers: false,
    factoryReset: false,
  });

  // Android Mobile PWA Installation banner state
  const [showAndroidInstallBanner, setShowAndroidInstallBanner] = useState(() => {
    return localStorage.getItem('quarry_hide_android_banner') !== 'true';
  });

  const dismissAndroidBanner = () => {
    localStorage.setItem('quarry_hide_android_banner', 'true');
    setShowAndroidInstallBanner(false);
  };

  // States for options dropdown and associated modals
  const [isOptionsMenuOpen, setIsOptionsMenuOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [isStatsModalOpen, setIsStatsModalOpen] = useState(false);

  // System settings customization states
  const [systemTitle, setSystemTitle] = useState(() => {
    return localStorage.getItem('quarry_sys_title') || 'نظام إدارة مبيعات الكسارات';
  });
  const [systemSlogan, setSystemSlogan] = useState(() => {
    return localStorage.getItem('quarry_sys_slogan') || 'إدارة مبيعات الكري، تعبئة السيلوهات المقررة بالمتر المكعب، وقيود حسابات الكسارات الثنائية الدفترية.';
  });
  const [autoDeductInventory, setAutoDeductInventory] = useState(() => {
    return localStorage.getItem('quarry_auto_deduct') !== 'false';
  });

  // Backup data upload handling
  const [backupJsonInput, setBackupJsonInput] = useState('');
  const [backupError, setBackupError] = useState<string | null>(null);
  const [backupSuccess, setBackupSuccess] = useState<string | null>(null);

  // Live dynamic local date & time state
  const [currentDateTime, setCurrentDateTime] = useState<string>(() => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    };
    try {
      return new Intl.DateTimeFormat('ar-YE', options).format(new Date());
    } catch (e) {
      return new Date().toLocaleString('ar-YE');
    }
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const options: Intl.DateTimeFormatOptions = {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
      };
      try {
        setCurrentDateTime(new Intl.DateTimeFormat('ar-YE', options).format(new Date()));
      } catch (e) {
        setCurrentDateTime(new Date().toLocaleString('ar-YE'));
      }
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Persistent saving of customized parameters
  useEffect(() => {
    localStorage.setItem('quarry_v5_selected_user_id', selectedUserId);
  }, [selectedUserId]);

  useEffect(() => {
    localStorage.setItem('quarry_v5_authenticated', isAuthenticated ? 'true' : 'false');
  }, [isAuthenticated]);

  useEffect(() => {
    localStorage.setItem('quarry_sys_title', systemTitle);
  }, [systemTitle]);

  useEffect(() => {
    localStorage.setItem('quarry_sys_slogan', systemSlogan);
  }, [systemSlogan]);

  useEffect(() => {
    localStorage.setItem('quarry_auto_deduct', autoDeductInventory ? 'true' : 'false');
  }, [autoDeductInventory]);

  // Sync to LocalStorage whenever state modifies
  useEffect(() => {
    localStorage.setItem('quarry_v5_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('quarry_v5_suppliers', JSON.stringify(suppliers));
  }, [suppliers]);

  useEffect(() => {
    localStorage.setItem('quarry_v5_inventory', JSON.stringify(inventory));
  }, [inventory]);

  useEffect(() => {
    localStorage.setItem('quarry_v5_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('quarry_v5_transactions', JSON.stringify(transactions));
  }, [transactions]);

  // Current active user's details and roles
  const activeUser = users.find(u => u.id === selectedUserId) || users[0];
  const currentRole = activeUser.role;

  // 2. Action Handlers (All containing double-entry relational accounting as planned in Section 4)
  
  // Submit new Order
  const handleAddOrder = (newOrder: Order) => {
    // A. Re-balance inventory stock
    setInventory(prevInv => {
      return prevInv.map(item => {
        if (item.crusher === newOrder.supplierName && item.productId === newOrder.productId) {
          const newQty = Math.max(0, item.quantity - newOrder.quantity);
          let nStatus: 'Low' | 'Normal' | 'High' = 'Normal';
          if (newQty < 200) nStatus = 'Low';
          else if (newQty > 3000) nStatus = 'High';
          
          return {
            ...item,
            quantity: newQty,
            status: nStatus
          };
        }
        return item;
      });
    });

    // B. Re-balance Supplier liability (Outstanding unpaid balance increases by supplier's net share)
    setSuppliers(prevSupps => {
      return prevSupps.map(s => {
        if (s.id === newOrder.supplierId) {
          return {
            ...s,
            balance: s.balance + newOrder.supplierAmount
          };
        }
        return s;
      });
    });

    // C. Write transaction ledger
    setTransactions(prevTxns => {
      const numericIds = prevTxns.map(t => {
        const match = t.id.match(/\d+/);
        return match ? parseInt(match[0], 10) : 0;
      });
      const maxId = Math.max(0, ...numericIds);
      const nextTxnId = `TXN-${maxId + 1}`;

      const newTxn: SupplierTransaction = {
        id: nextTxnId,
        supplierId: newOrder.supplierId,
        orderId: newOrder.id,
        type: 'Sale',
        amount: newOrder.supplierAmount,
        quantity: newOrder.quantity,
        product: newOrder.product,
        date: new Date().toISOString(),
        description: `مبيعات الكري - فاتورة مبيعات وتوزيع مستحقات رقم: ${newOrder.id}`
      };
      return [newTxn, ...prevTxns];
    });

    // D. Push order
    setOrders(prevOrders => [newOrder, ...prevOrders]);
  };

  // Modify Order status (Pending -> Delivered -> Cancelled)
  const handleUpdateOrderStatus = (orderId: string, newStatus: 'Pending' | 'Delivered' | 'Cancelled') => {
    setOrders(prevOrders => {
      const match = prevOrders.find(o => o.id === orderId);
      if (!match) return prevOrders;

      // Handle cancellation actions (restore stock and cancel accounting liabilities)
      if (newStatus === 'Cancelled' && match.status !== 'Cancelled') {
        // Restore stock
        setInventory(prevInv => {
          return prevInv.map(item => {
            if (item.crusher === match.supplierName && item.productId === match.productId) {
              const newQty = item.quantity + match.quantity;
              let nStatus: 'Low' | 'Normal' | 'High' = 'Normal';
              if (newQty < 200) nStatus = 'Low';
              else if (newQty > 3000) nStatus = 'High';

              return { ...item, quantity: newQty, status: nStatus };
            }
            return item;
          });
        });

        // Deduct/Subtract from supplier's owed balance
        setSuppliers(prevSupps => {
          return prevSupps.map(s => {
            if (s.id === match.supplierId) {
              return { ...s, balance: Math.max(0, s.balance - match.supplierAmount) };
            }
            return s;
          });
        });

        // Write a reversing entry in transactions ledger
        setTransactions(prev => {
          const numericIds = prev.map(t => {
            const match = t.id.match(/\d+/);
            return match ? parseInt(match[0], 10) : 0;
          });
          const maxId = Math.max(0, ...numericIds);
          const nextTxnId = `TXN-${maxId + 1}`;

          const cancelTxn: SupplierTransaction = {
            id: nextTxnId,
            supplierId: match.supplierId,
            orderId: match.id,
            type: 'Payment', // debiting
            amount: match.supplierAmount, // Statement logic will subtract this from balance
            date: new Date().toISOString(),
            description: `إلغاء الطلب ${match.id} - تسوية وعكس قيد مستحقات`
          };
          return [cancelTxn, ...prev];
        });
      }

      return prevOrders.map(o => o.id === orderId ? { ...o, status: newStatus } : o);
    });
  };

  // Pay supplier cash directly
  const handleAddTransaction = (newTxn: SupplierTransaction) => {
    if (newTxn.type === 'Payment') {
      setSuppliers(prevSupps => {
        return prevSupps.map(s => {
          if (s.id === newTxn.supplierId) {
            return {
              ...s,
              balance: Math.max(0, s.balance - newTxn.amount)
            };
          }
          return s;
        });
      });
    }
    setTransactions(prev => [newTxn, ...prev]);
  };

  // Register production directly (increases stock level)
  const handleRegisterProduction = (supplierId: string, productId: string, qtyToAdd: number) => {
    const supplierObj = suppliers.find(s => s.id === supplierId);
    if (!supplierObj) return;

    setInventory(prevInv => {
      return prevInv.map(item => {
        if (item.crusher === supplierObj.name && item.productId === productId) {
          const newQty = item.quantity + qtyToAdd;
          let nStatus: 'Low' | 'Normal' | 'High' = 'Normal';
          if (newQty < 200) nStatus = 'Low';
          else if (newQty > 3000) nStatus = 'High';

          return {
            ...item,
            quantity: newQty,
            status: nStatus
          };
        }
        return item;
      });
    });
  };

  // Admin directly corrects inventory quantity
  const handleUpdateInventoryQty = (itemId: string, newQty: number) => {
    setInventory(prevInv => {
      return prevInv.map(item => {
        if (item.id === itemId) {
          let nStatus: 'Low' | 'Normal' | 'High' = 'Normal';
          if (newQty < 200) nStatus = 'Low';
          else if (newQty > 3000) nStatus = 'High';

          return {
            ...item,
            quantity: newQty,
            status: nStatus
          };
        }
        return item;
      });
    });
  };

  // Toggle user state active/suspend
  const handleToggleUserStatus = (userId: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        return {
          ...u,
          status: u.status === 'Active' ? 'Suspended' : 'Active'
        };
      }
      return u;
    }));
  };

  // Toggle employee's entry level
  const handleToggleTerminalAccess = (userId: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        return {
          ...u,
          terminalAccess: !u.terminalAccess
        };
      }
      return u;
    }));
  };

  // Add new employee / customer user card
  const handleAddUser = (newUser: User) => {
    setUsers(prev => [...prev, newUser]);
  };

  const handleExportBackup = () => {
    try {
      const backupData = {
        version: 'v5.4',
        exportDate: new Date().toISOString(),
        users,
        suppliers,
        inventory,
        orders,
        transactions
      };
      const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `quarry_backup_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      setBackupSuccess('✅ تم تصدير وتحميل ملف النسخة الاحتياطية الفورية لجهازك بنجاح!');
      setBackupError(null);
    } catch (e) {
      setBackupError('تعذر تصدير النسخة الاحتياطية المخصصة.');
    }
  };

  const handleImportBackup = (jsonStr: string) => {
    try {
      if (!jsonStr || !jsonStr.trim()) {
        setBackupError('محتوى البيانات فارغ! يرجى لصق كود النسخة النصي أولاً.');
        return;
      }
      const parsed = JSON.parse(jsonStr);
      if (parsed && (parsed.orders || parsed.suppliers || parsed.users || parsed.inventory || parsed.transactions)) {
        if (parsed.users && Array.isArray(parsed.users)) {
          setUsers(parsed.users);
          localStorage.setItem('quarry_v5_users', JSON.stringify(parsed.users));
        }
        if (parsed.suppliers && Array.isArray(parsed.suppliers)) {
          setSuppliers(parsed.suppliers);
          localStorage.setItem('quarry_v5_suppliers', JSON.stringify(parsed.suppliers));
        }
        if (parsed.inventory && Array.isArray(parsed.inventory)) {
          setInventory(parsed.inventory);
          localStorage.setItem('quarry_v5_inventory', JSON.stringify(parsed.inventory));
        }
        if (parsed.orders && Array.isArray(parsed.orders)) {
          setOrders(parsed.orders);
          localStorage.setItem('quarry_v5_orders', JSON.stringify(parsed.orders));
        }
        if (parsed.transactions && Array.isArray(parsed.transactions)) {
          setTransactions(parsed.transactions);
          localStorage.setItem('quarry_v5_transactions', JSON.stringify(parsed.transactions));
        }
        
        setBackupSuccess('✅ تم استيراد واستعادة ودمج البيانات من النسخة الاحتياطية بنجاح!');
        setBackupError(null);
      } else {
        setBackupError('ملف النسخة الاحتياطية غير متوافق أو لا يحتوي على كائنات صحيحة للقالب المالي للكسارات.');
      }
    } catch (e) {
      setBackupError('البيانات المدخلة ليست بصيغة JSON صالحة. يرجى التأكد من نسخ الملف كاملاً ودون تمزق الحروف.');
    }
  };

  // Re-seed all values to initial defaults for clean test or open dialog
  const handleResetData = () => {
    setResetOptions({
      resetOrders: false,
      resetTransactions: false,
      resetSuppliers: false,
      resetInventory: false,
      resetUsers: false,
      factoryReset: false,
    });
    setIsResetModalOpen(true);
  };

  const executeReset = () => {
    const { resetOrders, resetTransactions, resetSuppliers, resetInventory, resetUsers, factoryReset } = resetOptions;
    
    if (!resetOrders && !resetTransactions && !resetSuppliers && !resetInventory && !resetUsers && !factoryReset) {
      alert('الرجاء اختيار خيار واحد على الأقل لتنفيذ عملية التصفير والضبط!');
      return;
    }

    if (factoryReset) {
      // Full reset to default demo data
      localStorage.removeItem('quarry_v5_users');
      localStorage.removeItem('quarry_v5_suppliers');
      localStorage.removeItem('quarry_v5_inventory');
      localStorage.removeItem('quarry_v5_orders');
      localStorage.removeItem('quarry_v5_transactions');

      setUsers(INITIAL_USERS);
      setSuppliers(INITIAL_SUPPLIERS);
      setInventory(INITIAL_INVENTORY);
      setOrders(INITIAL_ORDERS);
      setTransactions(INITIAL_SUPPLIER_TRANSACTIONS);
      setSelectedUserId('USR-001');
      setActiveTab('orders');
    } else {
      // Individual granular zeroing
      if (resetOrders) {
        setOrders([]);
        localStorage.setItem('quarry_v5_orders', JSON.stringify([]));
      }
      
      if (resetTransactions) {
        setTransactions([]);
        localStorage.setItem('quarry_v5_transactions', JSON.stringify([]));
      }

      if (resetSuppliers) {
        const zeroedSuppliers = suppliers.map(s => ({ ...s, balance: 0 }));
        setSuppliers(zeroedSuppliers);
        localStorage.setItem('quarry_v5_suppliers', JSON.stringify(zeroedSuppliers));
      }

      if (resetInventory) {
        const zeroedInv = inventory.map(item => ({ ...item, quantity: 0, status: 'Low' as const }));
        setInventory(zeroedInv);
        localStorage.setItem('quarry_v5_inventory', JSON.stringify(zeroedInv));
      }

      if (resetUsers) {
        setUsers(INITIAL_USERS);
        localStorage.setItem('quarry_v5_users', JSON.stringify(INITIAL_USERS));
        setSelectedUserId('USR-001');
      }
    }

    setIsResetModalOpen(false);
  };

  // Helper descriptor for role capability notices
  const getRoleNotice = () => {
    switch (currentRole) {
      case 'Admin':
        return 'أنت تتصفح بصفتك المدير العام المالي والتشغيلي للنظام. تملك تحكماً مطلقاً في إصدار سندات المبيعات، صرف دفعات الكسارات، تعديل مستويات السيلو، وتعديل صلاحيات الموظفين والسائقين.';
      case 'Sales Representative':
        return 'أنت تتصفح بصفتك مندوب المبيعات. تملك صلاحية إصدار طلبيات الكري، تتبع ترحيل بوليصات الشحن، ومطابقة تسليم الأوزان. صلاحيات الدفع المالي وتصاريح الموظفين محجوبة.';
      case 'Customer':
        return 'أنت تتصفح بصفتك العميل. تملك واجهة حصرية لمراجعة شحناتك الحالية وطرق الدفع الكودية المسجلة، ولا يتاح لك استعراض كشوف حساب الكسارات أو الكوادر الأخرى.';
      case 'Marketing':
        return 'بصفتك المسؤول التسويقي، تملك حق معاينة كفاءة السيلوهات وأرقام المبيعات وصيغ الفواتير بدون إمكانية التغيير الهيكلي للحسابات المالية.';
      case 'Accounting':
        return 'أنت تتصفح بصفتك مسؤول الحسابات. تملك حق الوصول والتحكم الكامل في الدفاتر اليومية وسندات الصرف والقبض والتسويات والمطابقات المالية للشركاء والكسارات.';
      case 'Cashier':
        return 'أنت تتصفح بصفتك مسؤول الصندوق. تملك صلاحية استلام مبالغ الطلبيات النقدية وصرف الدفعات وتسجيل حركة النقدية اليومية للصندوق والعهد.';
      case 'Owner':
        return 'أنت تتصفح بصفتك مالك كسارة. تملك صلاحيات استعراض كشوفات الإنتاج والحسابات والمستحقات والطلبات المرتبطة بكساراتك دون تعديل إداري مطلق.';
      default:
        return '';
    }
  };

  if (!isAuthenticated) {
    return (
      <LoginScreen
        users={users}
        onLogin={(userId) => {
          setSelectedUserId(userId);
          setIsAuthenticated(true);
        }}
        onUpdatePassword={(userId, newPass) => {
          setUsers(prevUsers => {
            const updated = prevUsers.map(u => u.id === userId ? { ...u, password: newPass } : u);
            localStorage.setItem('quarry_v5_users', JSON.stringify(updated));
            return updated;
          });
          alert('✅ تم تحديث وحفظ كلمة المرور الجديدة تلقائياً بنجاح!');
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans" dir="rtl" id="app-root">
      
      {/* 1. Header Banner */}
      <header className="bg-slate-900 text-white shadow-md relative overflow-hidden" id="main-header">
        {/* Subtle decorative background graphic */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-slate-800 via-slate-900 to-slate-950 opacity-90"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 relative z-10">
          
          {/* Top Utility Bar with 3-Dots Options Menu & Quick Stats Trigger */}
          <div className="flex justify-between items-center border-b border-white/5 pb-3.5 mb-4 gap-4" id="utility-options-bar">
            {/* Right: Active Live Status Tracker */}
            <div className="flex items-center gap-1.5 bg-slate-950/40 text-emerald-400 px-3 py-1 rounded-xl border border-emerald-500/10">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-[10px] font-black font-sans uppercase tracking-wider">قاعدة بيانات الكسارات المحلية متزامنة وآمنة</span>
            </div>

            {/* Left: Actions Area (Stats & 3-Dots Dropdown) */}
            <div className="flex items-center gap-2">
              {currentRole !== 'Customer' && (
                <button
                  onClick={() => setIsStatsModalOpen(true)}
                  className="bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-xl px-3 py-2 text-xs font-black flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow-sm"
                  id="top-stats-trigger-btn"
                  title="فتح لوحة الإحصاءات والتحليل الميكروي"
                >
                  <LayoutDashboard className="w-4 h-4 text-amber-400 animate-pulse" />
                  <span className="hidden md:inline font-sans font-bold">لوحة التحليل الميكروي</span>
                </button>
              )}

              <div className="relative">
                <button
                  onClick={() => setIsOptionsMenuOpen(!isOptionsMenuOpen)}
                  className="bg-slate-800 hover:bg-slate-750 text-white rounded-xl p-2.5 border border-slate-700/50 hover:border-slate-600 transition-all duration-150 flex items-center justify-center cursor-pointer select-none shadow-sm focus:outline-none focus:ring-1 focus:ring-amber-500 active:scale-95"
                  id="options-menu-trigger"
                  title="خيارات وإعدادات النظام الإضافية"
                >
                  <MoreVertical className="w-5 h-5 text-slate-300 hover:text-white" />
                </button>

              {/* Dropdown Menu popover */}
              {isOptionsMenuOpen && (
                <div 
                  className="absolute left-0 mt-2 bg-slate-950 border border-slate-850 rounded-2xl p-2 w-64 shadow-2xl z-50 text-right animate-slide-down font-sans text-xs divide-y divide-slate-850"
                  onMouseLeave={() => setIsOptionsMenuOpen(false)}
                  id="options-dropdown-panel"
                >
                  <div className="py-1 space-y-0.5">
                    {currentRole !== 'Customer' && (
                      <button
                        onClick={() => {
                          setIsStatsModalOpen(true);
                          setIsOptionsMenuOpen(false);
                        }}
                        className={`w-full p-2.5 rounded-xl flex items-center gap-2.5 transition cursor-pointer text-right ${
                          isStatsModalOpen
                            ? 'text-amber-400 bg-white/5 font-black border border-white/5'
                            : 'text-slate-200 hover:text-white hover:bg-slate-900'
                        }`}
                      >
                        <LayoutDashboard className="w-4 h-4 text-amber-500 shrink-0 animate-pulse" />
                        <span className="font-bold">📊 لوحة الإحصاءات الميكروية</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        setIsSettingsModalOpen(true);
                        setIsOptionsMenuOpen(false);
                      }}
                      className="w-full text-slate-200 hover:text-white hover:bg-slate-900 p-2.5 rounded-xl flex items-center gap-2.5 transition cursor-pointer text-right"
                    >
                      <Settings className="w-4 h-4 text-amber-500 shrink-0" />
                      <span className="font-bold">⚙️ إعدادات وتخصيص النظام</span>
                    </button>
                    
                    <button
                      onClick={() => {
                        setIsProfileModalOpen(true);
                        setIsOptionsMenuOpen(false);
                      }}
                      className="w-full text-slate-200 hover:text-white hover:bg-slate-900 p-2.5 rounded-xl flex items-center gap-2.5 transition cursor-pointer text-right"
                    >
                      <UserIcon className="w-4 h-4 text-sky-400 shrink-0" />
                      <span className="font-bold">👤 ملف المستخدم والتحقق</span>
                    </button>

                    <button
                      onClick={() => {
                        setIsBackupModalOpen(true);
                        setIsOptionsMenuOpen(false);
                      }}
                      className="w-full text-slate-200 hover:text-white hover:bg-slate-900 p-2.5 rounded-xl flex items-center gap-2.5 transition cursor-pointer text-right"
                    >
                      <Database className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span className="font-bold">💾 النسخ الاحتياطية للبيانات</span>
                    </button>
                  </div>

                  <div className="py-1">
                    {currentRole !== 'Customer' && (
                      <button
                        onClick={() => {
                          setActiveTab('terminal');
                          setIsOptionsMenuOpen(false);
                        }}
                        className="w-full text-emerald-400 hover:text-emerald-350 hover:bg-slate-900 p-2.5 rounded-xl flex items-center gap-2.5 transition font-black cursor-pointer text-right mb-1"
                      >
                        <Terminal className="w-4 h-4 animate-pulse text-emerald-400 shrink-0" />
                        <span>🖥️ الانتقال إلى الوحدة الطرفية</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        setIsAuthenticated(false);
                        setIsOptionsMenuOpen(false);
                      }}
                      className="w-full text-rose-400 hover:text-rose-350 hover:bg-slate-900 p-2.5 rounded-xl flex items-center gap-2.5 transition font-black cursor-pointer text-right"
                    >
                      <LogOut className="w-4 h-4 text-rose-500 shrink-0" />
                      <span>🚪 تسجيل الخروج الآمن</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            
            {/* Project Title */}
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-amber-500 text-slate-900 text-[10px] px-2.5 py-1 rounded-md font-black tracking-widest uppercase">
                  نظام إدارة مبيعات الكسارات
                </span>
                <span className="text-[11px] text-slate-400 font-mono">الجيل الخامس v5.4</span>
              </div>
              <h1 className="text-2xl font-black text-white mt-1.5 tracking-tight">
                {systemTitle}
              </h1>
              <p className="text-slate-400 text-xs mt-1 font-semibold leading-relaxed">
                {systemSlogan}
              </p>
            </div>

            {/* Simulated Live User Role Switcher & Notice Panel */}
            {currentRole === 'Admin' ? (
              <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800 backdrop-blur-md self-start lg:self-center max-w-md w-full relative group" id="role-switcher">
                <div className="flex items-center justify-between gap-2 border-b border-white/5 pb-2 mb-2">
                  <label className="block text-[10px] font-bold text-amber-400">
                    💼 محاكاة واجهات المستخدمين (تغيير دور التصفح والتحقق):
                  </label>
                  <div className="bg-amber-500/15 border border-amber-500/30 text-amber-300 p-0.5 px-2 rounded-md text-[9px] font-black font-sans shrink-0">
                    <span>{currentRole}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <select 
                    value={selectedUserId} 
                    onChange={(e) => {
                      setSelectedUserId(e.target.value);
                      const sel = users.find(u => u.id === e.target.value);
                      if (sel) {
                        // auto switch tabs to home under restrictive contexts
                        setActiveTab('home');
                      }
                    }}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs font-bold focus:outline-none focus:border-amber-500"
                    id="select-active-role"
                  >
                    {users.map(u => (
                      <option key={u.id} value={u.id}>
                        {u.name} ({
                          u.role === 'Admin' ? 'مسؤول النظام' : 
                          u.role === 'Customer' ? 'عميل / زبون' : 
                          u.role === 'Sales Representative' ? 'مندوب مبيعات' : 
                          u.role === 'Accounting' ? 'مسؤول حسابات' : 
                          u.role === 'Cashier' ? 'مسؤول الصندوق' : 
                          u.role === 'Owner' ? 'مالك كسارة' : 'تسويق'
                        })
                      </option>
                    ))}
                  </select>
                </div>
                <div className="text-[10px] text-slate-300/90 leading-relaxed font-sans bg-white/5 p-2 rounded-lg border border-white/5">
                  <span className="font-bold text-[9px] text-amber-400 block mb-0.5">ℹ️ تصاريح المحاكاة النشطة:</span>
                  {getRoleNotice()}
                </div>
              </div>
            ) : (
              <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800 backdrop-blur-md self-start lg:self-center max-w-md w-full flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/20">
                    <UserIcon className="w-5 h-5 text-indigo-400" />
                  </div>
                  <div className="text-right">
                    <span className="block text-[10px] text-slate-400 font-bold">المستخدم الحالي:</span>
                    <span className="text-sm font-black text-white">{activeUser.name}</span>
                    <span className="block text-[9px] text-indigo-400 font-bold mt-1">دورك: {
                      currentRole === 'Customer' ? 'عميل / زبون' : 
                      currentRole === 'Sales Representative' ? 'مندوب مبيعات' : 
                      currentRole === 'Accounting' ? 'مسؤول حسابات' : 
                      currentRole === 'Cashier' ? 'مسؤول الصندوق' : 
                      currentRole === 'Owner' ? 'مالك كسارة' : 'تسويق'
                    }</span>
                  </div>
                </div>
                <button
                  onClick={() => setIsAuthenticated(false)}
                  className="bg-rose-500/10 hover:bg-rose-500/25 text-rose-400 border border-rose-500/20 rounded-xl px-3 py-2 text-xs font-bold transition active:scale-95 cursor-pointer shadow-sm shrink-0"
                >
                  تسجيل خروج ×
                </button>
              </div>
            )}

          </div>

          {/* Current Local Time representing current deployment period */}
          <div className="mt-4 pt-3.5 border-t border-white/5 flex flex-wrap gap-4 justify-between items-center text-[10px] text-slate-400 font-mono">
            <div className="flex items-center gap-1.5 bg-slate-900/50 px-3 py-1.5 rounded-lg border border-white/5">
              <Clock className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>توقيت النظام التلقائي (محدث):</span> <span className="text-white font-bold">{currentDateTime}</span>
            </div>
            {activeUser.terminalAccess && (
              <div className="bg-emerald-600/20 text-emerald-400 p-1 px-2.5 rounded border border-emerald-500/30 flex items-center gap-1 font-sans font-bold">
                <Smartphone className="w-3.5 h-3.5 animate-pulse" />
                <span>شاشة البوابة الطرفية (Terminal Console) مفعلة</span>
              </div>
            )}
          </div>

        </div>
      </header>

      {/* 2b. Android/PWA Native Installation Guide Banner */}
      {showAndroidInstallBanner && (
        <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 mt-4" id="android-install-banner">
          <div className="bg-gradient-to-r from-slate-900 to-indigo-950 border border-indigo-500/25 text-white p-4 rounded-2xl shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all duration-300 animate-slide-down">
            <div className="flex items-start gap-3">
              <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20 shrink-0">
                <Smartphone className="w-5 h-5 animate-bounce" />
              </div>
              <div className="space-y-1">
                <div className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                  <span>📱</span>
                  <span>تثبيت النظام كتطبيق أندرويد متكامل (PWA App):</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed font-sans">
                  هذا النظام مجهز بالكامل للعمل كـ <strong>تطبيق مثبت</strong> على أجهزة أندرويد. انقر على خيارات المتصفح <strong className="text-amber-400">(⋮ أو شريط القائمة في Chrome)</strong> ثم اضغط على <strong className="text-emerald-400 font-bold">"إضافة إلى الشاشة الرئيسية" (Add to Home Screen)</strong> أو <strong className="text-emerald-400 font-bold">"تثبيت التطبيق" (Install App)</strong> لتشغيله كأيقونة واختصار مستقل على هاتفك مع أداء مضاعف وواجهة كاملة بدون أشرطة مفقودة.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 self-end md:self-center shrink-0">
              <button 
                onClick={dismissAndroidBanner}
                className="text-[10px] text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-lg border border-white/5 transition-all cursor-pointer font-bold"
              >
                تخطي الإرشاد ×
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Main Dashboard Interactive Layout */}
      <main className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 flex-1 py-6 flex flex-col gap-6">
        
        {/* Navigation Tabs (Modern Segmented Track) */}
        {currentRole !== 'Customer' && currentRole !== 'Owner' && (
          <div className="bg-slate-200/60 p-1.5 rounded-2xl flex flex-wrap gap-1 border border-slate-200 shadow-inner print:hidden" id="navigation-tabs">
          
          <button
            onClick={() => setActiveTab('home')}
            className={`px-4 py-2.5 rounded-xl font-extrabold text-xs flex items-center gap-2 transition-all duration-200 cursor-pointer ${
              activeTab === 'home'
                ? 'bg-slate-900 text-white shadow-sm scale-[1.01]'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>لوحة التحكم الرئيسية</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2.5 rounded-xl font-extrabold text-xs flex items-center gap-2 transition-all duration-200 cursor-pointer ${
              activeTab === 'orders'
                ? 'bg-slate-900 text-white shadow-sm scale-[1.01]'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <ShoppingCart className="w-4 h-4" />
            <span>طلبيات وفواتير مبيعات الكري</span>
          </button>

          {currentRole !== 'Customer' && (
            <>
              <button
                onClick={() => setActiveTab('accounts')}
                className={`px-4 py-2.5 rounded-xl font-extrabold text-xs flex items-center gap-2 transition-all duration-200 cursor-pointer ${
                  activeTab === 'accounts'
                    ? 'bg-slate-900 text-white shadow-sm scale-[1.01]'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                }`}
              >
                <Scale className="w-4 h-4" />
                <span>الحسابات العامة والقيود والتقارير</span>
              </button>

              <button
                onClick={() => setActiveTab('suppliers')}
                className={`px-4 py-2.5 rounded-xl font-extrabold text-xs flex items-center gap-2 transition-all duration-200 cursor-pointer ${
                  activeTab === 'suppliers'
                    ? 'bg-slate-900 text-white shadow-sm scale-[1.01]'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                }`}
              >
                <Landmark className="w-4 h-4" />
                <span>الحسابات الجارية للكسارات وكشف الحساب</span>
              </button>

              <button
                onClick={() => setActiveTab('inventory')}
                className={`px-4 py-2.5 rounded-xl font-extrabold text-xs flex items-center gap-2 transition-all duration-200 cursor-pointer ${
                  activeTab === 'inventory'
                    ? 'bg-slate-900 text-white shadow-sm scale-[1.01]'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                }`}
              >
                <Boxes className="w-4 h-4" />
                <span>سيلوهات المخزون الفعلي بالمتر المكعب</span>
              </button>

              <button
                onClick={() => setActiveTab('users')}
                className={`px-4 py-2.5 rounded-xl font-extrabold text-xs flex items-center gap-2 transition-all duration-200 cursor-pointer ${
                  activeTab === 'users'
                    ? 'bg-slate-900 text-white shadow-sm scale-[1.01]'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>إدارة الصلاحيات والكادر</span>
              </button>

              <button
                onClick={() => setActiveTab('terminal')}
                className={`px-4 py-2.5 rounded-xl font-extrabold text-xs flex items-center gap-2 transition-all duration-200 cursor-pointer ${
                  activeTab === 'terminal'
                    ? 'bg-emerald-600 text-white shadow-sm scale-[1.01]'
                    : 'text-emerald-800 hover:bg-emerald-500/10'
                }`}
                id="tab-btn-terminal"
              >
                <Terminal className="w-4 h-4 animate-pulse" />
                <span>شاشة البوابة والوزن الطرفية</span>
              </button>
            </>
          )}
        </div>
        )}

        {/* 4. Dynamic Views Container */}
        <div className="space-y-6" id="dashboard-content-renderer">
          
          {/* Special view for Customer role */}
          {currentRole === 'Customer' && (
            <CustomerOrderPortal
              activeUser={activeUser}
              suppliers={suppliers}
              inventory={inventory}
              prices={prices}
              onAddOrder={handleAddOrder}
            />
          )}

          {/* Special view for Owner role */}
          {currentRole === 'Owner' && (
            <OwnerDashboard
              activeUser={activeUser}
              suppliers={suppliers}
              orders={orders}
              inventory={inventory}
            />
          )}

          {/* Tab: Home (Uncluttered main overview) */}
          {currentRole !== 'Customer' && currentRole !== 'Owner' && activeTab === 'home' && (() => {
            // High-level metrics calculation for prestigious summary display
            const activeOrdersForHome = orders.filter(o => o.status !== 'Cancelled');
            const totalSalesForHome = activeOrdersForHome.reduce((sum, o) => sum + o.totalPrice, 0);
            const totalCommissionForHome = activeOrdersForHome.reduce((sum, o) => sum + o.commission, 0);
            const totalOwedToSuppliersForHome = suppliers.reduce((sum, s) => sum + s.balance, 0);
            const totalVolumeForHome = activeOrdersForHome.reduce((sum, o) => sum + o.quantity, 0);
            const pendingOrdersForHome = orders.filter(o => o.status === 'Pending').length;

            return (
              <div className="space-y-6 pt-2 animate-slide-down animate-duration-200" id="home-dashboard-view">
                
                {/* 1. Main Executive Console & Banner */}
                <div className="bg-gradient-to-l from-slate-950 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 md:p-8 relative overflow-hidden border border-slate-800 shadow-2xl">
                  <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl -mr-20 -mt-20"></div>
                  <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl -ml-15 -mb-15"></div>
                  
                  <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                    <div className="text-right space-y-2">
                      <div className="flex flex-wrap items-center gap-2 flex-row-reverse justify-end">
                        <span className="bg-amber-500/10 text-amber-400 text-[10px] px-3 py-1 rounded-full font-black tracking-wide border border-amber-500/20">
                          لوحة التحكم والمطابقة الموحدة 🏢
                        </span>
                        <span className="bg-emerald-500/10 text-emerald-400 text-[10px] px-2.5 py-1 rounded-full font-black border border-emerald-500/20 flex items-center gap-1">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                          <span>خادم التخزين الآمن مفعل ونشط</span>
                        </span>
                      </div>
                      
                      <h2 className="text-xl md:text-2xl font-black mt-2 text-white">
                        مرحباً بك، {activeUser?.name || 'مستخدم النظام الموقر'}
                      </h2>
                      
                      <p className="text-slate-350 text-xs leading-relaxed max-w-3xl">
                        صلاحياتك النشطة: <span className="text-amber-300 font-bold">{
                          activeUser?.role === 'Admin' ? 'المدير المطلق للنظام التشغيلي والمالي الموحد' : 
                          activeUser?.role === 'Sales Representative' ? 'مندوب مبيعات معتمد لتسجيل وفواتير العملاء' : 
                          activeUser?.role === 'Accounting' ? 'مسؤول حسابات مالي لمراجعة وتدقيق المعاملات والقيود ثنائية الدفتر' : 
                          activeUser?.role === 'Cashier' ? 'مسؤول الصندوق لاستلام المقبوضات وصرف الدفعات' : 
                          'مستشار ومسؤول مبيعات للكسارات'
                        }</span>. يمكنك تتبع حركة الشاحنات والموازين الذاتية والاطلاع على التوزيعات المحاسبية الفورية بكل سلاسة وأمان.
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-3 shrink-0 self-start lg:self-auto pt-2 lg:pt-0">
                      <button
                        onClick={() => setIsStatsModalOpen(true)}
                        className="bg-amber-500 hover:bg-amber-600 text-slate-950 px-5 py-3 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer shadow-lg shadow-amber-500/10"
                        title="عرض كلي لإحصائيات الكسارات"
                      >
                        <LayoutDashboard className="w-4 h-4 text-slate-950 shrink-0" />
                        <span>تحليلات الأداء المتقدمة 📊</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* 2. Micro-Analytics Executive Metrics Bar - Uncluttered, airy, high status overview */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4" id="home-executive-ribbon">
                  
                  <div className="bg-white rounded-2xl border border-slate-200 p-4 hover:border-slate-300 hover:shadow-xs transition-all duration-300 text-right">
                    <span className="text-[10px] text-slate-400 font-bold block">إجمالي قيمة فواتير المبيعات</span>
                    <div className="flex items-baseline justify-end gap-1 mt-1.5">
                      <span className="text-sm font-sans text-slate-500 font-bold">ريال</span>
                      <span className="text-lg md:text-xl font-mono font-black text-slate-900 tracking-tight">
                        {totalSalesForHome.toLocaleString('ar-YE')}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center justify-end gap-1.5 text-[9px] text-emerald-600 font-bold">
                      <span>✓ {activeOrdersForHome.length} طلبيات معتمدة</span>
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl border border-slate-200 p-4 hover:border-slate-300 hover:shadow-xs transition-all duration-300 text-right">
                    <span className="text-[10px] text-slate-400 font-bold block">الرسوم الإدارية والتوزيعات (1100 ريال)</span>
                    <div className="flex items-baseline justify-end gap-1 mt-1.5">
                      <span className="text-sm font-sans text-slate-500 font-bold">ريال</span>
                      <span className="text-lg md:text-xl font-mono font-black text-indigo-700 tracking-tight">
                        {totalCommissionForHome.toLocaleString('ar-YE')}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center justify-end gap-1 text-[9px] text-slate-400 font-bold">
                      <span>الرسوم المحصلة بالتوازي</span>
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl border border-slate-200 p-4 hover:border-slate-300 hover:shadow-xs transition-all duration-300 text-right">
                    <span className="text-[10px] text-slate-400 font-bold block">المستحقات الحالية للكسارات</span>
                    <div className="flex items-baseline justify-end gap-1 mt-1.5">
                      <span className="text-sm font-sans text-slate-500 font-bold">ريال</span>
                      <span className="text-lg md:text-xl font-mono font-black text-amber-700 tracking-tight">
                        {totalOwedToSuppliersForHome.toLocaleString('ar-YE')}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center justify-end gap-1 text-[9px] text-amber-600 font-bold">
                      <span>موزعة على {suppliers.length} كسارة</span>
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl border border-slate-200 p-4 hover:border-slate-300 hover:shadow-xs transition-all duration-300 text-right">
                    <span className="text-[10px] text-slate-400 font-bold block">إجمالي الكميات المباعة والموردة</span>
                    <div className="flex items-baseline justify-end gap-1 mt-1.5">
                      <span className="text-sm font-sans text-slate-500 font-bold">م³</span>
                      <span className="text-lg md:text-xl font-mono font-black text-emerald-700 tracking-tight">
                        {totalVolumeForHome.toLocaleString('ar-YE')}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center justify-end gap-1 text-[9px] text-slate-400 font-bold">
                      <span>مطابقة للبوابات والموازين</span>
                    </div>
                  </div>

                </div>

                {/* 3. Core Operational Control Bento Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  
                  {/* Card 1: Orders and Bills Control Panel */}
                  <div className="bg-white rounded-3xl border border-slate-200 p-6 flex flex-col justify-between hover:border-slate-300 hover:shadow-md transition duration-300 relative overflow-hidden group">
                    <div className="absolute top-0 left-0 w-24 h-24 bg-indigo-50 rounded-full blur-2xl -ml-5 -mt-5"></div>
                    <div className="text-right relative z-10">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                        <span className="bg-slate-100 text-slate-800 text-[10px] font-mono px-2.5 py-0.5 rounded-full font-bold">
                          {orders.length} شحنة مسجلة
                        </span>
                        <div className="flex items-center gap-2.5">
                          <div>
                            <h4 className="font-extrabold text-slate-900 text-xs text-right">مبيعات وفواتير الكري</h4>
                            <span className="text-[9px] text-slate-400 block font-semibold text-right">تسجيل بوالص الشحن والاعتماد</span>
                          </div>
                          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                            <ShoppingCart className="w-4 h-4" />
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2 mb-6">
                        <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-xs text-slate-600">
                          <span className="font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded font-mono">{pendingOrdersForHome} شحنات</span>
                          <span>الطلبيات قيد التدقيق:</span>
                        </div>
                        <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-xs text-slate-600">
                          <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-mono">
                            {orders.filter(o => o.status === 'Delivered').length} فاتورة
                          </span>
                          <span>الشحنات المعتمدة والمسلمة:</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setActiveTab('orders')}
                      className="w-full bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition cursor-pointer mt-2 shadow-sm"
                    >
                      <span>🛒 بوابة فواتير مبيعات الكري</span>
                      <ChevronLeft className="w-4 h-4 rotate-180" />
                    </button>
                  </div>

                  {/* Card 2: Inventory & Materials Control Panel */}
                  <div className="bg-white rounded-3xl border border-slate-200 p-6 flex flex-col justify-between hover:border-slate-300 hover:shadow-md transition duration-300 relative overflow-hidden group">
                    <div className="absolute top-0 left-0 w-24 h-24 bg-emerald-50 rounded-full blur-2xl -ml-5 -mt-5"></div>
                    <div className="text-right relative z-10">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                        <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${inventory.filter(i => i.status === 'Low').length > 0 ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'}`}>
                          {inventory.filter(i => i.status === 'Low').length > 0 ? `${inventory.filter(i => i.status === 'Low').length} مستودعات بحاجة لشحن` : 'المخزون آمن'}
                        </span>
                        <div className="flex items-center gap-2.5">
                          <div>
                            <h4 className="font-extrabold text-slate-900 text-xs text-right">سيلوهات الكري والتخزين</h4>
                            <span className="text-[9px] text-slate-400 block font-semibold text-right">المخزونات الحالية وسعة التعبئة</span>
                          </div>
                          <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
                            <Boxes className="w-4 h-4" />
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2 mb-6">
                        {inventory.slice(0, 3).map(item => (
                          <div key={item.id} className="flex items-center justify-between text-xs bg-slate-50 p-2 rounded-xl border border-slate-100">
                            <div className="flex items-center gap-2 font-mono">
                              <span className="font-bold text-slate-900">{item.quantity} م³</span>
                              {item.status === 'Low' && (
                                <span className="bg-rose-50 border border-rose-100 text-rose-600 text-[8px] px-1 rounded">شبه فارغ</span>
                              )}
                            </div>
                            <span className="font-bold text-slate-700">{item.product}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={() => setActiveTab('inventory')}
                      className="w-full bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition cursor-pointer mt-2 shadow-sm"
                    >
                      <span>📦 سيلوهات ومستودعات التخزين</span>
                      <ChevronLeft className="w-4 h-4 rotate-180" />
                    </button>
                  </div>

                  {/* Card 3: Supplier and Financial Ledger Panel */}
                  <div className="bg-white rounded-3xl border border-slate-200 p-6 flex flex-col justify-between hover:border-slate-300 hover:shadow-md transition duration-300 relative overflow-hidden group">
                    <div className="absolute top-0 left-0 w-24 h-24 bg-amber-50 rounded-full blur-2xl -ml-5 -mt-5"></div>
                    <div className="text-right relative z-10">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                        <span className="bg-slate-100 text-slate-800 text-[10px] font-mono px-2.5 py-0.5 rounded-full font-bold">
                          {suppliers.length} جهات معتمدة
                        </span>
                        <div className="flex items-center gap-2.5">
                          <div>
                            <h4 className="font-extrabold text-slate-900 text-xs text-right">الحسابات الجارية للكسارات</h4>
                            <span className="text-[9px] text-slate-400 block font-semibold text-right">الموازين المالية والتوزيع الدفتري</span>
                          </div>
                          <div className="p-2.5 bg-amber-50 text-amber-700 rounded-xl">
                            <Landmark className="w-4 h-4" />
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2 mb-6">
                        {suppliers.slice(0, 3).map(s => (
                          <div key={s.id} className="flex items-center justify-between text-xs bg-slate-50 p-2 rounded-xl border border-slate-100">
                            <span className="font-mono font-bold text-amber-700 bg-amber-50/50 px-2 py-0.5 rounded text-[10px]">
                              {s.balance.toLocaleString()} ر.ي
                            </span>
                            <span className="font-bold text-slate-700">{s.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={() => setActiveTab('suppliers')}
                      className="w-full bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition cursor-pointer mt-2 shadow-sm"
                    >
                      <span>🏛️ إدارة الكسارات والتسويات المالية</span>
                      <ChevronLeft className="w-4 h-4 rotate-180" />
                    </button>
                  </div>

                </div>

                {/* 4. Elegant Platform Status Ribbon */}
                <div className="bg-slate-50 rounded-2xl border border-slate-200 p-4" id="home-system-map">
                  <div className="flex flex-col md:flex-row-reverse justify-between items-start md:items-center gap-4 text-right">
                    <div className="flex items-center flex-row-reverse gap-3">
                      <div className="p-2.5 bg-white border border-slate-200 text-slate-600 rounded-xl">
                        <ShieldCheck className="w-5 h-5 text-indigo-600" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-slate-900 text-xs">نظام موثوق ومحمي بالكامل</h4>
                        <p className="text-slate-400 text-[10px] mt-0.5">كافة القيود المالية وسجلات التحميل مطابقة للمعاير اليمنية للمحاسبة وسندات موازين بوابات الكسارات الموحدة.</p>
                      </div>
                    </div>
                    <div className="bg-slate-100/80 border border-slate-200/50 text-slate-600 text-[10px] px-3 py-1.5 rounded-xl font-bold font-mono">
                      نسخة النظام المعتمدة: v5.4 (محلي ومطابق بالكامل)
                    </div>
                  </div>
                </div>

              </div>
            );
          })()}

          {/* Tab: Orders (Purchase list) */}
          {currentRole !== 'Customer' && currentRole !== 'Owner' && activeTab === 'orders' && (
            <OrdersManager
              orders={orders}
              suppliers={suppliers}
              inventory={inventory}
              prices={prices}
              users={users}
              currentRole={currentRole}
              onAddOrder={handleAddOrder}
              onUpdateOrderStatus={handleUpdateOrderStatus}
            />
          )}

          {/* Tab: Suppliers Ledger & Ledger list */}
          {currentRole !== 'Customer' && currentRole !== 'Owner' && activeTab === 'suppliers' && (
            <SuppliersManager
              suppliers={suppliers}
              transactions={transactions}
              prices={prices}
              inventory={inventory}
              currentRole={currentRole}
              onAddTransaction={handleAddTransaction}
              onRegisterProduction={handleRegisterProduction}
            />
          )}

          {/* Tab: General Accounting & Ledger */}
          {currentRole !== 'Customer' && currentRole !== 'Owner' && activeTab === 'accounts' && (
            <AccountingManager
              orders={orders}
              suppliers={suppliers}
              inventory={inventory}
              transactions={transactions}
              currentRole={currentRole}
              onAddTransaction={handleAddTransaction}
            />
          )}

          {/* Tab: Inventory details */}
          {currentRole !== 'Customer' && currentRole !== 'Owner' && activeTab === 'inventory' && (
            <InventoryManager
              inventory={inventory}
              prices={prices}
              currentRole={currentRole}
              onUpdateInventoryQty={handleUpdateInventoryQty}
            />
          )}

          {/* Tab: Users Management */}
          {currentRole !== 'Customer' && currentRole !== 'Owner' && activeTab === 'users' && (
            <UsersManager
              users={users}
              currentRole={currentRole}
              onAddUser={handleAddUser}
              onToggleUserStatus={handleToggleUserStatus}
              onToggleTerminalAccess={handleToggleTerminalAccess}
            />
          )}

          {/* Tab: Terminal Console */}
          {currentRole !== 'Customer' && currentRole !== 'Owner' && activeTab === 'terminal' && (
            <TerminalConsole
              orders={orders}
              suppliers={suppliers}
              inventory={inventory}
              prices={prices}
              users={users}
              currentRole={currentRole}
              activeUser={activeUser}
              onAddOrder={handleAddOrder}
              onUpdateOrderStatus={handleUpdateOrderStatus}
              onAddTransaction={handleAddTransaction}
              onRegisterProduction={handleRegisterProduction}
              onUpdateInventoryQty={handleUpdateInventoryQty}
            />
          )}

        </div>

      </main>

      {/* 5. Footer and Seed Data Reset tools */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 mt-12 py-8" id="main-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div>
              <p className="text-xs font-bold text-white">نظام إدارة مبيعات الكسارات لعام © 2026</p>
              <p className="text-[10px] text-slate-500 mt-1">مصمم خصيصاً لمتابعة مبيعات الكري وحسابات الكسارات بموجب الدفاتر المحوسبة الثنائية الدقيقة.</p>
            </div>

            <div className="flex items-center gap-4">
              {/* Reset to Seed Data default for prospective testing */}
              <button
                onClick={handleResetData}
                className="bg-slate-800 hover:bg-slate-700 text-slate-350 text-slate-300 font-bold text-[10px] px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all"
                id="btn-reseed-data"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                إعادة ضبط البيانات وتصفير المعاملات المحدثة
              </button>

              <span className="text-[10px] font-mono text-slate-500">
                مبني محلياً بنظام Persisted Buffer Engine
              </span>
            </div>
          </div>
        </div>
      </footer>

      {/* 6. Custom Reset & Thinning Interactive Dialog */}
      {isResetModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto" id="reset-modal-overlay">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden divide-y divide-slate-100" id="reset-modal-body">
            
            {/* Header */}
            <div className="p-5 flex items-center justify-between bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-500 animate-pulse" />
                <h3 className="font-bold text-sm">أدوات التصفير وإعادة ضبط الحسابات والكميات</h3>
              </div>
              <button 
                onClick={() => setIsResetModalOpen(false)}
                className="text-slate-400 hover:text-white transition-colors text-lg p-1"
                title="إغلاق"
              >
                ×
              </button>
            </div>

            {/* Options List */}
            <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
              <p className="text-xs text-slate-500 leading-relaxed font-sans mb-3 text-right">
                الرجاء تحديد الأقسام والبيانات التي تود تصفير قيمها أو إلغاء قيودها من تطبيق أندرويد. يمكنك دمج عدة خيارات أو اختيار تصفير النظام الشامل:
              </p>

              {/* Option 1: Factory Reset */}
              <label className={`block p-3.5 rounded-xl border transition-all cursor-pointer ${resetOptions.factoryReset ? 'border-amber-500 bg-amber-50/50' : 'border-slate-200 hover:bg-slate-50'}`}>
                <div className="flex items-start gap-3">
                  <input 
                    type="checkbox"
                    checked={resetOptions.factoryReset}
                    onChange={(e) => {
                      const isChecked = e.target.checked;
                      setResetOptions({
                        resetOrders: isChecked,
                        resetTransactions: isChecked,
                        resetSuppliers: isChecked,
                        resetInventory: isChecked,
                        resetUsers: isChecked,
                        factoryReset: isChecked,
                      });
                    }}
                    className="mt-1 accent-amber-600 rounded cursor-pointer"
                  />
                  <div>
                    <span className="text-xs font-black text-amber-950 block font-sans">🔄 إعادة ضبط المصنع بالكامل (املأ بالبيانات الافتراضية)</span>
                    <span className="text-[10px] text-amber-900 block mt-1 leading-normal">
                      يلغي كافة المدخلات والطلبات المحدثة الحالية ويعيد النظام إلى الحالة النموذجية الجاهزة للمعاينة مع الكسارات المعتمدة والطلبيات المخططة افتراضياً.
                    </span>
                  </div>
                </div>
              </label>

              <div className="border-t border-dashed border-slate-200 my-3"></div>

              {/* Grid of other granular options */}
              <div className="space-y-3">
                
                {/* Orders */}
                <label className={`block p-3 rounded-xl border transition-all cursor-pointer ${resetOptions.factoryReset ? 'opacity-50 cursor-not-allowed bg-slate-50' : resetOptions.resetOrders ? 'border-emerald-500 bg-emerald-50/20' : 'border-slate-200 hover:bg-slate-50'}`}>
                  <div className="flex items-start gap-3">
                    <input 
                      type="checkbox"
                      disabled={resetOptions.factoryReset}
                      checked={resetOptions.resetOrders}
                      onChange={(e) => setResetOptions(prev => ({ ...prev, resetOrders: e.target.checked }))}
                      className="mt-0.5 accent-emerald-600 rounded cursor-pointer"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-800 block font-sans">📦 تصفير فواتير وطلبات المبيعات الجارية</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5 font-sans">
                        سيتم مسح كافة سجلات طلبات الشراء والبيع وعقود مستحقات الطلبيات لتصبح القائمة فارغة تماماً.
                      </span>
                    </div>
                  </div>
                </label>

                {/* Transactions */}
                <label className={`block p-3 rounded-xl border transition-all cursor-pointer ${resetOptions.factoryReset ? 'opacity-50 cursor-not-allowed bg-slate-50' : resetOptions.resetTransactions ? 'border-emerald-500 bg-emerald-50/20' : 'border-slate-200 hover:bg-slate-50'}`}>
                  <div className="flex items-start gap-3">
                    <input 
                      type="checkbox"
                      disabled={resetOptions.factoryReset}
                      checked={resetOptions.resetTransactions}
                      onChange={(e) => setResetOptions(prev => ({ ...prev, resetTransactions: e.target.checked }))}
                      className="mt-0.5 accent-emerald-600 rounded cursor-pointer"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-800 block font-sans">💵 تصفير كشوف الحساب والقيود الثنائية الدفترية</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5 font-sans">
                        سيتم تصفير كشوف وسجلات المحاسبة وحذف جميع سندات الصرف والإنتاج للكسارات الجارية.
                      </span>
                    </div>
                  </div>
                </label>

                {/* Suppliers balances */}
                <label className={`block p-3 rounded-xl border transition-all cursor-pointer ${resetOptions.factoryReset ? 'opacity-50 cursor-not-allowed bg-slate-50' : resetOptions.resetSuppliers ? 'border-emerald-500 bg-emerald-50/20' : 'border-slate-200 hover:bg-slate-50'}`}>
                  <div className="flex items-start gap-3">
                    <input 
                      type="checkbox"
                      disabled={resetOptions.factoryReset}
                      checked={resetOptions.resetSuppliers}
                      onChange={(e) => setResetOptions(prev => ({ ...prev, resetSuppliers: e.target.checked }))}
                      className="mt-0.5 accent-emerald-600 rounded cursor-pointer"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-800 block font-sans">🏛️ تصفير الذمم والأرصدة الدائنة للكسارات</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5 font-sans">
                        سيصبح رصيد المبالغ المستحقة لكافة الكسارات الموردة (صفر ريال يمني) لتسوية الذمم.
                      </span>
                    </div>
                  </div>
                </label>

                {/* Inventory */}
                <label className={`block p-3 rounded-xl border transition-all cursor-pointer ${resetOptions.factoryReset ? 'opacity-50 cursor-not-allowed bg-slate-50' : resetOptions.resetInventory ? 'border-emerald-500 bg-emerald-50/20' : 'border-slate-200 hover:bg-slate-50'}`}>
                  <div className="flex items-start gap-3">
                    <input 
                      type="checkbox"
                      disabled={resetOptions.factoryReset}
                      checked={resetOptions.resetInventory}
                      onChange={(e) => setResetOptions(prev => ({ ...prev, resetInventory: e.target.checked }))}
                      className="mt-0.5 accent-emerald-600 rounded cursor-pointer"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-800 block font-sans">🌪️ تصفير مخزون السيلوهات والكسارات (0 متر مكعب)</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5 font-sans">
                        سيتم ضبط كافة كميات سيلوهات الكري والكسارات م³ إلى (صفر) تصفير كلي لمستويات المخازن.
                      </span>
                    </div>
                  </div>
                </label>

                {/* Users list */}
                <label className={`block p-3 rounded-xl border transition-all cursor-pointer ${resetOptions.factoryReset ? 'opacity-50 cursor-not-allowed bg-slate-50' : resetOptions.resetUsers ? 'border-emerald-500 bg-emerald-50/20' : 'border-slate-200 hover:bg-slate-50'}`}>
                  <div className="flex items-start gap-3">
                    <input 
                      type="checkbox"
                      disabled={resetOptions.factoryReset}
                      checked={resetOptions.resetUsers}
                      onChange={(e) => setResetOptions(prev => ({ ...prev, resetUsers: e.target.checked }))}
                      className="mt-0.5 accent-emerald-600 rounded cursor-pointer"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-800 block font-sans">👥 إبقاء الكوادر الافتراضية والتخلص من الحسابات الإضافية</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5 font-sans">
                        سيتم تصفير واستعادة قائمة المستخدمين المعتمدة الأولى ومسح الحسابات والعملاء المكتسبين.
                      </span>
                    </div>
                  </div>
                </label>

              </div>

            </div>

            {/* Actions footer */}
            <div className="p-4 bg-slate-50 flex items-center justify-between gap-3 font-sans text-right">
              <button
                type="button"
                onClick={() => setIsResetModalOpen(false)}
                className="text-slate-500 hover:bg-slate-100 hover:text-slate-700 bg-white border border-slate-200 text-xs font-bold px-4 py-2 rounded-xl transition-all cursor-pointer"
              >
                تراجع وإلغاء
              </button>
              
              <button
                type="button"
                onClick={executeReset}
                className="bg-rose-600 hover:bg-rose-700 text-white text-xs font-black px-6 py-2.5 rounded-xl inline-flex items-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                تأكيد وتنفيذ التصفير الآن
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Settings Modal */}
      {isSettingsModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto" id="modal-system-settings">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-100/80 text-right animate-float-in">
            <div className="bg-slate-900 p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold font-sans">تخصيص وإعدادات النظام والواجهة</h3>
              </div>
              <button 
                onClick={() => setIsSettingsModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs font-bold font-mono bg-white/5 hover:bg-white/10 w-7 h-7 rounded-lg flex items-center justify-center transition cursor-pointer"
              >
                ×
              </button>
            </div>

            <div className="p-6 space-y-4 font-sans text-xs">
              <p className="text-slate-500 mb-2 leading-relaxed">
                هنا يمكنك تكييف وتحديث المعالم والنصوص الظاهرية للنظام المالي واللوجستي، وسيتم تحديثها فورياً وحفظها تلقائياً على المتصفح.
              </p>

              <div className="space-y-1.5">
                <label className="block font-bold text-slate-700">✍️ اسم النظام الرئيسي المعتمد (العنوان)</label>
                <input
                  type="text"
                  value={systemTitle}
                  onChange={(e) => setSystemTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-850 font-bold focus:bg-white outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                  placeholder="مثال: المبيعات وفواتير وتوزيعات الكري"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block font-bold text-slate-700">📝 شعار ووصف النظام الفرعي</label>
                <textarea
                  value={systemSlogan}
                  rows={2}
                  onChange={(e) => setSystemSlogan(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-750 font-medium focus:bg-white outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 leading-relaxed"
                  placeholder="اكتب وصفاً مختصراً للشريط التعريفي..."
                />
              </div>

              <div className="pt-2">
                <label className="flex items-start gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-100 hover:border-slate-200 transition cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoDeductInventory}
                    onChange={(e) => setAutoDeductInventory(e.target.checked)}
                    className="mt-0.5 accent-slate-900 rounded cursor-pointer"
                  />
                  <div>
                    <span className="block font-bold text-slate-800">📊 خصم المخزون التلقائي من السيلو</span>
                    <span className="block text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                      عند تمكين الخيار، سيتم تحديث رصيد السيلو وتناقصه بالمتر المكعب جراء شحن وتخليص الفواتير في نافذة الميزان تلقائياً.
                    </span>
                  </div>
                </label>
              </div>

              <div className="bg-amber-50 rounded-xl p-3 border border-amber-200/50 flex gap-2.5">
                <HelpCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="text-[11px] text-amber-950 leading-relaxed">
                  <span className="font-extrabold block mb-0.5">تنويه المزامنة:</span>
                  الإعدادات مخزنة محلياً في جهاز التصفح الحالي وتظل سارية المفعول حتى في حالة انقطاع شبكة الإنترنت المحلية بساحة الكسارة.
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-105 flex justify-between gap-3">
              <button
                onClick={() => setIsSettingsModalOpen(false)}
                className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold px-4 py-2.5 rounded-xl transition cursor-pointer"
              >
                رجوع / تراجع ×
              </button>
              <button
                onClick={() => setIsSettingsModalOpen(false)}
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-black px-6 py-2.5 rounded-xl flex items-center gap-1.5 shadow-md active:scale-95 transition cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>حفظ وإغلاق الإعدادات</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Profile Modal */}
      {isProfileModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto" id="modal-user-profile">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-100/85 text-right animate-float-in">
            <div className="bg-slate-900 p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <UserIcon className="w-5 h-5 text-sky-400" />
                <h3 className="text-sm font-bold font-sans">ملف المستخدم الحالي وبيانات الاعتماد</h3>
              </div>
              <button 
                onClick={() => setIsProfileModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs font-bold font-mono bg-white/5 hover:bg-white/10 w-7 h-7 rounded-lg flex items-center justify-center transition cursor-pointer"
              >
                ×
              </button>
            </div>

            <div className="p-6 space-y-4 font-sans text-xs">
              <div className="flex items-center gap-4 p-4 bg-sky-500/10 border border-sky-550/20 rounded-2xl">
                <div className="bg-sky-500 text-white p-3 rounded-xl font-bold text-center shrink-0 min-w-[55px]">
                  <span className="block text-[10px] opacity-80">كود</span>
                  <span className="block text-xs font-black font-mono">{activeUser.id}</span>
                </div>
                <div className="space-y-1">
                  <div className="text-slate-900 font-black text-sm flex items-center gap-1.5">
                    <span>{activeUser.name}</span>
                    <span className="bg-slate-900 text-amber-400 text-[9px] px-2 py-0.5 rounded-md font-bold">{activeUser.role}</span>
                  </div>
                  <p className="text-slate-500 text-[11px]">
                    رقم الهاتف: {activeUser.phone || 'غير مسجل'} • كود الترخيص والتوثيق متاح
                  </p>
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <h4 className="font-bold text-slate-800 border-b border-slate-100 pb-1.5">📝 تعديل وتحديث البيانات الشخصية:</h4>
                
                <div className="space-y-1.5">
                  <label className="block text-slate-600 font-semibold">👤 الاسم الكامل للمستفيد / الموظف</label>
                  <input
                    type="text"
                    value={activeUser.name}
                    onChange={(e) => {
                      const updated = { ...activeUser, name: e.target.value };
                      setUsers(prev => prev.map(u => u.id === activeUser.id ? updated : u));
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-850 font-bold focus:bg-white focus:border-sky-500 outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-slate-600 font-semibold">📞 رقم الهاتف المحمول (الناقل/سائق/مكتبي)</label>
                  <input
                    type="text"
                    value={activeUser.phone || ''}
                    onChange={(e) => {
                      const updated = { ...activeUser, phone: e.target.value };
                      setUsers(prev => prev.map(u => u.id === activeUser.id ? updated : u));
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-slate-850 font-mono focus:bg-white focus:border-sky-500 outline-none"
                    placeholder="مثال: 967777777777"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 space-y-2">
                <span className="block font-bold text-slate-800">🛡️ تصاريح الوصول والصلاحيات الأمنية:</span>
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div className={`p-2.5 rounded-xl border flex items-center gap-2 ${activeUser.terminalAccess ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-slate-50 text-slate-400 border-slate-200'}`}>
                    <Smartphone className="w-4 h-4 text-emerald-500 shrink-0" />
                    <div>
                      <span className="font-bold block">الوحدة الطرفية</span>
                      <span>{activeUser.terminalAccess ? 'مسموح ومخوّل' : 'محجوب أمنياً'}</span>
                    </div>
                  </div>

                  <div className={`p-2.5 rounded-xl border flex items-center gap-2 ${currentRole === 'Admin' ? 'bg-amber-50 text-amber-800 border-amber-200' : 'bg-slate-50 text-slate-400 border-slate-200'}`}>
                    <Shield className="w-4 h-4 text-amber-500 shrink-0" />
                    <div>
                      <span className="font-bold block">الصلاحيات الإدارية</span>
                      <span>{currentRole === 'Admin' ? 'مدير مطلق حسابات' : 'مستعرض دور فرعي'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-between gap-3">
              <button
                onClick={() => setIsProfileModalOpen(false)}
                className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold px-4 py-2.5 rounded-xl transition cursor-pointer"
              >
                رجوع / تراجع ×
              </button>
              <button
                onClick={() => setIsProfileModalOpen(false)}
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-black px-6 py-2.5 rounded-xl flex items-center gap-1.5 shadow-md active:scale-95 transition cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>حفظ البيانات وإغلاق</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Backup Modal */}
      {isBackupModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto" id="modal-system-backup">
          <div className="bg-white rounded-2xl max-w-xl w-full overflow-hidden shadow-2xl border border-slate-100/80 text-right animate-float-in">
            <div className="bg-slate-900 p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-emerald-400" />
                <h3 className="text-sm font-bold font-sans">إدارة النسخ الاحتياطية واستعادة قاعدة البيانات</h3>
              </div>
              <button 
                onClick={() => {
                  setIsBackupModalOpen(false);
                  setBackupError(null);
                  setBackupSuccess(null);
                  setBackupJsonInput('');
                }}
                className="text-slate-400 hover:text-white text-xs font-bold font-mono bg-white/5 hover:bg-white/10 w-7 h-7 rounded-lg flex items-center justify-center transition cursor-pointer"
              >
                ×
              </button>
            </div>

            <div className="p-6 space-y-4 font-sans text-xs">
              <p className="text-slate-500 mb-2 leading-relaxed text-[11px]">
                لكي تضمن حماية الحسابات الجارية وأوامر التحميل المترية للكسارات، يمكنك تصدير ملف النسخة الاحتياطية الكامل وبصيغة معيارية وتخزينه خارجياً، أو استيراد ملف سابق لاستئناف عملك.
              </p>

              {/* Stats overview of what is in backup */}
              <div className="grid grid-cols-4 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-100/70 text-center">
                <div className="p-1 px-1.5">
                  <span className="block text-slate-400 text-[10px]">الطلبيات</span>
                  <span className="block text-emerald-600 font-extrabold text-sm font-mono mt-0.5">{orders.length}</span>
                </div>
                <div className="p-1 px-1.5">
                  <span className="block text-slate-400 text-[10px]">الكسارات</span>
                  <span className="block text-amber-600 font-extrabold text-sm font-mono mt-0.5">{suppliers.length}</span>
                </div>
                <div className="p-1 px-1.5">
                  <span className="block text-slate-400 text-[10px]">القيود الحسابية</span>
                  <span className="block text-indigo-600 font-extrabold text-sm font-mono mt-0.5">{transactions.length}</span>
                </div>
                <div className="p-1 px-1.5">
                  <span className="block text-slate-400 text-[10px]">المستخدمين</span>
                  <span className="block text-slate-800 font-extrabold text-sm font-mono mt-0.5">{users.length}</span>
                </div>
              </div>

              <div className="space-y-2 pt-1">
                <span className="block font-bold text-slate-700">💾 خيار أول: تصدير وتنزيل نسخة احتياطية</span>
                <button
                  type="button"
                  onClick={handleExportBackup}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black p-3 rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer active:scale-95 duration-100"
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل النسخة الاحتياطية الفورية لجهازك (JSON File)</span>
                </button>
              </div>

              <div className="space-y-2.5 pt-3 border-t border-slate-100">
                <span className="block font-bold text-slate-700">🔄 خيار ثانٍ: استعادة واستيراد نسخة احتياطية</span>
                
                {/* Drag-and-drop or file uploader wrapper */}
                <div className="border-2 border-dashed border-slate-250 hover:border-slate-350 rounded-xl p-4 bg-slate-50/50 transition relative text-center">
                  <input
                    type="file"
                    accept=".json"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = (event) => {
                          const text = event.target?.result as string;
                          setBackupJsonInput(text);
                          handleImportBackup(text);
                        };
                        reader.readAsText(file);
                      }
                    }}
                    className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                    id="backup-file-picker"
                  />
                  <div className="space-y-1">
                    <Upload className="w-6 h-6 text-slate-400 mx-auto" />
                    <p className="text-slate-600 font-bold text-[11px]">انقر هنا لاختيار ملف النسخة من جهازك أو اسحبه إلى هنا</p>
                    <p className="text-[10px] text-slate-400">يقبل ملفات بصيغة .json حصراً المستخرجة من النظام</p>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-slate-500 font-medium pb-0.5">أو بدلالة ذلك، الصق كود النسخة النصي (JSON) هنا لاستعادتها:</label>
                  <textarea
                    rows={3}
                    value={backupJsonInput}
                    onChange={(e) => setBackupJsonInput(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 font-mono text-[9px] text-slate-605 outline-none focus:bg-white"
                    placeholder="الصق سلسلة البيانات المشفرة هنا..."
                  />
                  <button
                    type="button"
                    disabled={!backupJsonInput.trim()}
                    onClick={() => handleImportBackup(backupJsonInput)}
                    className="bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-black px-4 py-2 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>تأكيد دمج واستعادة البيانات النصية المكتوبة</span>
                  </button>
                </div>
              </div>

              {/* Alert Feedback messaging */}
              {backupSuccess && (
                <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-xl font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500" />
                  <span>{backupSuccess}</span>
                </div>
              )}

              {backupError && (
                <div className="bg-red-50 border border-red-200 text-red-800 p-3 rounded-xl font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
                  <span>{backupError}</span>
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => {
                  setIsBackupModalOpen(false);
                  setBackupError(null);
                  setBackupSuccess(null);
                  setBackupJsonInput('');
                }}
                className="bg-slate-200 text-slate-800 hover:bg-slate-350 text-xs font-bold px-5 py-2' rounded-xl transition cursor-pointer"
              >
                إغلاق النافذة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Micro Statistics and Analysis Modal */}
      {isStatsModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto" id="modal-system-statistics">
          <div className="bg-white rounded-2xl max-w-5xl w-full overflow-hidden shadow-2xl border border-slate-100/80 text-right animate-float-in my-8">
            <div className="bg-slate-900 p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <LayoutDashboard className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold font-sans">📊 لوحة الإحصاءات والتحليل الميكروي المباشر</h3>
              </div>
              <button 
                onClick={() => setIsStatsModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs font-bold font-mono bg-white/5 hover:bg-white/10 w-7 h-7 rounded-lg flex items-center justify-center transition cursor-pointer"
              >
                ×
              </button>
            </div>

            <div className="p-6 space-y-6 font-sans text-xs">
              <div className="flex flex-col gap-1">
                <p className="text-slate-500 leading-relaxed text-[11px]">
                  مؤشرات تدفق البيانات المترية وسيلوهات الكري المحدثة فوريًا لكل الكسارات المعتمدة للتشغيل.
                </p>
              </div>

              {/* Dynamic calculations stats board */}
              <StatsOverview 
                orders={orders} 
                suppliers={suppliers} 
                inventory={inventory} 
              />

              {/* Graphic analysis component */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6" id="modal-graphical-analysis">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">توزيع الرسوم والنسب والكسارات الجارية</h4>
                    <p className="text-slate-400 text-[10px] mt-0.5">رسم تمثيلي علائقي فوري لأحجام المبيعات وتوزيع الرسوم والنسب الموزعة.</p>
                  </div>
                  <span className="bg-slate-100 text-slate-700 text-[10px] px-2.5 py-1 rounded font-bold font-mono">
                    تحديث تدوين لحظي
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  
                  {/* Progress panel 1: Crusher contributions to orders */}
                  <div className="bg-slate-50 border p-4 rounded-xl flex flex-col justify-between" id="modal-volume-shares">
                    <div>
                      <h5 className="font-bold text-xs text-slate-800 mb-3 block">شحنات الكري المسلمة كليّاً:</h5>
                      <div className="space-y-3">
                        {suppliers.map(s => {
                          const suppOrders = orders.filter(o => o.supplierId === s.id && o.status === 'Delivered');
                          const totalVol = suppOrders.reduce((sum, o) => sum + o.quantity, 0);
                          const pctOfTotal = Math.min(100, Math.round((totalVol / 1000) * 100));
                          return (
                            <div key={s.id} className="text-xs">
                              <div className="flex justify-between font-semibold text-slate-700 mb-1">
                                <span>{s.name}</span>
                                <span className="font-mono text-[10px] text-slate-500">{totalVol} م³</span>
                              </div>
                              <div className="w-full bg-slate-200 rounded-full h-1">
                                <div 
                                  className="bg-slate-900 h-1 rounded-full transition-all duration-300" 
                                  style={{ width: `${pctOfTotal}%` }}
                                ></div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-4 border-t pt-2.5">
                      قيد الكري التراكمي المستخرج بالكامل من سيلوهات التخزين.
                    </div>
                  </div>

                   {/* Progress panel 2: Pending orders monitor */}
                  <div className="bg-slate-50 border p-4 rounded-xl flex flex-col justify-between" id="modal-pending-orders-monitor">
                    <div>
                      <h5 className="font-bold text-xs text-slate-800 mb-3 block">مراقبة الطلبيات المعلقة (بانتظار تأكيد التسوية):</h5>
                      
                      {orders.filter(o => o.status === 'Pending').length === 0 ? (
                        <div className="text-slate-400 text-xs py-4 text-center">
                          لا توجد طلبيات معلقة حالياً. جميع الفواتير تم مطابقتها وتأكيد تسويتها بالكامل.
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {orders.filter(o => o.status === 'Pending').map(o => (
                            <div key={o.id} className="text-[11px] p-2 bg-white rounded border border-slate-100 flex justify-between items-center">
                              <div>
                                <span className="font-mono font-bold block text-slate-900">{o.id}</span>
                                <span className="text-slate-400 text-[9px]">{o.customerName}</span>
                              </div>
                              <div className="text-left font-mono text-[10px]">
                                <span className="text-slate-800 font-bold">{o.quantity} م³</span>
                                <span className="text-slate-400 block text-[9px] font-sans">⏱️ قيد المراجعة</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-500 mt-4 border-t pt-2.5 flex items-center gap-1">
                      <span className="h-2 w-2 rounded-full bg-amber-400"></span>
                      <span>تنبيه: يتوجب مراجعة الرقم الكودي للحوالة البنكية قبل النقر على تأكيد التسليم.</span>
                    </div>
                  </div>

                  {/* Progress panel 3: Inventory adequacy */}
                  <div className="bg-slate-50 border p-4 rounded-xl flex flex-col justify-between" id="modal-quick-ratios">
                    <div>
                      <h5 className="font-bold text-xs text-slate-800 mb-3 block">أبرز تنبيهات الإدارة والتشغيل:</h5>
                      <div className="space-y-3 text-xs">
                        
                        <div className="p-2.5 rounded bg-emerald-50 border border-emerald-100 flex items-center gap-2 flex-row-reverse">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 grow-0 shrink-0" />
                          <div className="text-right">
                            <span className="font-bold text-emerald-800 block">سلامة الحسابات ومزامنة التخزين:</span>
                            <span className="text-[10px] text-emerald-600 block">جميع العمليات مدونة بـ LocalStorage لسلامة الفواتير من انقطاع الطاقة.</span>
                          </div>
                        </div>

                        {inventory.filter(i => i.status === 'Low').length > 0 ? (
                          <div className="p-2.5 rounded bg-rose-50 border border-rose-100 flex items-center gap-2 flex-row-reverse">
                            <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                            <div className="text-right">
                              <span className="font-bold text-rose-800 block">مخزون متدني (خطر):</span>
                              <span className="text-[10px] text-rose-600 block">الكميات لكسارات ومقاطع الكري قاربت كمية الأمان. الرجاء تسجيل إنتاج فوري.</span>
                            </div>
                          </div>
                        ) : (
                          <div className="p-2.5 rounded bg-slate-100 border border-slate-200 text-slate-600 flex items-center gap-2 flex-row-reverse">
                            <Award className="w-4 h-4 text-slate-400" />
                            <div className="text-right">
                              <span className="font-semibold block">المستودعات آمنة:</span>
                              <span className="text-[10px] block">كميات الإمداد الحالية تتجاوز عتبات الأمان لجميع المقاسات.</span>
                            </div>
                          </div>
                        )}

                      </div>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-4 border-t pt-2.5 text-center">
                      مشفر وبواجهة تحكم ذكية للأعمدة.
                    </div>
                  </div>

                </div>
              </div>

            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setIsStatsModalOpen(false)}
                className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-black px-6 py-2.5 rounded-xl flex items-center gap-1.5 shadow-md active:scale-95 transition cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>إغلاق واستكمال العمل</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
