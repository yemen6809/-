package com.crusher.system;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
